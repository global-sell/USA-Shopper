<?php
$pageTitle = "Settings";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle favicon upload
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/x-icon', 'image/png', 'image/jpeg', 'image/svg+xml', 'image/vnd.microsoft.icon'];
        $fileType = $_FILES['favicon']['type'];
        
        if (in_array($fileType, $allowedTypes)) {
            $uploadDir = ROOT_PATH . '/assets/images/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            // Get file extension
            $extension = pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION);
            $faviconPath = $uploadDir . 'favicon.' . $extension;
            
            if (move_uploaded_file($_FILES['favicon']['tmp_name'], $faviconPath)) {
                updateSetting('favicon_path', 'assets/images/favicon.' . $extension);
                $success = 'Favicon uploaded successfully!';
            } else {
                $error = 'Failed to upload favicon';
            }
        } else {
            $error = 'Invalid file type. Please upload ICO, PNG, JPG, or SVG file.';
        }
    }
    
    $settings = [
        'site_name' => sanitizeInput($_POST['site_name'] ?? ''),
        'site_logo' => sanitizeInput($_POST['site_logo'] ?? ''),
        'currency' => sanitizeInput($_POST['currency'] ?? 'USD'),
        'currency_symbol' => sanitizeInput($_POST['currency_symbol'] ?? '$'),
        'tax_percentage' => (float)($_POST['tax_percentage'] ?? 0),
        'payment_gateway' => sanitizeInput($_POST['payment_gateway'] ?? 'razorpay'),
        'razorpay_key_id' => sanitizeInput($_POST['razorpay_key_id'] ?? ''),
        'razorpay_key_secret' => sanitizeInput($_POST['razorpay_key_secret'] ?? ''),
        'stripe_public_key' => sanitizeInput($_POST['stripe_public_key'] ?? ''),
        'stripe_secret_key' => sanitizeInput($_POST['stripe_secret_key'] ?? ''),
        'paypal_client_id' => sanitizeInput($_POST['paypal_client_id'] ?? ''),
        'paypal_secret' => sanitizeInput($_POST['paypal_secret'] ?? ''),
        'from_email' => sanitizeInput($_POST['from_email'] ?? ''),
        'from_name' => sanitizeInput($_POST['from_name'] ?? ''),
        'sendgrid_api_key' => sanitizeInput($_POST['sendgrid_api_key'] ?? ''),
        'email_provider' => sanitizeInput($_POST['email_provider'] ?? 'sendgrid'),
        'site_meta_description' => sanitizeInput($_POST['site_meta_description'] ?? ''),
        'site_keywords' => sanitizeInput($_POST['site_keywords'] ?? ''),
        'google_analytics_id' => sanitizeInput($_POST['google_analytics_id'] ?? ''),
        'facebook_pixel_id' => sanitizeInput($_POST['facebook_pixel_id'] ?? ''),
        'og_image' => sanitizeInput($_POST['og_image'] ?? ''),
        'twitter_handle' => sanitizeInput($_POST['twitter_handle'] ?? ''),
        'contact_phone' => sanitizeInput($_POST['contact_phone'] ?? ''),
        'contact_address' => sanitizeInput($_POST['contact_address'] ?? ''),
        'business_hours' => sanitizeInput($_POST['business_hours'] ?? ''),
        'maintenance_mode' => isset($_POST['maintenance_mode']) ? 1 : 0,
        'maintenance_message' => sanitizeInput($_POST['maintenance_message'] ?? ''),
    ];
    
    foreach ($settings as $key => $value) {
        updateSetting($key, $value);
    }
    
    if (!isset($success)) {
        $success = 'Settings updated successfully';
    }
}

// Get current settings
$currentSettings = [];
$result = $db->query("SELECT setting_key, setting_value FROM settings");
while ($row = $result->fetch_assoc()) {
    $currentSettings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">
                <i class="fas fa-cog me-2 text-primary"></i>System Settings
            </h2>
            <p class="text-muted mb-0">Manage your application configuration and preferences</p>
        </div>
        <div>
            <button type="submit" form="settingsForm" class="btn btn-primary btn-lg">
                <i class="fas fa-save me-2"></i>Save All Changes
            </button>
        </div>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Tabbed Settings Interface -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <!-- Nav Tabs -->
            <ul class="nav nav-tabs nav-fill" id="settingsTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="general-tab" data-mdb-toggle="tab" 
                            data-mdb-target="#general" type="button" role="tab">
                        <i class="fas fa-sliders-h me-2"></i>General
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="email-tab" data-mdb-toggle="tab" 
                            data-mdb-target="#email" type="button" role="tab">
                        <i class="fas fa-envelope me-2"></i>Email
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="payment-tab" data-mdb-toggle="tab" 
                            data-mdb-target="#payment" type="button" role="tab">
                        <i class="fas fa-credit-card me-2"></i>Payment Gateways
                    </button>
                </li>
            </ul>
            
            <form method="POST" id="settingsForm" enctype="multipart/form-data">
                <!-- Tab Content -->
                <div class="tab-content p-4" id="settingsTabContent">
                    
                    <!-- General Settings Tab -->
                    <div class="tab-pane fade show active" id="general" role="tabpanel">
                        <h4 class="mb-4">
                            <i class="fas fa-sliders-h text-primary me-2"></i>General Configuration
                        </h4>
                        
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card border mb-4">
                                    <div class="card-body">
                                        <h6 class="fw-bold mb-3">
                                            <i class="fas fa-globe text-info me-2"></i>Site Information
                                        </h6>
                                        <div class="form-outline mb-4">
                                            <input type="text" id="site_name" name="site_name" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['site_name'] ?? ''); ?>" required>
                                            <label class="form-label" for="site_name">Site Name</label>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="site_logo" name="site_logo" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['site_logo'] ?? ''); ?>" 
                                                   placeholder="https://example.com/logo.png">
                                            <label class="form-label" for="site_logo">Site Logo URL</label>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <textarea id="site_meta_description" name="site_meta_description" class="form-control" 
                                                      rows="3" maxlength="160" 
                                                      placeholder="Enter website meta description for SEO (max 160 characters)"><?php echo htmlspecialchars($currentSettings['site_meta_description'] ?? ''); ?></textarea>
                                            <label class="form-label" for="site_meta_description">Website Meta Description (SEO)</label>
                                            <div class="form-text">
                                                <span id="meta-char-count">0</span>/160 characters - This appears in search results
                                            </div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="site_keywords" name="site_keywords" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['site_keywords'] ?? ''); ?>" 
                                                   placeholder="e.g., online shopping, food delivery, ecommerce">
                                            <label class="form-label" for="site_keywords">SEO Keywords (comma separated)</label>
                                            <div class="form-text">Keywords that describe your website for search engines</div>
                                        </div>
                                        
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            This name will appear across your website and emails. Meta description helps with SEO.
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="card border border-primary mb-4">
                                    <div class="card-header bg-primary text-white">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-image me-2"></i>Favicon & Branding
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Current Favicon</label>
                                            <div class="d-flex align-items-center p-3 bg-light rounded">
                                                <?php 
                                                $faviconPath = $currentSettings['favicon_path'] ?? 'assets/images/favicon.svg';
                                                $fullFaviconPath = SITE_URL . '/' . $faviconPath;
                                                ?>
                                                <img src="<?php echo $fullFaviconPath; ?>" alt="Current Favicon" 
                                                     style="width: 32px; height: 32px; object-fit: contain;" 
                                                     onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Ctext y=\'.9em\' font-size=\'90\'%3E🌐%3C/text%3E%3C/svg%3E'">
                                                <div class="ms-3 flex-grow-1">
                                                    <strong>favicon.ico</strong><br>
                                                    <small class="text-muted">32x32 pixels</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="favicon" class="form-label fw-bold">Upload New Favicon</label>
                                            <input type="file" class="form-control" id="favicon" name="favicon" 
                                                   accept=".ico,.png,.jpg,.jpeg,.svg">
                                            <small class="text-muted d-block mt-2">
                                                <i class="fas fa-info-circle me-1"></i>
                                                Accepted formats: ICO, PNG, JPG, SVG (32x32 or 16x16 recommended)
                                            </small>
                                        </div>
                                        
                                        <div class="alert alert-info mb-0">
                                            <i class="fas fa-lightbulb me-2"></i>
                                            <strong>Tip:</strong> For best results, use a 32x32px PNG or ICO file. 
                                            The favicon will appear in browser tabs and bookmarks.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="card border mb-4">
                                    <div class="card-body">
                                        <h6 class="fw-bold mb-3">
                                            <i class="fas fa-dollar-sign text-success me-2"></i>Currency Settings
                                        </h6>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <div class="form-outline">
                                                    <input type="text" id="currency" name="currency" class="form-control" 
                                                           value="<?php echo htmlspecialchars($currentSettings['currency'] ?? 'USD'); ?>">
                                                    <label class="form-label" for="currency">Currency Code</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <div class="form-outline">
                                                    <input type="text" id="currency_symbol" name="currency_symbol" class="form-control" 
                                                           value="<?php echo htmlspecialchars($currentSettings['currency_symbol'] ?? '$'); ?>">
                                                    <label class="form-label" for="currency_symbol">Symbol</label>
                                                </div>
                                            </div>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Example: USD, EUR, GBP
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="card border mb-4">
                                    <div class="card-body">
                                        <h6 class="fw-bold mb-3">
                                            <i class="fas fa-percentage text-warning me-2"></i>Tax Configuration
                                        </h6>
                                        <div class="form-outline mb-3">
                                            <input type="number" id="tax_percentage" name="tax_percentage" class="form-control" 
                                                   step="0.01" value="<?php echo htmlspecialchars($currentSettings['tax_percentage'] ?? '0'); ?>">
                                            <label class="form-label" for="tax_percentage">Tax Percentage (%)</label>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Applied to all product prices at checkout
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Analytics & Tracking Section -->
                            <div class="col-lg-6">
                                <div class="card border border-info mb-4">
                                    <div class="card-header bg-info text-white">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-chart-line me-2"></i>Analytics & Tracking
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-4">
                                            <input type="text" id="google_analytics_id" name="google_analytics_id" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['google_analytics_id'] ?? 'G-X0ZXK1ZT9C'); ?>" 
                                                   placeholder="G-X0ZXK1ZT9C (Current: Stream ID 12337106903)">
                                            <label class="form-label" for="google_analytics_id">Google Analytics Measurement ID</label>
                                            <div class="form-text">Track website visitors and behavior. Current default: G-X0ZXK1ZT9C</div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="facebook_pixel_id" name="facebook_pixel_id" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['facebook_pixel_id'] ?? ''); ?>" 
                                                   placeholder="123456789012345">
                                            <label class="form-label" for="facebook_pixel_id">Facebook Pixel ID</label>
                                            <div class="form-text">Track conversions for Facebook ads</div>
                                        </div>
                                        
                                        <div class="alert alert-info mb-0">
                                            <i class="fas fa-info-circle me-2"></i>
                                            <strong>Note:</strong> These tracking codes will be automatically added to your website.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Social Media & SEO Section -->
                            <div class="col-lg-6">
                                <div class="card border border-success mb-4">
                                    <div class="card-header bg-success text-white">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-share-alt me-2"></i>Social Media & Open Graph
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-4">
                                            <input type="url" id="og_image" name="og_image" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['og_image'] ?? ''); ?>" 
                                                   placeholder="https://example.com/og-image.jpg">
                                            <label class="form-label" for="og_image">Open Graph Image URL</label>
                                            <div class="form-text">Image shown when sharing on social media (1200x630px recommended)</div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="twitter_handle" name="twitter_handle" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['twitter_handle'] ?? ''); ?>" 
                                                   placeholder="@yourbusiness">
                                            <label class="form-label" for="twitter_handle">Twitter Handle</label>
                                            <div class="form-text">Your business Twitter username (with @)</div>
                                        </div>
                                        
                                        <div class="alert alert-success mb-0">
                                            <i class="fas fa-thumbs-up me-2"></i>
                                            <strong>Tip:</strong> Good social media setup improves click-through rates from social platforms.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Contact Information Section -->
                            <div class="col-lg-6">
                                <div class="card border border-warning mb-4">
                                    <div class="card-header bg-warning text-dark">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-address-book me-2"></i>Business Contact Information
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-4">
                                            <input type="tel" id="contact_phone" name="contact_phone" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['contact_phone'] ?? ''); ?>" 
                                                   placeholder="+1 (555) 123-4567">
                                            <label class="form-label" for="contact_phone">Business Phone</label>
                                            <div class="form-text">Main contact number for customer support</div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <textarea id="contact_address" name="contact_address" class="form-control" 
                                                      rows="3" placeholder="123 Business St, City, State 12345"><?php echo htmlspecialchars($currentSettings['contact_address'] ?? ''); ?></textarea>
                                            <label class="form-label" for="contact_address">Business Address</label>
                                            <div class="form-text">Physical address for your business</div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="business_hours" name="business_hours" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['business_hours'] ?? ''); ?>" 
                                                   placeholder="Mon-Fri: 9AM-6PM, Sat: 10AM-4PM">
                                            <label class="form-label" for="business_hours">Business Hours</label>
                                            <div class="form-text">When customers can reach you</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Maintenance Mode Section -->
                            <div class="col-lg-6">
                                <div class="card border border-danger mb-4">
                                    <div class="card-header bg-danger text-white">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-tools me-2"></i>Maintenance Mode
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-check form-switch mb-4">
                                            <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" 
                                                   <?php echo ($currentSettings['maintenance_mode'] ?? 0) ? 'checked' : ''; ?>>
                                            <label class="form-check-label fw-bold" for="maintenance_mode">
                                                Enable Maintenance Mode
                                            </label>
                                            <div class="form-text">When enabled, only admins can access the site</div>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <textarea id="maintenance_message" name="maintenance_message" class="form-control" 
                                                      rows="3" placeholder="We're currently updating our website. Please check back soon!"><?php echo htmlspecialchars($currentSettings['maintenance_message'] ?? 'We are currently performing scheduled maintenance. Please check back soon!'); ?></textarea>
                                            <label class="form-label" for="maintenance_message">Maintenance Message</label>
                                            <div class="form-text">Message shown to visitors during maintenance</div>
                                        </div>
                                        
                                        <div class="alert alert-warning mb-0">
                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                            <strong>Warning:</strong> Enabling maintenance mode will make your site inaccessible to regular users.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Email Settings Tab -->
                    <div class="tab-pane fade" id="email" role="tabpanel">
                        <h4 class="mb-4">
                            <i class="fas fa-envelope text-primary me-2"></i>Email Configuration
                        </h4>
                        
                        <div class="row">
                            <!-- Email Provider Selection -->
                            <div class="col-lg-12 mb-4">
                                <div class="card border">
                                    <div class="card-body">
                                        <h6 class="fw-bold mb-3">
                                            <i class="fas fa-server text-primary me-2"></i>Email Service Provider
                                        </h6>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <label class="form-label">Select Email Provider</label>
                                                <select name="email_provider" id="email_provider" class="form-select form-select-lg">
                                                    <option value="sendgrid" <?php echo ($currentSettings['email_provider'] ?? 'sendgrid') === 'sendgrid' ? 'selected' : ''; ?>>
                                                        📧 SendGrid (Recommended)
                                                    </option>
                                                    <option value="smtp" <?php echo ($currentSettings['email_provider'] ?? '') === 'smtp' ? 'selected' : ''; ?>>
                                                        📤 SMTP Server
                                                    </option>
                                                    <option value="local" <?php echo ($currentSettings['email_provider'] ?? '') === 'local' ? 'selected' : ''; ?>>
                                                        🖥️ Local Mail (Development Only)
                                                    </option>
                                                </select>
                                                <small class="text-muted mt-2 d-block">
                                                    <i class="fas fa-info-circle me-1"></i>
                                                    SendGrid is recommended for production use
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Sender Information -->
                            <div class="col-lg-6 mb-4">
                                <div class="card border">
                                    <div class="card-body">
                                        <h6 class="fw-bold mb-3">
                                            <i class="fas fa-paper-plane text-info me-2"></i>Sender Information
                                        </h6>
                                        <p class="text-muted mb-4">Configure the default sender details for outgoing emails</p>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="email" id="from_email" name="from_email" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['from_email'] ?? 'noreply@rangpurfood.com'); ?>" required>
                                            <label class="form-label" for="from_email">From Email Address</label>
                                        </div>
                                        
                                        <div class="form-outline mb-4">
                                            <input type="text" id="from_name" name="from_name" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['from_name'] ?? 'Rangpur Food'); ?>" required>
                                            <label class="form-label" for="from_name">From Name</label>
                                        </div>
                                        
                                        <div class="alert alert-warning">
                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                            <strong>Important:</strong> Verify this email address in SendGrid before sending emails.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- SendGrid Configuration -->
                            <div class="col-lg-6 mb-4">
                                <div class="card border border-primary">
                                    <div class="card-header bg-primary text-white">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-key me-2"></i>SendGrid API Configuration
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-3">
                                            <input type="text" id="sendgrid_api_key" name="sendgrid_api_key" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['sendgrid_api_key'] ?? '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'); ?>" 
                                                   placeholder="SG.xxxxxxxxxxxxx">
                                            <label class="form-label" for="sendgrid_api_key">SendGrid API Key</label>
                                        </div>
                                        
                                        <div class="alert alert-info mb-3">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <strong>Status:</strong> 
                                            <?php if (!empty($currentSettings['sendgrid_api_key'])): ?>
                                                <span class="badge bg-success">✓ Configured</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">⚠ Not Configured</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <small class="text-muted d-block mb-2">
                                            <i class="fas fa-link me-1"></i>
                                            <a href="https://app.sendgrid.com/settings/api_keys" target="_blank">Get API Key from SendGrid</a>
                                        </small>
                                        
                                        <small class="text-muted d-block">
                                            <i class="fas fa-gift me-1"></i>
                                            Free Plan: 100 emails/day
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Email Testing -->
                            <div class="col-lg-12">
                                <div class="card border border-success">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-vial text-success me-2"></i>Test Email Configuration
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted mb-3">Send a test email to verify your configuration is working correctly</p>
                                        <div class="row align-items-end">
                                            <div class="col-lg-6">
                                                <div class="form-outline">
                                                    <input type="email" id="test_email" class="form-control" placeholder="your-email@example.com">
                                                    <label class="form-label" for="test_email">Test Email Address</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <button type="button" class="btn btn-success" onclick="sendTestEmail()">
                                                    <i class="fas fa-paper-plane me-2"></i>Send Test Email
                                                </button>
                                            </div>
                                        </div>
                                        <div id="testEmailResult" class="mt-3"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Email Logs -->
                            <div class="col-lg-12 mt-4">
                                <div class="alert alert-secondary">
                                    <i class="fas fa-file-alt me-2"></i>
                                    <strong>Email Logs:</strong> All sent emails are logged to 
                                    <code>logs/emails.log</code> for debugging purposes.
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Gateway Settings Tab -->
                    <div class="tab-pane fade" id="payment" role="tabpanel">
                        <h4 class="mb-4">
                            <i class="fas fa-credit-card text-primary me-2"></i>Payment Gateway Configuration
                        </h4>
                        
                        <div class="card border mb-4">
                            <div class="card-body">
                                <h6 class="fw-bold mb-3">
                                    <i class="fas fa-toggle-on text-success me-2"></i>Active Gateway
                                </h6>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label class="form-label">Select Active Payment Gateway</label>
                                        <select name="payment_gateway" class="form-select form-select-lg">
                                            <option value="razorpay" <?php echo ($currentSettings['payment_gateway'] ?? '') === 'razorpay' ? 'selected' : ''; ?>>
                                                <i class="fas fa-rupee-sign"></i> Razorpay
                                            </option>
                                            <option value="stripe" <?php echo ($currentSettings['payment_gateway'] ?? '') === 'stripe' ? 'selected' : ''; ?>>
                                                Stripe
                                            </option>
                                            <option value="paypal" <?php echo ($currentSettings['payment_gateway'] ?? '') === 'paypal' ? 'selected' : ''; ?>>
                                                PayPal
                                            </option>
                                        </select>
                                        <small class="text-muted mt-2 d-block">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Only one gateway can be active at a time
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <!-- Razorpay -->
                            <div class="col-lg-4 mb-4">
                                <div class="card border h-100">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fas fa-rupee-sign text-primary me-2"></i>Razorpay
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-3">
                                            <input type="text" id="razorpay_key_id" name="razorpay_key_id" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['razorpay_key_id'] ?? ''); ?>">
                                            <label class="form-label" for="razorpay_key_id">Key ID</label>
                                        </div>
                                        <div class="form-outline mb-3">
                                            <input type="password" id="razorpay_key_secret" name="razorpay_key_secret" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['razorpay_key_secret'] ?? ''); ?>">
                                            <label class="form-label" for="razorpay_key_secret">Key Secret</label>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-link me-1"></i>
                                            <a href="https://dashboard.razorpay.com/" target="_blank">Get API Keys</a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Stripe -->
                            <div class="col-lg-4 mb-4">
                                <div class="card border h-100">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fab fa-stripe text-primary me-2"></i>Stripe
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-3">
                                            <input type="text" id="stripe_public_key" name="stripe_public_key" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['stripe_public_key'] ?? ''); ?>">
                                            <label class="form-label" for="stripe_public_key">Publishable Key</label>
                                        </div>
                                        <div class="form-outline mb-3">
                                            <input type="password" id="stripe_secret_key" name="stripe_secret_key" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['stripe_secret_key'] ?? ''); ?>">
                                            <label class="form-label" for="stripe_secret_key">Secret Key</label>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-link me-1"></i>
                                            <a href="https://dashboard.stripe.com/apikeys" target="_blank">Get API Keys</a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- PayPal -->
                            <div class="col-lg-4 mb-4">
                                <div class="card border h-100">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0 fw-bold">
                                            <i class="fab fa-paypal text-primary me-2"></i>PayPal
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-outline mb-3">
                                            <input type="text" id="paypal_client_id" name="paypal_client_id" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['paypal_client_id'] ?? ''); ?>">
                                            <label class="form-label" for="paypal_client_id">Client ID</label>
                                        </div>
                                        <div class="form-outline mb-3">
                                            <input type="password" id="paypal_secret" name="paypal_secret" class="form-control" 
                                                   value="<?php echo htmlspecialchars($currentSettings['paypal_secret'] ?? ''); ?>">
                                            <label class="form-label" for="paypal_secret">Secret</label>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-link me-1"></i>
                                            <a href="https://developer.paypal.com/" target="_blank">Get API Credentials</a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Security Notice:</strong> Keep your API keys secure and never share them publicly.
                            Use test keys during development and switch to live keys only in production.
                        </div>
                    </div>
                    
                </div>
                
                <!-- Save Button -->
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            <i class="fas fa-shield-alt me-1"></i>
                            All settings are securely stored in the database
                        </small>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-save me-2"></i>Save All Settings
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function sendTestEmail() {
    const testEmail = document.getElementById('test_email').value;
    const resultDiv = document.getElementById('testEmailResult');
    
    if (!testEmail) {
        resultDiv.innerHTML = '<div class="alert alert-danger"><i class="fas fa-times me-2"></i>Please enter an email address</div>';
        return;
    }
    
    resultDiv.innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin me-2"></i>Sending test email...</div>';
    
    fetch('test-email.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: testEmail })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            resultDiv.innerHTML = '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>' + data.message + '</div>';
        } else {
            resultDiv.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-circle me-2"></i>' + data.message + '</div>';
        }
    })
    .catch(error => {
        resultDiv.innerHTML = '<div class="alert alert-danger"><i class="fas fa-times me-2"></i>Error sending test email</div>';
    });
}

// Favicon preview before upload
document.getElementById('favicon')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const preview = document.querySelector('.bg-light img');
            if (preview) {
                preview.src = event.target.result;
            }
        };
        reader.readAsDataURL(file);
        
        // Update file name display
        const fileName = document.querySelector('.bg-light strong');
        if (fileName) {
            fileName.textContent = file.name;
        }
    }
});

// Meta description character counter
document.addEventListener('DOMContentLoaded', function() {
    const metaDescField = document.getElementById('site_meta_description');
    const charCountSpan = document.getElementById('meta-char-count');
    
    if (metaDescField && charCountSpan) {
        // Update counter on page load
        charCountSpan.textContent = metaDescField.value.length;
        
        // Update counter on input
        metaDescField.addEventListener('input', function() {
            const currentLength = this.value.length;
            charCountSpan.textContent = currentLength;
            
            // Change color based on character count
            if (currentLength > 160) {
                charCountSpan.style.color = '#dc3545'; // Red
                charCountSpan.parentElement.classList.add('text-danger');
                charCountSpan.parentElement.classList.remove('text-muted', 'text-warning');
            } else if (currentLength > 140) {
                charCountSpan.style.color = '#fd7e14'; // Orange
                charCountSpan.parentElement.classList.add('text-warning');
                charCountSpan.parentElement.classList.remove('text-muted', 'text-danger');
            } else {
                charCountSpan.style.color = '#6c757d'; // Gray
                charCountSpan.parentElement.classList.add('text-muted');
                charCountSpan.parentElement.classList.remove('text-warning', 'text-danger');
            }
        });
    }
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>