<?php
$pageTitle = "Add Landing Page";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

// Ensure landing_pages table exists
$tableCheck = $db->query("SHOW TABLES LIKE 'landing_pages'");
if ($tableCheck && $tableCheck->num_rows === 0) {
    $createSql = "CREATE TABLE IF NOT EXISTS landing_pages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) UNIQUE NOT NULL,
        meta_description VARCHAR(160) DEFAULT NULL,
        hero_title VARCHAR(255) DEFAULT NULL,
        hero_subtitle VARCHAR(255) DEFAULT NULL,
        hero_button_text VARCHAR(100) DEFAULT NULL,
        hero_button_url VARCHAR(255) DEFAULT NULL,
        hero_image VARCHAR(255) DEFAULT NULL,
        content LONGTEXT,
        status ENUM('draft','published') NOT NULL DEFAULT 'draft',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $db->query($createSql);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title'] ?? '');
    $customSlug = sanitizeInput($_POST['slug'] ?? '');
    $metaDescription = sanitizeInput($_POST['meta_description'] ?? '');
    $heroTitle = sanitizeInput($_POST['hero_title'] ?? '');
    $heroSubtitle = sanitizeInput($_POST['hero_subtitle'] ?? '');
    $heroButtonText = sanitizeInput($_POST['hero_button_text'] ?? '');
    $heroButtonUrl = sanitizeInput($_POST['hero_button_url'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? 'draft');
    $content = $_POST['content'] ?? '';

    if (empty($title)) {
        $error = 'Title is required';
    } else {
        // Generate or sanitize slug
        if (!empty($customSlug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $customSlug)));
        } else {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        }

        // Ensure uploads/landing directory exists
        $landingDir = UPLOADS_PATH . '/landing';
        if (!is_dir($landingDir)) {
            @mkdir($landingDir, 0777, true);
        }

        // Handle hero image upload (file input)
        $heroImage = '';
        if (isset($_FILES['hero_image_file']) && $_FILES['hero_image_file']['error'] === UPLOAD_ERR_OK) {
            $allowedImageTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
            $type = $_FILES['hero_image_file']['type'];
            if (isset($allowedImageTypes[$type])) {
                $ext = $allowedImageTypes[$type];
                $fileName = time() . '_' . preg_replace('/\s+/', '_', basename($_FILES['hero_image_file']['name']));
                $targetPath = $landingDir . '/' . $fileName;
                if (move_uploaded_file($_FILES['hero_image_file']['tmp_name'], $targetPath)) {
                    $heroImage = $fileName;
                }
            }
        }

        // Validate slug uniqueness
        $stmt = $db->prepare("SELECT id FROM landing_pages WHERE slug = ?");
        $stmt->bind_param("s", $slug);
        $stmt->execute();
        $existsResult = $stmt->get_result();
        if ($existsResult && $existsResult->num_rows > 0) {
            $error = 'Slug already exists. Please choose a different slug.';
        } else {
            // Insert landing page
            $sql = "INSERT INTO landing_pages (title, slug, meta_description, hero_title, hero_subtitle, hero_button_text, hero_button_url, hero_image, content, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->bind_param(
                "ssssssssss",
                $title,
                $slug,
                $metaDescription,
                $heroTitle,
                $heroSubtitle,
                $heroButtonText,
                $heroButtonUrl,
                $heroImage,
                $content,
                $status
            );

            if ($stmt->execute()) {
                $success = 'Landing page created successfully!';
                echo "<script>setTimeout(function(){ window.location.href = '" . ADMIN_URL . "/add-landing.php?added=1'; }, 1200);</script>";
            } else {
                $error = 'Failed to create landing page: ' . $stmt->error;
            }
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-flag me-2"></i>Create Landing Page</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="title" name="title" class="form-control" required>
                                    <label class="form-label" for="title">Page Title *</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="slug" name="slug" class="form-control">
                                    <label class="form-label" for="slug">Permalink (Slug)</label>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-link me-1"></i>URL: <?php echo SITE_URL; ?>/pages/<span id="slug-preview">your-slug</span>
                                </small>
                            </div>
                        </div>

                        <div class="mb-4">
                            <div class="form-outline">
                                <textarea id="meta_description" name="meta_description" class="form-control" rows="2" maxlength="160" placeholder="Meta description (max 160 characters)"></textarea>
                                <label class="form-label" for="meta_description">Meta Description</label>
                            </div>
                            <small class="text-muted"><span id="meta-char-count">0</span>/160</small>
                        </div>

                        <div class="card mb-4 border">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-bullhorn me-2"></i>Hero Section</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-4">
                                        <div class="form-outline">
                                            <input type="text" id="hero_title" name="hero_title" class="form-control">
                                            <label class="form-label" for="hero_title">Headline</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-4">
                                        <div class="form-outline">
                                            <input type="text" id="hero_subtitle" name="hero_subtitle" class="form-control">
                                            <label class="form-label" for="hero_subtitle">Subheadline</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mb-4">
                                        <div class="form-outline">
                                            <input type="text" id="hero_button_text" name="hero_button_text" class="form-control" placeholder="e.g., Get Started">
                                            <label class="form-label" for="hero_button_text">Button Text</label>
                                        </div>
                                    </div>
                                    <div class="col-md-8 mb-4">
                                        <div class="form-outline">
                                            <input type="url" id="hero_button_url" name="hero_button_url" class="form-control" placeholder="https://example.com/signup">
                                            <label class="form-label" for="hero_button_url">Button URL</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="hero_image_file"><i class="fas fa-image me-2"></i>Hero Image</label>
                                    <input type="file" id="hero_image_file" name="hero_image_file" class="form-control" accept="image/*">
                                    <small class="text-muted">Recommended size: 1600x900px</small>
                                </div>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label" for="content">Page Content</label>
                            <textarea id="content" name="content" class="form-control" rows="12" placeholder="Add rich HTML content for your landing page..."></textarea>
                            <small class="text-muted">You can use HTML for sections, features, testimonials, etc.</small>
                        </div>

                        <div class="row">
                            <div class="col-md-3 mb-4">
                                <label class="form-label" for="status">Status</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="draft">Draft</option>
                                    <option value="published">Published</option>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save me-2"></i>Create Page
                            </button>
                            <a href="<?php echo ADMIN_URL; ?>" class="btn btn-secondary btn-lg">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Generate slug from string
function generateSlug(text) {
    return text
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9-]+/g, '-')
        .replace(/^-+|-+$/g, '');
}

function updateSlugPreview() {
    const slugInput = document.getElementById('slug');
    const slugPreview = document.getElementById('slug-preview');
    const titleInput = document.getElementById('title');
    let slug = slugInput.value;
    if (!slug && titleInput.value) {
        slug = generateSlug(titleInput.value);
    }
    slugPreview.textContent = slug || 'your-slug';
}

// Meta desc char count
function updateMetaCount() {
    const ta = document.getElementById('meta_description');
    const cnt = document.getElementById('meta-char-count');
    if (ta && cnt) cnt.textContent = ta.value.length;
}

document.addEventListener('DOMContentLoaded', function() {
    const slugInput = document.getElementById('slug');
    const titleInput = document.getElementById('title');
    let manuallyEdited = false;

    if (slugInput) {
        slugInput.addEventListener('input', function() {
            manuallyEdited = true;
            updateSlugPreview();
        });
    }
    if (titleInput) {
        titleInput.addEventListener('input', function() {
            if (!manuallyEdited) {
                const generatedSlug = generateSlug(titleInput.value);
                slugInput.value = generatedSlug;
                updateSlugPreview();
            }
        });
    }

    const meta = document.getElementById('meta_description');
    if (meta) meta.addEventListener('input', updateMetaCount);
    updateMetaCount();
    updateSlugPreview();
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>
