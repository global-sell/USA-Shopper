<?php
// Maintenance Mode Check
// Include this at the top of pages that should respect maintenance mode

require_once __DIR__ . '/../config/config.php';

// Check if maintenance mode is enabled
$maintenanceMode = getSetting('maintenance_mode', 0);

// If maintenance mode is enabled and user is not admin, show maintenance page
if ($maintenanceMode && !isAdmin()) {
    $maintenanceMessage = getSetting('maintenance_message', 'We are currently performing scheduled maintenance. Please check back soon!');
    $siteName = getSetting('site_name', 'Website');
    
    http_response_code(503); // Service Temporarily Unavailable
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Maintenance Mode - <?php echo htmlspecialchars($siteName); ?></title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: 'Inter', sans-serif;
            }
            .maintenance-card {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
                max-width: 500px;
                width: 90%;
                padding: 3rem 2rem;
                text-align: center;
            }
            .maintenance-icon {
                font-size: 4rem;
                color: #667eea;
                margin-bottom: 1.5rem;
                animation: pulse 2s infinite;
            }
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.1); }
                100% { transform: scale(1); }
            }
            .maintenance-title {
                font-size: 2rem;
                font-weight: 700;
                color: #333;
                margin-bottom: 1rem;
            }
            .maintenance-message {
                font-size: 1.1rem;
                color: #666;
                line-height: 1.6;
                margin-bottom: 2rem;
            }
            .maintenance-footer {
                font-size: 0.9rem;
                color: #999;
            }
        </style>
    </head>
    <body>
        <div class="maintenance-card">
            <div class="maintenance-icon">
                <i class="fas fa-tools"></i>
            </div>
            <h1 class="maintenance-title">Under Maintenance</h1>
            <p class="maintenance-message">
                <?php echo nl2br(htmlspecialchars($maintenanceMessage)); ?>
            </p>
            <div class="maintenance-footer">
                <p><strong><?php echo htmlspecialchars($siteName); ?></strong></p>
                <p><i class="fas fa-clock me-1"></i> We'll be back soon!</p>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>
