<?php
session_start();
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(SITE_URL . '/signup.php');
}

$provider = sanitizeInput($_POST['provider'] ?? '');
$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');

if (empty($name) || empty($email) || !validateEmail($email)) {
    redirect(SITE_URL . '/auth/social-demo.php?provider=' . $provider . '&error=invalid_data');
}

$db = Database::getInstance();

// Check if user exists
$stmt = $db->prepare("SELECT id, name, email, role, status FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    // User exists, log them in
    if ($user['status'] === 'blocked') {
        redirect(SITE_URL . '/login.php?error=account_blocked');
    }
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['last_activity'] = time();
    
    redirect(SITE_URL . '?welcome_back=1');
} else {
    // Check if oauth columns exist
    $columns = $db->query("SHOW COLUMNS FROM users LIKE 'oauth_provider'")->num_rows;
    
    if ($columns == 0) {
        // Add OAuth columns
        $db->query("ALTER TABLE users ADD COLUMN oauth_provider VARCHAR(50) NULL AFTER password");
        $db->query("ALTER TABLE users ADD COLUMN oauth_id VARCHAR(255) NULL AFTER oauth_provider");
    }
    
    // Create new user
    $randomPassword = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
    $oauthId = $provider . '_' . md5($email);
    
    $stmt = $db->prepare("INSERT INTO users (name, email, password, role, oauth_provider, oauth_id) VALUES (?, ?, ?, 'user', ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $randomPassword, $provider, $oauthId);
    
    if ($stmt->execute()) {
        $userId = $db->getConnection()->insert_id;
        
        // Log them in
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['role'] = 'user';
        $_SESSION['last_activity'] = time();
        
        // Send welcome email
        $subject = "Welcome to " . getSetting('site_name', 'YBT Digital');
        $message = "
            <h2>Welcome to " . getSetting('site_name', 'YBT Digital') . "!</h2>
            <p>Hi $name,</p>
            <p>Thank you for signing up with " . ucfirst($provider) . ". You can now start exploring our products.</p>
            <p>Best regards,<br>" . getSetting('site_name', 'YBT Digital') . " Team</p>
        ";
        sendEmail($email, $subject, $message);
        
        redirect(SITE_URL . '?welcome=1&provider=' . $provider);
    } else {
        redirect(SITE_URL . '/signup.php?error=registration_failed');
    }
}
?>
