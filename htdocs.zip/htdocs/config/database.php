<?php
// Database credentials (InfinityFree)
define('DB_HOST', 'sql307.infinityfree.com');
define('DB_USER', 'if0_39879936');
define('DB_PASS', 'Surjo253692');
define('DB_NAME', 'if0_39879936_ybt_digital');

// Create database connection
function getDBConnection() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (Exception $e) {
        error_log($e->getMessage());
        die("Database connection failed. Please try again later.");
    }
}

// Get single database instance (singleton pattern)
class Database {
    private static $instance = null;
    private $conn;
    
    private function __construct() {
        $this->conn = getDBConnection();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    public function query($sql) {
        return $this->conn->query($sql);
    }
    
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }
    
    public function escape($value) {
        return $this->conn->real_escape_string($value);
    }
    
    public function lastInsertId() {
        return $this->conn->insert_id;
    }
}
?>
