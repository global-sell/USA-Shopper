<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$email = sanitizeInput($_POST['email'] ?? '');
$name = sanitizeInput($_POST['name'] ?? '');

// Validate email
if (empty($email)) {
    echo json_encode(['success' => false, 'message' => 'Email is required']);
    exit;
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

$db = Database::getInstance();

// Check if table exists
$tableCheck = $db->query("SHOW TABLES LIKE 'newsletter_subscribers'");
if ($tableCheck->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Newsletter system is not set up yet. Please contact administrator.']);
    exit;
}

// Check if email already exists
$stmt = $db->prepare("SELECT id, status FROM newsletter_subscribers WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $subscriber = $result->fetch_assoc();
    
    if ($subscriber['status'] === 'active') {
        echo json_encode(['success' => false, 'message' => 'This email is already subscribed to our newsletter']);
        exit;
    } else {
        // Reactivate subscription
        $stmt = $db->prepare("UPDATE newsletter_subscribers SET status = 'active', name = ?, subscribed_at = NOW(), unsubscribed_at = NULL WHERE email = ?");
        $stmt->bind_param("ss", $name, $email);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Welcome back! Your subscription has been reactivated.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to reactivate subscription']);
        }
        exit;
    }
}

// Add new subscriber
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
$stmt = $db->prepare("INSERT INTO newsletter_subscribers (email, name, ip_address) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $name, $ipAddress);

if ($stmt->execute()) {
    // Send welcome email
    $subject = "Welcome to Our Newsletter!";
    $message = "
        <h2>Thank you for subscribing!</h2>
        <p>Hi" . (!empty($name) ? " " . htmlspecialchars($name) : "") . ",</p>
        <p>You've successfully subscribed to our newsletter. You'll now receive updates on:</p>
        <ul>
            <li>New product launches</li>
            <li>Exclusive deals and discounts</li>
            <li>Shopping tips and guides</li>
            <li>Special promotions</li>
        </ul>
        <p>We promise not to spam you. You can unsubscribe at any time.</p>
        <p>Best regards,<br>The Team</p>
        <hr>
        <p style='font-size: 12px; color: #666;'>
            If you didn't subscribe to this newsletter, please ignore this email.
        </p>
    ";
    
    sendEmail($email, $subject, $message);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Thank you for subscribing! Check your email for confirmation.'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to subscribe. Please try again.']);
}
?>
