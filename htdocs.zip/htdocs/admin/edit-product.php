<?php
$pageTitle = "Edit Product";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

// Get product ID
$productId = (int)($_GET['id'] ?? 0);

if ($productId <= 0) {
    redirect(ADMIN_URL . '/products.php');
}

// Get product details
$stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $productId);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    redirect(ADMIN_URL . '/products.php');
}

// Get categories
$categories = $db->query("SELECT * FROM categories WHERE status = 'active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $sku = sanitizeInput($_POST['sku'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $regularPrice = !empty($_POST['regular_price']) ? (float)$_POST['regular_price'] : null;
    $salePrice = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : null;
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $categoryId = $categoryId > 0 ? $categoryId : null;
    $demoUrl = sanitizeInput($_POST['demo_url'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? 'active');
    $productType = sanitizeInput($_POST['product_type'] ?? 'simple');
    $externalUrl = sanitizeInput($_POST['external_url'] ?? '');
    $affiliateLink = sanitizeInput($_POST['affiliate_link'] ?? '');
    $buttonText = sanitizeInput($_POST['button_text'] ?? 'Buy Now');
    $stockQuantity = (int)($_POST['stock_quantity'] ?? 0);
    $sold = (int)($_POST['sold'] ?? 0);
    $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
    
    if (empty($title) || empty($description) || $price <= 0) {
        $error = 'Please fill in all required fields';
    } else {
        // Get custom slug or generate from title
        $customSlug = sanitizeInput($_POST['slug'] ?? '');
        if (!empty($customSlug)) {
            // Use custom slug and sanitize it
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $customSlug)));
        } else {
            // Auto-generate slug from title
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        }
        
        // Handle file upload
        $filePath = $product['file_path'];
        if (isset($_FILES['product_file']) && $_FILES['product_file']['error'] === UPLOAD_ERR_OK) {
            // Delete old file
            if (!empty($filePath) && file_exists(PRODUCTS_PATH . '/' . $filePath)) {
                unlink(PRODUCTS_PATH . '/' . $filePath);
            }
            
            $fileName = time() . '_' . basename($_FILES['product_file']['name']);
            $targetPath = PRODUCTS_PATH . '/' . $fileName;
            
            if (move_uploaded_file($_FILES['product_file']['tmp_name'], $targetPath)) {
                $filePath = $fileName;
            }
        }
        
        // Handle screenshots upload
        $screenshots = json_decode($product['screenshots'], true) ?? [];
        if (isset($_FILES['screenshots']) && !empty($_FILES['screenshots']['name'][0])) {
            foreach ($_FILES['screenshots']['tmp_name'] as $key => $tmpName) {
                if ($_FILES['screenshots']['error'][$key] === UPLOAD_ERR_OK) {
                    $fileName = time() . '_' . $key . '_' . basename($_FILES['screenshots']['name'][$key]);
                    $targetPath = SCREENSHOTS_PATH . '/' . $fileName;
                    
                    if (move_uploaded_file($tmpName, $targetPath)) {
                        $screenshots[] = $fileName;
                    }
                }
            }
        }
        
        $screenshotsJson = json_encode($screenshots);
        
        // Update product
        try {
            $sql = "UPDATE products SET 
                    title = ?, slug = ?, sku = ?, description = ?, 
                    price = ?, regular_price = ?, sale_price = ?, 
                    category_id = ?, file_path = ?, demo_url = ?, 
                    screenshots = ?, status = ?, product_type = ?, 
                    external_url = ?, affiliate_link = ?, button_text = ?, 
                    stock_quantity = ?, sold = ?, is_featured = ?
                    WHERE id = ?";
            
            $stmt = $db->prepare($sql);
            // Type string: 20 parameters (19 fields + 1 WHERE id)
            // s s s s  d   d   d   i    s    s    s      s    s     s      s       s     i      i    i      i
            // 1 2 3 4  5   6   7   8    9   10   11     12   13    14     15      16    17     18   19     20
            $stmt->bind_param("ssssdddiisssssssiiii", 
                $title,           // 1  - string
                $slug,            // 2  - string
                $sku,             // 3  - string
                $description,     // 4  - string
                $price,           // 5  - double
                $regularPrice,    // 6  - double
                $salePrice,       // 7  - double
                $categoryId,      // 8  - integer
                $filePath,        // 9  - string
                $demoUrl,         // 10 - string
                $screenshotsJson, // 11 - string
                $status,          // 12 - string
                $productType,     // 13 - string
                $externalUrl,     // 14 - string
                $affiliateLink,   // 15 - string
                $buttonText,      // 16 - string
                $stockQuantity,   // 17 - integer
                $sold,            // 18 - integer
                $isFeatured,      // 19 - integer
                $productId        // 20 - integer (WHERE clause)
            );
            
            if ($stmt->execute()) {
                $success = 'Product updated successfully!';
                // Refresh product data
                $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
                $stmt->bind_param("i", $productId);
                $stmt->execute();
                $product = $stmt->get_result()->fetch_assoc();
            } else {
                $error = 'Failed to update product: ' . $stmt->error;
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Decode screenshots for display
$existingScreenshots = json_decode($product['screenshots'], true) ?? [];
?>

<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Product</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <!-- Product Type Selection -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Product Type *</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="product_type" id="type_simple" value="simple" 
                                               <?php echo $product['product_type'] === 'simple' ? 'checked' : ''; ?> onchange="toggleProductType()">
                                        <label class="form-check-label" for="type_simple">
                                            <i class="fas fa-box me-1"></i>Simple Product
                                            <small class="d-block text-muted">Regular downloadable product</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="product_type" id="type_external" value="external" 
                                               <?php echo $product['product_type'] === 'external' ? 'checked' : ''; ?> onchange="toggleProductType()">
                                        <label class="form-check-label" for="type_external">
                                            <i class="fas fa-external-link-alt me-1"></i>External Product
                                            <small class="d-block text-muted">Link to external site</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="product_type" id="type_affiliate" value="affiliate" 
                                               <?php echo $product['product_type'] === 'affiliate' ? 'checked' : ''; ?> onchange="toggleProductType()">
                                        <label class="form-check-label" for="type_affiliate">
                                            <i class="fas fa-handshake me-1"></i>Affiliate Product
                                            <small class="d-block text-muted">Affiliate/referral link</small>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="title" name="title" class="form-control" 
                                           value="<?php echo htmlspecialchars($product['title']); ?>" required>
                                    <label class="form-label" for="title">Product Title *</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="slug" name="slug" class="form-control" 
                                           value="<?php echo htmlspecialchars($product['slug']); ?>">
                                    <label class="form-label" for="slug">Permalink (Slug)</label>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-link me-1"></i>URL: <?php echo SITE_URL; ?>/<span id="slug-preview"><?php echo htmlspecialchars($product['slug']); ?></span>
                                </small>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="sku" name="sku" class="form-control" 
                                           value="<?php echo htmlspecialchars($product['sku'] ?? ''); ?>">
                                    <label class="form-label" for="sku">SKU (optional)</label>
                                </div>
                            </div>
                            
                            <div class="col-md-3 mb-4">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured" 
                                           <?php echo $product['is_featured'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="is_featured">
                                        <i class="fas fa-star text-warning me-1"></i>Featured Product
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="description">Description *</label>
                            <textarea id="description" name="description" class="form-control" rows="5" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                        </div>

                        <?php // SEO checker include for admins ?>
                        <?php
                        $seoPath = __DIR__ . '/includes/seo-checker.php';
                        if (file_exists($seoPath)) {
                            require_once $seoPath;
                        }
                        ?>
                        
                        <!-- Pricing Section -->
                        <div class="card mb-4 border">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-dollar-sign me-2"></i>Pricing</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="form-outline">
                                            <input type="number" id="regular_price" name="regular_price" class="form-control" 
                                                   step="0.01" min="0" value="<?php echo $product['regular_price'] ?? ''; ?>">
                                            <label class="form-label" for="regular_price">Regular Price (<?php echo getSetting('currency_symbol', '$'); ?>)</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-outline">
                                            <input type="number" id="sale_price" name="sale_price" class="form-control" 
                                                   step="0.01" min="0" value="<?php echo $product['sale_price'] ?? ''; ?>">
                                            <label class="form-label" for="sale_price">Sale Price (<?php echo getSetting('currency_symbol', '$'); ?>)</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-outline">
                                            <input type="number" id="price" name="price" class="form-control" 
                                                   step="0.01" min="0" value="<?php echo $product['price']; ?>" required>
                                            <label class="form-label" for="price">Final Price (<?php echo getSetting('currency_symbol', '$'); ?>) *</label>
                                        </div>
                                    </div>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    If sale price is set, it will be displayed with a strikethrough on regular price
                                </small>
                            </div>
                        </div>
                        
                        <!-- External/Affiliate Section -->
                        <div class="card mb-4 border" id="external_section" style="display: none;">
                            <div class="card-header bg-warning text-dark">
                                <h6 class="mb-0"><i class="fas fa-link me-2"></i>External/Affiliate Settings</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <div class="form-outline">
                                        <input type="url" id="external_url" name="external_url" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['external_url'] ?? ''); ?>">
                                        <label class="form-label" for="external_url">External Product URL</label>
                                    </div>
                                    <small class="text-muted">Direct link to the product page</small>
                                </div>
                                <div class="mb-3">
                                    <div class="form-outline">
                                        <input type="url" id="affiliate_link" name="affiliate_link" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['affiliate_link'] ?? ''); ?>">
                                        <label class="form-label" for="affiliate_link">Affiliate Link (optional)</label>
                                    </div>
                                    <small class="text-muted">Your affiliate/referral link with tracking code</small>
                                </div>
                                <div class="mb-3">
                                    <div class="form-outline">
                                        <input type="text" id="button_text" name="button_text" class="form-control" 
                                               value="<?php echo htmlspecialchars($product['button_text'] ?? 'Buy Now'); ?>">
                                        <label class="form-label" for="button_text">Button Text</label>
                                    </div>
                                    <small class="text-muted">Text to display on the purchase button (e.g., "Buy on Amazon", "Get Deal")</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-4">
                                <label class="form-label" for="category_id">Category</label>
                                <select id="category_id" name="category_id" class="form-select">
                                    <option value="0">No Category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                                <?php echo $product['category_id'] == $category['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-4">
                                <label class="form-label" for="status">Status</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="active" <?php echo $product['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $product['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-4" id="stock_field">
                                <div class="form-outline">
                                    <input type="number" id="stock_quantity" name="stock_quantity" class="form-control" 
                                           value="<?php echo $product['stock_quantity'] ?? 0; ?>" min="0">
                                    <label class="form-label" for="stock_quantity">Stock Quantity</label>
                                </div>
                            </div>
                            
                            <div class="col-md-3 mb-4">
                                <div class="form-outline">
                                    <input type="number" id="sold" name="sold" class="form-control" 
                                           value="<?php echo $product['sold'] ?? 0; ?>" min="0">
                                    <label class="form-label" for="sold">
                                        <i class="fas fa-shopping-bag me-1"></i>Sold Items
                                    </label>
                                </div>
                                <small class="text-muted">Update sold count</small>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <div class="form-outline">
                                <input type="url" id="demo_url" name="demo_url" class="form-control" 
                                       value="<?php echo htmlspecialchars($product['demo_url'] ?? ''); ?>">
                                <label class="form-label" for="demo_url">Demo URL (optional)</label>
                            </div>
                        </div>
                        
                        <div class="mb-4" id="file_upload_section">
                            <label class="form-label" for="product_file">
                                <i class="fas fa-file-upload me-2"></i>Product File
                            </label>
                            <?php if (!empty($product['file_path'])): ?>
                                <div class="alert alert-info mb-2">
                                    <i class="fas fa-file me-2"></i>Current file: <strong><?php echo htmlspecialchars($product['file_path']); ?></strong>
                                </div>
                            <?php endif; ?>
                            <input type="file" id="product_file" name="product_file" class="form-control">
                            <small class="text-muted">Upload a new file to replace the existing one (ZIP, PDF, etc.)</small>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="screenshots">
                                <i class="fas fa-images me-2"></i>Product Images/Screenshots
                            </label>
                            <?php if (!empty($existingScreenshots)): ?>
                                <div class="row mb-3">
                                    <?php foreach ($existingScreenshots as $screenshot): ?>
                                        <div class="col-md-2 mb-2">
                                            <img src="<?php echo UPLOADS_URL; ?>/screenshots/<?php echo $screenshot; ?>" 
                                                 class="img-thumbnail" alt="Screenshot">
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <input type="file" id="screenshots" name="screenshots[]" class="form-control" 
                                   multiple accept="image/*">
                            <small class="text-muted">Upload additional images (will be added to existing ones)</small>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save me-2"></i>Update Product
                            </button>
                            <a href="<?php echo ADMIN_URL; ?>/products.php" class="btn btn-secondary btn-lg">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                            <a href="<?php echo SITE_URL; ?>/<?php echo $product['slug']; ?>" 
                               class="btn btn-info btn-lg ms-auto" target="_blank">
                                <i class="fas fa-eye me-2"></i>View Product
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleProductType() {
    const productType = document.querySelector('input[name="product_type"]:checked').value;
    const externalSection = document.getElementById('external_section');
    const fileUploadSection = document.getElementById('file_upload_section');
    const stockField = document.getElementById('stock_field');
    
    if (productType === 'external' || productType === 'affiliate') {
        externalSection.style.display = 'block';
        fileUploadSection.style.display = 'none';
        stockField.style.display = 'none';
    } else {
        externalSection.style.display = 'none';
        fileUploadSection.style.display = 'block';
        stockField.style.display = 'block';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    toggleProductType();
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>
