<?php
$pageTitle = "Manage Orders";
require_once 'includes/admin-header.php';

$db = Database::getInstance();

// Handle status update
if (isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $status = sanitizeInput($_POST['status']);
    
    $db->query("UPDATE orders SET payment_status = '$status' WHERE id = $orderId");
    redirect(ADMIN_URL . '/orders.php?updated=1');
}

// Get all orders
$orders = $db->query("SELECT o.*, u.name as user_name, u.email as user_email 
                     FROM orders o 
                     JOIN users u ON o.user_id = u.id 
                     ORDER BY o.created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">
        <i class="fas fa-shopping-cart me-2"></i>Manage Orders
    </h2>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Order status updated successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <?php
                            // Get order items count
                            $itemsCount = $db->query("SELECT COUNT(*) as count FROM order_items WHERE order_id = " . $order['id'])->fetch_assoc()['count'];
                            
                            $statusClass = match($order['payment_status']) {
                                'completed' => 'success',
                                'pending' => 'warning',
                                'failed' => 'danger',
                                'refunded' => 'info',
                                default => 'secondary'
                            };
                            ?>
                            <tr>
                                <td class="fw-bold"><?php echo htmlspecialchars($order['order_number']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($order['user_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($order['user_email']); ?></small>
                                </td>
                                <td><?php echo $itemsCount; ?> item(s)</td>
                                <td class="fw-bold text-primary"><?php echo formatPrice($order['final_amount']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                        <?php echo ucfirst($order['payment_status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($order['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-mdb-toggle="modal" 
                                            data-mdb-target="#orderModal<?php echo $order['id']; ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                </td>
                            </tr>
                            
                            <!-- Order Details Modal -->
                            <div class="modal fade" id="orderModal<?php echo $order['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title">Order Details - <?php echo htmlspecialchars($order['order_number']); ?></h5>
                                            <button type="button" class="btn-close btn-close-white" data-mdb-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php
                                            // Get order items
                                            $orderItems = $db->query("SELECT * FROM order_items WHERE order_id = " . $order['id'])->fetch_all(MYSQLI_ASSOC);
                                            ?>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <h6 class="fw-bold">Customer Information</h6>
                                                    <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($order['user_name']); ?></p>
                                                    <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($order['user_email']); ?></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6 class="fw-bold">Order Information</h6>
                                                    <p class="mb-1"><strong>Date:</strong> <?php echo date('M j, Y g:i A', strtotime($order['created_at'])); ?></p>
                                                    <p class="mb-1"><strong>Payment Method:</strong> <?php echo ucfirst($order['payment_method']); ?></p>
                                                    <?php if ($order['transaction_id']): ?>
                                                        <p class="mb-1"><strong>Transaction ID:</strong> <?php echo htmlspecialchars($order['transaction_id']); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <h6 class="fw-bold mb-3">Order Items</h6>
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>Product</th>
                                                        <th class="text-end">Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($orderItems as $item): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($item['product_title']); ?></td>
                                                            <td class="text-end"><?php echo formatPrice($item['price']); ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td><strong>Subtotal</strong></td>
                                                        <td class="text-end"><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                                    </tr>
                                                    <?php if ($order['discount_amount'] > 0): ?>
                                                        <tr class="text-success">
                                                            <td>Discount <?php echo $order['coupon_code'] ? '(' . htmlspecialchars($order['coupon_code']) . ')' : ''; ?></td>
                                                            <td class="text-end">-<?php echo formatPrice($order['discount_amount']); ?></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                    <tr>
                                                        <td>Tax</td>
                                                        <td class="text-end"><?php echo formatPrice($order['tax_amount']); ?></td>
                                                    </tr>
                                                    <tr class="table-primary">
                                                        <td><strong>Total</strong></td>
                                                        <td class="text-end"><strong><?php echo formatPrice($order['final_amount']); ?></strong></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                            
                                            <h6 class="fw-bold mb-3">Update Status</h6>
                                            <form method="POST">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <select name="status" class="form-select">
                                                            <option value="pending" <?php echo $order['payment_status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                            <option value="completed" <?php echo $order['payment_status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                            <option value="failed" <?php echo $order['payment_status'] === 'failed' ? 'selected' : ''; ?>>Failed</option>
                                                            <option value="refunded" <?php echo $order['payment_status'] === 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <button type="submit" name="update_status" class="btn btn-primary w-100">
                                                            Update
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
