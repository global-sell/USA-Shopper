<?php
$pageTitle = "Newsletter Subscribers";
require_once 'includes/admin-header.php';

$db = Database::getInstance();

// Handle unsubscribe
if (isset($_GET['unsubscribe'])) {
    $id = (int)$_GET['unsubscribe'];
    $stmt = $db->prepare("UPDATE newsletter_subscribers SET status = 'unsubscribed', unsubscribed_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    redirect(ADMIN_URL . '/newsletter.php?updated=1');
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $db->prepare("DELETE FROM newsletter_subscribers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    redirect(ADMIN_URL . '/newsletter.php?deleted=1');
}

// Get filter
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$query = "SELECT * FROM newsletter_subscribers WHERE 1=1";

if ($filter === 'active') {
    $query .= " AND status = 'active'";
} elseif ($filter === 'unsubscribed') {
    $query .= " AND status = 'unsubscribed'";
}

if (!empty($search)) {
    $query .= " AND (email LIKE '%" . $db->getConnection()->real_escape_string($search) . "%' OR name LIKE '%" . $db->getConnection()->real_escape_string($search) . "%')";
}

$query .= " ORDER BY subscribed_at DESC";

$subscribers = $db->query($query)->fetch_all(MYSQLI_ASSOC);

// Get statistics
$stats = $db->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN status = 'unsubscribed' THEN 1 ELSE 0 END) as unsubscribed
    FROM newsletter_subscribers")->fetch_assoc();
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">
            <i class="fas fa-envelope me-2"></i>Newsletter Subscribers
        </h2>
    </div>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Subscriber deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Subscriber updated successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary bg-opacity-10 rounded p-3 me-3">
                            <i class="fas fa-users fa-2x text-primary"></i>
                        </div>
                        <div>
                            <h3 class="fw-bold mb-0"><?php echo $stats['total']; ?></h3>
                            <small class="text-muted">Total Subscribers</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-success bg-opacity-10 rounded p-3 me-3">
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        </div>
                        <div>
                            <h3 class="fw-bold mb-0"><?php echo $stats['active']; ?></h3>
                            <small class="text-muted">Active Subscribers</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="bg-danger bg-opacity-10 rounded p-3 me-3">
                            <i class="fas fa-user-slash fa-2x text-danger"></i>
                        </div>
                        <div>
                            <h3 class="fw-bold mb-0"><?php echo $stats['unsubscribed']; ?></h3>
                            <small class="text-muted">Unsubscribed</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Filters and Search -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <select name="filter" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Subscribers</option>
                        <option value="active" <?php echo $filter === 'active' ? 'selected' : ''; ?>>Active Only</option>
                        <option value="unsubscribed" <?php echo $filter === 'unsubscribed' ? 'selected' : ''; ?>>Unsubscribed Only</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search by email or name..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>Search
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Subscribers Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Subscribed Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($subscribers)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                                    <p class="text-muted">No subscribers found</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($subscribers as $subscriber): ?>
                                <tr>
                                    <td><?php echo $subscriber['id']; ?></td>
                                    <td><?php echo htmlspecialchars($subscriber['email']); ?></td>
                                    <td><?php echo htmlspecialchars($subscriber['name'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($subscriber['status'] === 'active'): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Unsubscribed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($subscriber['subscribed_at'])); ?></td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <?php if ($subscriber['status'] === 'active'): ?>
                                                <a href="?unsubscribe=<?php echo $subscriber['id']; ?>" 
                                                   class="btn btn-warning" 
                                                   onclick="return confirm('Unsubscribe this user?')" 
                                                   title="Unsubscribe">
                                                    <i class="fas fa-user-slash"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="?delete=<?php echo $subscriber['id']; ?>" 
                                               class="btn btn-danger" 
                                               onclick="return confirm('Delete this subscriber?')" 
                                               title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
