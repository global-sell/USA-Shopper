<?php
$pageTitle = "Manage Users";
require_once 'includes/admin-header.php';

$db = Database::getInstance();

// Handle user edit
if (isset($_POST['edit_user'])) {
    $userId = (int)$_POST['user_id'];
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    
    // Validate email
    if (!validateEmail($email)) {
        $error = "Invalid email format";
    } else {
        // Check if email already exists for another user
        $checkEmail = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $checkEmail->bind_param("si", $email, $userId);
        $checkEmail->execute();
        $result = $checkEmail->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Email already exists";
        } else {
            $stmt = $db->prepare("UPDATE users SET name = ?, email = ? WHERE id = ? AND role = 'user'");
            $stmt->bind_param("ssi", $name, $email, $userId);
            if ($stmt->execute()) {
                redirect(ADMIN_URL . '/users.php?updated=1&action=edited');
            } else {
                $error = "Failed to update user";
            }
        }
    }
}

// Handle block/unblock
if (isset($_GET['toggle_status'])) {
    $userId = (int)$_GET['toggle_status'];
    $db->query("UPDATE users SET status = IF(status = 'active', 'blocked', 'active') WHERE id = $userId AND role = 'user'");
    redirect(ADMIN_URL . '/users.php?updated=1&action=status');
}

// Get user statistics
$totalUsers = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'")->fetch_assoc()['count'];
$activeUsers = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user' AND status = 'active'")->fetch_assoc()['count'];
$blockedUsers = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user' AND status = 'blocked'")->fetch_assoc()['count'];
$newUsersThisMonth = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user' AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())")->fetch_assoc()['count'];

// Get all users
$users = $db->query("SELECT u.*, 
                    (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND payment_status = 'completed') as total_orders,
                    (SELECT COALESCE(SUM(final_amount), 0) FROM orders WHERE user_id = u.id AND payment_status = 'completed') as total_spent
                    FROM users u 
                    WHERE u.role = 'user' 
                    ORDER BY u.created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <!-- Modern Header -->
    <div class="card bg-gradient text-white mb-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold mb-2">
                        <i class="fas fa-users me-2"></i>User Management
                    </h2>
                    <p class="mb-0 opacity-90">Manage and monitor all registered users</p>
                </div>
                <div>
                    <i class="fas fa-users-cog" style="font-size: 4rem; opacity: 0.2;"></i>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show" style="border-radius: 10px; border-left: 4px solid #28a745;">
            <i class="fas fa-check-circle me-2"></i><strong>Success!</strong> User status updated successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card text-white border-0" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3); transition: all 0.3s ease;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-uppercase mb-2 opacity-75" style="font-size: 0.75rem; letter-spacing: 1px; font-weight: 600;">Total Users</p>
                            <h2 class="fw-bold mb-1" style="font-size: 2rem;"><?php echo $totalUsers; ?></h2>
                            <small class="opacity-75"><i class="fas fa-users me-1"></i>Registered</small>
                        </div>
                        <div class="bg-white bg-opacity-20 rounded-circle p-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card text-white border-0" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); border-radius: 15px; box-shadow: 0 8px 20px rgba(17, 153, 142, 0.3); transition: all 0.3s ease;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-uppercase mb-2 opacity-75" style="font-size: 0.75rem; letter-spacing: 1px; font-weight: 600;">Active Users</p>
                            <h2 class="fw-bold mb-1" style="font-size: 2rem;"><?php echo $activeUsers; ?></h2>
                            <small class="opacity-75"><i class="fas fa-check-circle me-1"></i>Active status</small>
                        </div>
                        <div class="bg-white bg-opacity-20 rounded-circle p-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card text-white border-0" style="background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%); border-radius: 15px; box-shadow: 0 8px 20px rgba(255, 107, 107, 0.3); transition: all 0.3s ease;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-uppercase mb-2 opacity-75" style="font-size: 0.75rem; letter-spacing: 1px; font-weight: 600;">Blocked Users</p>
                            <h2 class="fw-bold mb-1" style="font-size: 2rem;"><?php echo $blockedUsers; ?></h2>
                            <small class="opacity-75"><i class="fas fa-ban me-1"></i>Blocked</small>
                        </div>
                        <div class="bg-white bg-opacity-20 rounded-circle p-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user-slash fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stat-card text-white border-0" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 15px; box-shadow: 0 8px 20px rgba(240, 147, 251, 0.3); transition: all 0.3s ease;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="text-uppercase mb-2 opacity-75" style="font-size: 0.75rem; letter-spacing: 1px; font-weight: 600;">New This Month</p>
                            <h2 class="fw-bold mb-1" style="font-size: 2rem;"><?php echo $newUsersThisMonth; ?></h2>
                            <small class="opacity-75"><i class="fas fa-user-plus me-1"></i>Joined</small>
                        </div>
                        <div class="bg-white bg-opacity-20 rounded-circle p-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-calendar-plus fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Users Table Card -->
    <div class="card border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
        <div class="card-header text-white d-flex justify-content-between align-items-center" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 1.25rem 1.5rem;">
            <h5 class="mb-0 fw-bold"><i class="fas fa-list me-2"></i>All Users</h5>
            <div class="d-flex gap-2">
                <div class="input-group" style="width: 300px;">
                    <input type="text" id="searchUser" class="form-control" placeholder="Search users..." style="background: rgba(255,255,255,0.9);">
                    <button class="btn btn-light" type="button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Orders</th>
                            <th>Total Spent</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td class="fw-bold"><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo $user['total_orders']; ?></td>
                                <td class="fw-bold text-primary"><?php echo formatPrice($user['total_spent']); ?></td>
                                <td>
                                    <?php if ($user['status'] === 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Blocked</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn btn-info" 
                                                data-mdb-toggle="modal" 
                                                data-mdb-target="#userModal<?php echo $user['id']; ?>"
                                                title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-primary" 
                                                data-mdb-toggle="modal" 
                                                data-mdb-target="#editUserModal<?php echo $user['id']; ?>"
                                                title="Edit User">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?toggle_status=<?php echo $user['id']; ?>" 
                                           class="btn btn-<?php echo $user['status'] === 'active' ? 'warning' : 'success'; ?>" 
                                           title="<?php echo $user['status'] === 'active' ? 'Block' : 'Unblock'; ?>">
                                            <i class="fas fa-<?php echo $user['status'] === 'active' ? 'ban' : 'check'; ?>"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            
                            <!-- User Details Modal -->
                            <div class="modal fade" id="userModal<?php echo $user['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title">User Details - <?php echo htmlspecialchars($user['name']); ?></h5>
                                            <button type="button" class="btn-close btn-close-white" data-mdb-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php
                                            // Get user orders
                                            $userOrders = $db->query("SELECT * FROM orders WHERE user_id = " . $user['id'] . " ORDER BY created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);
                                            ?>
                                            
                                            <div class="row mb-4">
                                                <div class="col-md-6">
                                                    <h6 class="fw-bold">User Information</h6>
                                                    <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                                                    <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                                                    <p class="mb-1"><strong>Status:</strong> 
                                                        <span class="badge bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                            <?php echo ucfirst($user['status']); ?>
                                                        </span>
                                                    </p>
                                                    <p class="mb-1"><strong>Joined:</strong> <?php echo date('M j, Y', strtotime($user['created_at'])); ?></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6 class="fw-bold">Statistics</h6>
                                                    <p class="mb-1"><strong>Total Orders:</strong> <?php echo $user['total_orders']; ?></p>
                                                    <p class="mb-1"><strong>Total Spent:</strong> <?php echo formatPrice($user['total_spent']); ?></p>
                                                </div>
                                            </div>
                                            
                                            <h6 class="fw-bold mb-3">Recent Orders</h6>
                                            <?php if (empty($userOrders)): ?>
                                                <p class="text-muted">No orders yet</p>
                                            <?php else: ?>
                                                <table class="table table-sm">
                                                    <thead>
                                                        <tr>
                                                            <th>Order #</th>
                                                            <th>Amount</th>
                                                            <th>Status</th>
                                                            <th>Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($userOrders as $order): ?>
                                                            <tr>
                                                                <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                                                <td><?php echo formatPrice($order['final_amount']); ?></td>
                                                                <td>
                                                                    <?php
                                                                    $statusClass = match($order['payment_status']) {
                                                                        'completed' => 'success',
                                                                        'pending' => 'warning',
                                                                        'failed' => 'danger',
                                                                        'refunded' => 'info',
                                                                        default => 'secondary'
                                                                    };
                                                                    ?>
                                                                    <span class="badge bg-<?php echo $statusClass; ?>">
                                                                        <?php echo ucfirst($order['payment_status']); ?>
                                                                    </span>
                                                                </td>
                                                                <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Edit User Modal -->
                            <div class="modal fade" id="editUserModal<?php echo $user['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content" style="border-radius: 15px; overflow: hidden; border: none;">
                                        <div class="modal-header text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none;">
                                            <h5 class="modal-title fw-bold">
                                                <i class="fas fa-user-edit me-2"></i>Edit User - <?php echo htmlspecialchars($user['name']); ?>
                                            </h5>
                                            <button type="button" class="btn-close btn-close-white" data-mdb-dismiss="modal"></button>
                                        </div>
                                        <form method="POST" action="">
                                            <div class="modal-body p-4">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                
                                                <div class="mb-4">
                                                    <label for="name<?php echo $user['id']; ?>" class="form-label fw-bold">
                                                        <i class="fas fa-user me-2 text-primary"></i>Full Name
                                                    </label>
                                                    <input type="text" 
                                                           class="form-control form-control-lg" 
                                                           id="name<?php echo $user['id']; ?>" 
                                                           name="name" 
                                                           value="<?php echo htmlspecialchars($user['name']); ?>" 
                                                           required
                                                           style="border-radius: 10px;">
                                                </div>
                                                
                                                <div class="mb-4">
                                                    <label for="email<?php echo $user['id']; ?>" class="form-label fw-bold">
                                                        <i class="fas fa-envelope me-2 text-primary"></i>Email Address
                                                    </label>
                                                    <input type="email" 
                                                           class="form-control form-control-lg" 
                                                           id="email<?php echo $user['id']; ?>" 
                                                           name="email" 
                                                           value="<?php echo htmlspecialchars($user['email']); ?>" 
                                                           required
                                                           style="border-radius: 10px;">
                                                </div>
                                                
                                                <div class="alert alert-info border-0" style="border-radius: 10px; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));">
                                                    <i class="fas fa-info-circle me-2"></i>
                                                    <small><strong>Note:</strong> User ID: <?php echo $user['id']; ?> | Joined: <?php echo date('M j, Y', strtotime($user['created_at'])); ?></small>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0 bg-light">
                                                <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">
                                                    <i class="fas fa-times me-2"></i>Cancel
                                                </button>
                                                <button type="submit" name="edit_user" class="btn btn-primary">
                                                    <i class="fas fa-save me-2"></i>Save Changes
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
/* Card Animations */
.stat-card {
    animation: fadeInUp 0.6s ease-out;
}

.stat-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2) !important;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }

/* Table Row Hover */
.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background-color: #f8f9fa;
    transform: scale(1.01);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Button Animations */
.btn {
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Badge Animations */
.badge {
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Alert Animation */
.alert {
    animation: slideInDown 0.5s ease-out;
}

@keyframes slideInDown {
    from {
        transform: translateY(-100%);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* Search Input Focus */
#searchUser:focus {
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    border-color: #667eea;
}

/* Modal Enhancement */
.modal-content {
    border-radius: 15px;
    border: none;
    overflow: hidden;
}

/* Form Input Styling */
.form-control {
    transition: all 0.3s ease;
}

.form-control:focus {
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    border-color: #667eea;
    transform: translateY(-2px);
}

.form-label {
    color: #495057;
    margin-bottom: 0.5rem;
}

/* Modal Footer Buttons */
.modal-footer .btn {
    padding: 0.625rem 1.5rem;
    border-radius: 8px;
    font-weight: 600;
}

/* Smooth Scrollbar */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: #555;
}
</style>

<script>
// Search Functionality
document.getElementById('searchUser')?.addEventListener('keyup', function() {
    const searchValue = this.value.toLowerCase();
    const tableRows = document.querySelectorAll('.table tbody tr');
    
    tableRows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if (text.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Confirm before blocking/unblocking
document.querySelectorAll('a[href*="toggle_status"]').forEach(link => {
    link.addEventListener('click', function(e) {
        const action = this.querySelector('i').classList.contains('fa-ban') ? 'block' : 'unblock';
        if (!confirm(`Are you sure you want to ${action} this user?`)) {
            e.preventDefault();
        }
    });
});

// Auto-hide alerts after 5 seconds
setTimeout(() => {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        const bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
    });
}, 5000);

// Form validation for edit user
document.querySelectorAll('form[method="POST"]').forEach(form => {
    form.addEventListener('submit', function(e) {
        const nameInput = this.querySelector('input[name="name"]');
        const emailInput = this.querySelector('input[name="email"]');
        
        // Validate name
        if (nameInput && nameInput.value.trim().length < 2) {
            e.preventDefault();
            alert('Name must be at least 2 characters long');
            nameInput.focus();
            return false;
        }
        
        // Validate email format
        if (emailInput) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(emailInput.value)) {
                e.preventDefault();
                alert('Please enter a valid email address');
                emailInput.focus();
                return false;
            }
        }
    });
});

// Real-time email validation
document.querySelectorAll('input[type="email"]').forEach(input => {
    input.addEventListener('blur', function() {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (this.value && !emailRegex.test(this.value)) {
            this.classList.add('is-invalid');
        } else {
            this.classList.remove('is-invalid');
        }
    });
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>
