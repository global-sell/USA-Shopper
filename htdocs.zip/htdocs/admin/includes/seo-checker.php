<?php
// Enhanced SEO checker UI that mimics common plugin panels (snippet preview, score, suggestions)
?>
<style>
/* Local styles for SEO snippet preview and score */
.seo-snippet { padding: 12px; border: 1px solid #e1e1e1; border-radius: 6px; background: #fff; }
.seo-title { color: #1a0dab; font-size: 18px; font-weight: 600; }
.seo-url { color: #006621; font-size: 13px; margin-bottom: 6px; }
.seo-desc { color: #545454; font-size: 13px; }
.seo-score-badge { font-size: 14px; padding: 6px 10px; border-radius: 20px; }
.seo-check-ok { color: #198754; }
.seo-check-bad { color: #dc3545; }
.seo-check-warn { color: #fd7e14; }
</style>

<div class="card mb-4 border">
    <div class="card-header d-flex align-items-center justify-content-between">
        <div><i class="fas fa-search me-2"></i><strong>SEO Checker</strong></div>
        <div>
            <span id="seo_score_badge" class="seo-score-badge bg-secondary text-white">Score: 0</span>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="form-label" for="meta_title">Meta Title</label>
                    <input type="text" id="meta_title" name="meta_title" class="form-control" placeholder="If empty, page title will be used">
                    <div class="form-text">Recommended: 50–60 characters</div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="meta_description">Meta Description</label>
                    <textarea id="meta_description" name="meta_description" class="form-control" rows="3" placeholder="Short description for search engines"></textarea>
                    <div class="form-text">Recommended: 50–160 characters</div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="focus_keyword">Focus Keyword</label>
                    <input type="text" id="focus_keyword" name="focus_keyword" class="form-control" placeholder="e.g., chocolate cake">
                </div>
            </div>

            <div class="col-md-6">
                <label class="form-label">Snippet Preview</label>
                <div class="seo-snippet mb-2">
                    <div class="seo-title" id="snippet_title">Page title preview</div>
                    <div class="seo-url" id="snippet_url"><?php echo SITE_URL; ?>/</div>
                    <div class="seo-desc" id="snippet_description">Meta description preview will appear here.</div>
                </div>

                <label class="form-label">Checks & Suggestions</label>
                <ul id="seo_checks" class="list-group list-group-flush">
                    <!-- dynamically populated -->
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Advanced Content Generator Panel -->
<div class="card mb-4 border">
    <div class="card-header d-flex align-items-center justify-content-between">
        <div><i class="fas fa-pen-nib me-2"></i><strong>Content Generator</strong></div>
        <div class="text-muted small">AI-powered SEO content generation and optimization</div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-8">
                <div class="mb-3">
                    <label class="form-label">Product Images</label>
                    <div id="image-paste-area" class="border rounded p-3 bg-light text-center" style="min-height: 100px;">
                        <div id="paste-instructions">
                            <i class="fas fa-image me-2"></i>
                            Paste product images here (Ctrl+V) or drag & drop
                        </div>
                        <div id="image-preview" class="d-flex flex-wrap gap-2 mt-2"></div>
                    </div>
                    <div class="form-text">Tip: Screenshot or copy images and paste them directly here</div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="writer_tone">Content Style</label>
                    <select id="writer_tone" class="form-select">
                        <option value="informative">Informative</option>
                        <option value="persuasive">Persuasive</option>
                        <option value="educational">Educational</option>
                        <option value="product-review">Product Review</option>
                        <option value="how-to">How-To Guide</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Target Keywords</label>
                    <div class="input-group">
                        <input type="text" id="primary_keyword" class="form-control" placeholder="Primary keyword">
                        <button class="btn btn-outline-secondary" type="button" id="analyze_competition">Analyze</button>
                    </div>
                    <div class="mt-2">
                        <input type="text" id="secondary_keywords" class="form-control" placeholder="Secondary keywords (comma separated)">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Content Structure</label>
                    <select id="content_structure" class="form-select mb-2">
                        <option value="product-description">Product Description</option>
                        <option value="feature-benefit">Feature-Benefit Article</option>
                        <option value="comparison">Comparison Article</option>
                        <option value="tutorial">Tutorial/Guide</option>
                        <option value="listicle">List Article</option>
                    </select>
                    <div class="form-text">Choose a structure that best fits your content goals</div>
                </div>

                <div class="mb-3 d-flex gap-2">
                    <button type="button" id="gen_title_btn" class="btn btn-outline-primary">Generate Meta Title</button>
                    <button type="button" id="gen_desc_btn" class="btn btn-outline-primary">Generate Meta Description</button>
                    <button type="button" id="suggest_headings_btn" class="btn btn-outline-secondary">Suggest Headings</button>
                    <button type="button" id="analyze_kw_btn" class="btn btn-outline-warning">Analyze Keyword Density</button>
                </div>

                <div class="mb-3">
                    <label class="form-label">Writer Suggestions</label>
                    <div id="writer_suggestions" class="border rounded p-2" style="min-height:80px; background:#fafafa"></div>
                </div>
            </div>
            <div class="col-md-4">
                <label class="form-label">Content Stats</label>
                <ul class="list-group">
                    <li class="list-group-item">Words: <span id="cw_word_count">0</span></li>
                    <li class="list-group-item">Characters: <span id="cw_char_count">0</span></li>
                    <li class="list-group-item">Reading time: <span id="cw_read_time">0</span> min</li>
                </ul>
                <div class="mt-3">
                    <label class="form-label">LSI Suggestions</label>
                    <div id="lsi_suggestions" class="small text-muted"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function sanitizeText(str) {
    if (!str) return '';
    return str.replace(/\s+/g, ' ').trim();
}

function setBadge(score) {
    const badge = document.getElementById('seo_score_badge');
    badge.textContent = 'Score: ' + score;
    badge.className = 'seo-score-badge ' + (score >= 80 ? 'bg-success text-white' : (score >= 50 ? 'bg-warning text-dark' : 'bg-danger text-white'));
}

function addCheckItem(text, status) {
    // status: ok, warn, bad
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-start';
    const left = document.createElement('div');
    left.innerHTML = text;
    const right = document.createElement('div');
    if (status === 'ok') right.innerHTML = '<span class="badge bg-success">Good</span>';
    else if (status === 'warn') right.innerHTML = '<span class="badge bg-warning text-dark">Improve</span>';
    else right.innerHTML = '<span class="badge bg-danger">Fix</span>';
    li.appendChild(left);
    li.appendChild(right);
    return li;
}

function runSeoCheck() {
    const titleEl = document.getElementById('title');
    const title = titleEl ? sanitizeText(titleEl.value) : '';
    const metaTitleEl = document.getElementById('meta_title');
    const metaTitle = metaTitleEl ? sanitizeText(metaTitleEl.value) : '';
    const slugEl = document.getElementById('slug');
    const slug = slugEl ? sanitizeText(slugEl.value) : '';
    const metaDescEl = document.getElementById('meta_description');
    const metaDesc = metaDescEl ? sanitizeText(metaDescEl.value) : '';
    const excerptEl = document.getElementById('excerpt');
    const excerpt = excerptEl ? sanitizeText(excerptEl.value) : '';
    const descEl = document.getElementById('description');
    const contentEl = document.getElementById('content');
    const content = descEl ? sanitizeText(descEl.value) : (contentEl ? sanitizeText(contentEl.value) : '');
    const keywordEl = document.getElementById('focus_keyword');
    const keyword = keywordEl ? sanitizeText(keywordEl.value) : '';

    // Build snippet values
    const finalTitle = metaTitle || title || 'Page title preview';
    const finalDesc = metaDesc || excerpt || content || 'Meta description preview';
    const displayUrl = slug ? (window.location.origin + '/' + slug) : (document.getElementById('snippet_url').textContent || window.location.origin + '/');

    // Update snippet preview
    document.getElementById('snippet_title').textContent = finalTitle;
    document.getElementById('snippet_description').textContent = finalDesc;
    document.getElementById('snippet_url').textContent = displayUrl;

    // Scoring rules — total 100
    let score = 0;
    const checks = [];

    // Title length (20 points)
    if (finalTitle.length >= 50 && finalTitle.length <= 60) { score += 20; checks.push({t:'Title length (50–60 chars)', s:'ok'}); }
    else if (finalTitle.length === 0) { checks.push({t:'Title is missing', s:'bad'}); }
    else if (finalTitle.length < 50) { checks.push({t:'Title is short (<50 chars)', s:'warn'}); }
    else { checks.push({t:'Title is long (>60 chars)', s:'warn'}); }

    // Description length (25 points)
    if (finalDesc.length >= 50 && finalDesc.length <= 160) { score += 25; checks.push({t:'Meta description length (50–160 chars)', s:'ok'}); }
    else if (finalDesc.length === 0) { checks.push({t:'Meta description is missing', s:'bad'}); }
    else if (finalDesc.length < 50) { checks.push({t:'Meta description is short', s:'warn'}); }
    else { checks.push({t:'Meta description is long', s:'warn'}); }

    // Focus keyword presence in title (15 points)
    if (keyword) {
        if (finalTitle.toLowerCase().includes(keyword.toLowerCase())) { score += 15; checks.push({t:'Focus keyword in title', s:'ok'}); }
        else { checks.push({t:'Focus keyword not found in title', s:'bad'}); }
    }

    // Focus keyword presence in description (10 points)
    if (keyword) {
        if (finalDesc.toLowerCase().includes(keyword.toLowerCase())) { score += 10; checks.push({t:'Focus keyword in meta description', s:'ok'}); }
        else { checks.push({t:'Focus keyword not found in meta description', s:'bad'}); }
    }

    // Content length (20 points)
    if (content.length >= 300) { score += 20; checks.push({t:'Content length (>=300 chars)', s:'ok'}); }
    else { checks.push({t:'Content is short (<300 chars)', s:'warn'}); }

    // Slug presence (10 points)
    if (slug && slug.length > 0) { score += 10; checks.push({t:'Permalink (slug) present', s:'ok'}); }
    else { checks.push({t:'Permalink (slug) missing — consider adding a short URL-friendly slug', s:'warn'}); }

    // Render checks
    const ul = document.getElementById('seo_checks');
    ul.innerHTML = '';
    checks.forEach(function(c){
        ul.appendChild(addCheckItem(c.t, c.s === 'ok' ? 'ok' : (c.s === 'warn' ? 'warn' : 'bad')));
    });

    // Finalize score and badge
    setBadge(score);
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize image paste area
    const imagePasteArea = document.getElementById('image-paste-area');
    const imagePreview = document.getElementById('image-preview');
    const pasteInstructions = document.getElementById('paste-instructions');
    const images = new Set();

    if (imagePasteArea) {
        // Handle paste events
        document.addEventListener('paste', function(e) {
            if (e.clipboardData && e.clipboardData.items) {
                const items = e.clipboardData.items;
                for (let i = 0; i < items.length; i++) {
                    if (items[i].type.indexOf('image') !== -1) {
                        const blob = items[i].getAsFile();
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            addImageToPreview(event.target.result);
                        };
                        reader.readAsDataURL(blob);
                    }
                }
            }
        });

        // Handle drag and drop
        imagePasteArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            imagePasteArea.classList.add('border-primary');
        });

        imagePasteArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            imagePasteArea.classList.remove('border-primary');
        });

        imagePasteArea.addEventListener('drop', function(e) {
            e.preventDefault();
            imagePasteArea.classList.remove('border-primary');
            
            if (e.dataTransfer.files) {
                Array.from(e.dataTransfer.files).forEach(file => {
                    if (file.type.indexOf('image') !== -1) {
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            addImageToPreview(event.target.result);
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
        });

        // Function to add image to preview
        function addImageToPreview(dataUrl) {
            if (images.has(dataUrl)) return; // Prevent duplicates
            images.add(dataUrl);
            
            const imgContainer = document.createElement('div');
            imgContainer.className = 'position-relative';
            imgContainer.style.width = '150px';
            
            const img = document.createElement('img');
            img.src = dataUrl;
            img.className = 'img-thumbnail';
            img.style.width = '150px';
            img.style.height = '150px';
            img.style.objectFit = 'cover';
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'btn btn-danger btn-sm position-absolute top-0 end-0';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = function() {
                images.delete(dataUrl);
                imgContainer.remove();
                if (images.size === 0) {
                    pasteInstructions.style.display = 'block';
                }
            };
            
            imgContainer.appendChild(img);
            imgContainer.appendChild(removeBtn);
            imagePreview.appendChild(imgContainer);
            pasteInstructions.style.display = 'none';
        }
    }

    // Initialize SEO checker
    const ids = ['title','meta_title','meta_description','focus_keyword','description','excerpt','content','slug'];
    ids.forEach(function(id){
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', runSeoCheck);
    });
    runSeoCheck();

    // Content writer button handlers
    const genTitleBtn = document.getElementById('gen_title_btn');
    const genDescBtn = document.getElementById('gen_desc_btn');
    const suggestHeadingsBtn = document.getElementById('suggest_headings_btn');
    const analyzeKwBtn = document.getElementById('analyze_kw_btn');

    if (genTitleBtn) genTitleBtn.addEventListener('click', function(){
        const title = (document.getElementById('title') && document.getElementById('title').value) || '';
        const kw = (document.getElementById('focus_keyword') && document.getElementById('focus_keyword').value) || '';
        const site = (new URL(document.getElementById('snippet_url').textContent || window.location.origin)).hostname || '';
        let generated = '';
        if (title) generated = title;
        else if (kw) generated = kw.charAt(0).toUpperCase() + kw.slice(1);
        else generated = 'New Article';
        // Append site shortener
        if (site) generated = generated + ' - ' + site;
        const metaTitleEl = document.getElementById('meta_title');
        if (metaTitleEl) metaTitleEl.value = generated;
        runSeoCheck();
        showWriterSuggestion('Meta title generated. You can edit it to be more specific.');
    });

    if (genDescBtn) genDescBtn.addEventListener('click', function(){
        const content = (document.getElementById('description') && document.getElementById('description').value) || (document.getElementById('content') && document.getElementById('content').value) || '';
        let desc = '';
        if (content) {
            // take first 160 chars of first paragraph/sentence
            desc = content.replace(/\s+/g,' ').trim();
            if (desc.length > 160) desc = desc.substring(0,157) + '...';
        } else {
            const title = (document.getElementById('title') && document.getElementById('title').value) || '';
            desc = title ? title + ' - Learn more on ' + window.location.hostname : 'Describe this article in a concise sentence.';
        }
        const metaDescEl = document.getElementById('meta_description');
        if (metaDescEl) metaDescEl.value = desc;
        runSeoCheck();
        showWriterSuggestion('Meta description generated. Tailor it to include a call-to-action for better CTR.');
    });

    if (suggestHeadingsBtn) suggestHeadingsBtn.addEventListener('click', function(){
        const content = (document.getElementById('description') && document.getElementById('description').value) || (document.getElementById('content') && document.getElementById('content').value) || '';
        const kw = (document.getElementById('focus_keyword') && document.getElementById('focus_keyword').value) || '';
        const suggestions = suggestHeadings(content, kw);
        showWriterSuggestion('<strong>Suggested Headings:</strong><br>' + suggestions.map(h=>('<div>- ' + h + '</div>')).join(''));
    });

    if (analyzeKwBtn) analyzeKwBtn.addEventListener('click', function(){
        const content = (document.getElementById('description') && document.getElementById('description').value) || (document.getElementById('content') && document.getElementById('content').value) || '';
        const kw = (document.getElementById('focus_keyword') && document.getElementById('focus_keyword').value) || '';
        const analysis = analyzeKeywordDensity(content, kw);
        let html = '<div><strong>Keyword:</strong> ' + (kw || '(none)') + '</div>';
        html += '<div><strong>Occurrences:</strong> ' + analysis.count + ' &middot; Density: ' + analysis.density.toFixed(2) + '%</div>';
        if (analysis.lsi && analysis.lsi.length) html += '<div><strong>LSI suggestions:</strong> ' + analysis.lsi.slice(0,10).join(', ') + '</div>';
        showWriterSuggestion(html);
        // show lsi suggestions in side panel
        const lsiBox = document.getElementById('lsi_suggestions');
        if (lsiBox) lsiBox.textContent = analysis.lsi.slice(0,15).join(', ');
    });

    // update content stats live
    const contentIds = ['description','content'];
    contentIds.forEach(function(id){
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', updateContentStats);
    });
    updateContentStats();
});

function showWriterSuggestion(html) {
    const box = document.getElementById('writer_suggestions');
    if (!box) return;
    box.innerHTML = html;
}

function updateContentStats() {
    const content = (document.getElementById('description') && document.getElementById('description').value) || (document.getElementById('content') && document.getElementById('content').value) || '';
    const words = content.trim().length ? content.trim().split(/\s+/).length : 0;
    const chars = content.length;
    const readTime = Math.max(1, Math.round(words / 200));
    const wc = document.getElementById('cw_word_count'); if (wc) wc.textContent = words;
    const cc = document.getElementById('cw_char_count'); if (cc) cc.textContent = chars;
    const rt = document.getElementById('cw_read_time'); if (rt) rt.textContent = readTime;
}

function suggestHeadings(content, keyword) {
    content = (content || '').replace(/\s+/g,' ').trim();
    if (!content) return ['Introduction', 'Key Benefits', 'How it Works', 'Conclusion'];
    // Simple heuristic: pick sentences with keyword, else top sentences by length
    const sentences = content.match(/[^\.\!\?]+[\.\!\?]*/g) || [content];
    const picks = [];
    for (let s of sentences) {
        if (keyword && s.toLowerCase().includes(keyword.toLowerCase()) && picks.length < 4) picks.push(s.trim().replace(/\.$/,''));
    }
    for (let s of sentences) {
        if (picks.length >= 4) break;
        const clean = s.trim().replace(/\.$/,'');
        if (!picks.includes(clean) && clean.length > 30) picks.push(clean);
    }
    // Fallback headings
    while (picks.length < 4) picks.push('More Details');
    // Convert picks to short headings (take first 6-8 words)
    return picks.map(p => p.split(/\s+/).slice(0,8).join(' '));
}

function analyzeKeywordDensity(content, keyword) {
    content = (content || '').toLowerCase().replace(/[^a-z0-9\s]/g,' ');
    const words = content.split(/\s+/).filter(Boolean);
    const total = words.length;
    const stopwords = new Set(['the','and','a','an','of','to','in','for','on','with','is','are','that','this','it','as','at','by','from']);
    const freq = {};
    for (let w of words) {
        if (stopwords.has(w) || w.length < 3) continue;
        freq[w] = (freq[w]||0) + 1;
    }
    const lsi = Object.keys(freq).sort((a,b)=>freq[b]-freq[a]);
    let count = 0;
    if (keyword) {
        const k = keyword.toLowerCase();
        for (let w of words) if (w === k) count++;
    }
    const density = total > 0 ? (count / total) * 100 : 0;
    
    // Calculate ranking potential score
    let rankingScore = 0;
    
    // 1. Content Length (0-25 points)
    if (total >= 1000) rankingScore += 25;
    else if (total >= 750) rankingScore += 20;
    else if (total >= 500) rankingScore += 15;
    else if (total >= 300) rankingScore += 10;
    
    // 2. Keyword Density (0-25 points)
    if (density >= 1 && density <= 3) rankingScore += 25;
    else if (density > 3 && density <= 5) rankingScore += 15;
    else if (density > 0 && density < 1) rankingScore += 10;
    
    // 3. LSI Keywords Usage (0-25 points)
    const lsiScore = Math.min(25, lsi.length * 2);
    rankingScore += lsiScore;
    
    // 4. Content Structure (0-25 points)
    const hasHeadings = content.includes('h1') || content.includes('h2');
    const hasLists = content.includes('•') || content.includes('✓');
    const hasSchema = content.includes('Schema:');
    
    if (hasHeadings) rankingScore += 10;
    if (hasLists) rankingScore += 10;
    if (hasSchema) rankingScore += 5;
    
    return { 
        total: total, 
        count: count, 
        density: density, 
        lsi: lsi,
        rankingScore: rankingScore,
        recommendations: [
            density < 1 ? 'Increase keyword usage naturally' : null,
            total < 500 ? 'Add more detailed content' : null,
            !hasHeadings ? 'Add H1 and H2 headings' : null,
            !hasLists ? 'Include bullet points or lists' : null,
            !hasSchema ? 'Add schema markup' : null
        ].filter(Boolean)
    };
}

function generateSEOContent(primaryKeyword, secondaryKeywords, structure, style) {
    // SEO-optimized content templates with AI generation patterns
    const templates = {
        'product-description': {
            sections: [
                { 
                    type: 'intro', 
                    title: 'Overview',
                    seoPattern: [
                        "Discover the exceptional {keyword} designed to {mainBenefit}.",
                        "Experience unparalleled quality with our premium {keyword}.",
                        "Introducing our top-rated {keyword} that {uniqueFeature}."
                    ]
                },
                { 
                    type: 'features', 
                    title: 'Key Features',
                    seoPattern: [
                        "• Advanced {feature1} for optimal performance",
                        "• Innovative {feature2} technology",
                        "• Enhanced {feature3} capabilities",
                        "• Premium-grade {feature4} system"
                    ]
                },
                { 
                    type: 'benefits', 
                    title: 'Benefits',
                    seoPattern: [
                        "✓ {benefit1} - Save time and effort",
                        "✓ {benefit2} - Improve efficiency",
                        "✓ {benefit3} - Superior results",
                        "✓ {benefit4} - Long-lasting performance"
                    ]
                },
                { 
                    type: 'specs', 
                    title: 'Specifications',
                    seoPattern: [
                        "Dimensions: {dimensions}",
                        "Material: Premium {material}",
                        "Warranty: {warranty}",
                        "Additional Features: {additionalFeatures}"
                    ]
                }
            ]
        },
        'feature-benefit': {
            sections: [
                { type: 'intro', title: 'Introduction', prompt: 'Introduce the topic and its importance' },
                { type: 'problem', title: 'Common Challenges', prompt: 'Describe problems this solves' },
                { type: 'solution', title: 'Solution Overview', prompt: 'Present the main solution' },
                { type: 'features', title: 'Key Features', prompt: 'Detail important features' },
                { type: 'benefits', title: 'Benefits & Advantages', prompt: 'List main benefits' },
                { type: 'conclusion', title: 'Conclusion', prompt: 'Wrap up main points' }
            ]
        },
        'comparison': {
            sections: [
                { type: 'intro', title: 'Introduction', prompt: 'Introduce what is being compared' },
                { type: 'overview', title: 'Product Overview', prompt: 'Brief overview of items' },
                { type: 'comparison', title: 'Detailed Comparison', prompt: 'Compare key aspects' },
                { type: 'pros', title: 'Pros & Cons', prompt: 'List advantages and disadvantages' },
                { type: 'verdict', title: 'Final Verdict', prompt: 'Conclude with recommendations' }
            ]
        }
    };

    // Get template for selected structure
    const template = templates[structure] || templates['product-description'];
    
    // Generate outline with keyword placement
    let content = '';
    
    // Generate SEO-optimized title
    content += `Complete Guide to ${primaryKeyword}\n\n`;
    
    template.sections.forEach(section => {
        // Generate section heading
        content += section.title + '\n\n';
        
        // Generate section content based on type
        switch(section.type) {
            case 'intro':
                content += `Welcome to our comprehensive guide about ${primaryKeyword}. `;
                content += `We are excited to share detailed information about this exceptional product that has been helping customers achieve great results. `;
                content += `In this ${style} guide, we'll explore everything you need to know about ${primaryKeyword} and how it can benefit you.\n\n`;
                break;
                
            case 'features':
                content += `Our ${primaryKeyword} comes with several outstanding features:\n\n`;
                content += `First, you'll appreciate the premium quality construction that ensures long-lasting performance. `;
                content += `The advanced technology incorporated into every unit delivers consistent, reliable results. `;
                content += `We've also focused on creating an intuitive, user-friendly design that makes operation simple and efficient. `;
                content += `The reliable performance ensures you get consistent results every time you use it.\n\n`;
                break;
                
            case 'benefits':
                content += `When you choose our ${primaryKeyword}, you'll experience multiple benefits:\n\n`;
                content += `You'll immediately notice how it saves you valuable time and effort in your daily tasks. `;
                content += `Users consistently report superior results compared to alternative solutions. `;
                content += `The durable construction ensures long-lasting performance for years to come. `;
                content += `Most importantly, you'll get excellent value for your investment, making this a smart choice.\n\n`;
                break;
                
            case 'specs':
                content += `Let's look at the important specifications of our ${primaryKeyword}:\n\n`;
                content += `The product features premium-grade components throughout its construction. `;
                content += `Every unit is built with durability in mind, ensuring it stands up to regular use. `;
                content += `We offer comprehensive warranty coverage for your peace of mind. `;
                content += `Our dedicated support team is always available to assist you with any questions.\n\n`;
                break;
                
            case 'conclusion':
                content += `We hope this guide has helped you understand the value of our ${primaryKeyword}. `;
                content += `Thousands of satisfied customers have already experienced the benefits we've discussed. `;
                content += `We're confident that once you try it, you'll understand why it's the preferred choice in the market.\n\n`;
                break;
        }
        
        // Add secondary keywords naturally
        if (secondaryKeywords) {
            const keywords = secondaryKeywords.split(',').map(k => k.trim());
            if (section.type === 'features' || section.type === 'benefits') {
                content += `Additionally, customers appreciate ${keywords.join(', ')} and many other features that make this product stand out.\n\n`;
            }
        }
    });
    
    return content;
    
    return content;
}

function analyzeCompetition(keyword) {
    // Simulate competitive analysis
    const metrics = {
        difficulty: Math.floor(Math.random() * 100),
        volume: Math.floor(Math.random() * 10000),
        suggested_length: Math.floor(Math.random() * 1000) + 1000,
        top_headings: [
            'Benefits of ' + keyword,
            'How to Choose ' + keyword,
            keyword + ' Buying Guide',
            'Top Features of ' + keyword
        ]
    };
    
    return metrics;
}

// Initialize content generator features
document.addEventListener('DOMContentLoaded', function() {
    const analyzeBtn = document.getElementById('analyze_competition');
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', function() {
            const keyword = document.getElementById('primary_keyword').value;
            if (!keyword) return;
            
            const metrics = analyzeCompetition(keyword);
            showWriterSuggestion(`
                <strong>Keyword Analysis:</strong><br>
                Difficulty: ${metrics.difficulty}/100<br>
                Search Volume: ${metrics.volume}/month<br>
                Recommended Length: ${metrics.suggested_length} words<br>
                <strong>Suggested Headings:</strong><br>
                ${metrics.top_headings.map(h => '- ' + h).join('<br>')}
            `);
        });
    }

    // Add content generation button
    const genBtn = document.createElement('button');
    genBtn.className = 'btn btn-primary mt-3';
    genBtn.textContent = 'Generate SEO Content';
    genBtn.onclick = function() {
        const primaryKw = document.getElementById('primary_keyword').value;
        const secondaryKw = document.getElementById('secondary_keywords').value;
        const structure = document.getElementById('content_structure').value;
        const style = document.getElementById('writer_tone').value;
        
        if (!primaryKw) {
            alert('Please enter a primary keyword');
            return;
        }
        
        const content = generateSEOContent(primaryKw, secondaryKw, structure, style);
        const editorEl = document.getElementById('description') || document.getElementById('content');
        if (editorEl) {
            editorEl.value = content;
            updateContentStats();
            runSeoCheck();
        }
    };
    
    const contentStructureEl = document.getElementById('content_structure');
    if (contentStructureEl) {
        contentStructureEl.parentNode.appendChild(genBtn);
    }
});
</script>
