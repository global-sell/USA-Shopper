<?php
$pageTitle = "Support Tickets";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

// Handle add reply
if (isset($_POST['add_reply'])) {
    $ticketId = (int)$_POST['ticket_id'];
    $replyMessage = sanitizeInput($_POST['reply_message'] ?? '');
    
    if (!empty($replyMessage)) {
        $stmt = $db->prepare("INSERT INTO ticket_replies (ticket_id, user_id, message, is_admin) VALUES (?, ?, ?, 1)");
        $stmt->bind_param("iis", $ticketId, $_SESSION['user_id'], $replyMessage);
        
        if ($stmt->execute()) {
            $success = 'Reply sent successfully';
        } else {
            $error = 'Failed to send reply';
        }
    }
}

// Handle update status
if (isset($_POST['update_status'])) {
    $ticketId = (int)$_POST['ticket_id'];
    $status = sanitizeInput($_POST['status'] ?? '');
    
    $stmt = $db->prepare("UPDATE support_tickets SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $ticketId);
    
    if ($stmt->execute()) {
        $success = 'Ticket status updated';
    } else {
        $error = 'Failed to update status';
    }
}

// Handle delete ticket
if (isset($_GET['delete'])) {
    $ticketId = (int)$_GET['delete'];
    
    // Delete replies first
    $db->query("DELETE FROM ticket_replies WHERE ticket_id = $ticketId");
    
    // Delete ticket
    $db->query("DELETE FROM support_tickets WHERE id = $ticketId");
    
    redirect(ADMIN_URL . '/support.php?deleted=1');
}

// Get filter
$statusFilter = $_GET['status'] ?? 'all';
$priorityFilter = $_GET['priority'] ?? 'all';

// Build query
$query = "SELECT st.*, u.name as user_name, u.email as user_email,
          (SELECT COUNT(*) FROM ticket_replies WHERE ticket_id = st.id) as reply_count
          FROM support_tickets st
          JOIN users u ON st.user_id = u.id
          WHERE 1=1";

if ($statusFilter !== 'all') {
    $query .= " AND st.status = '" . $db->real_escape_string($statusFilter) . "'";
}

if ($priorityFilter !== 'all') {
    $query .= " AND st.priority = '" . $db->real_escape_string($priorityFilter) . "'";
}

$query .= " ORDER BY 
            CASE st.priority 
                WHEN 'high' THEN 1 
                WHEN 'medium' THEN 2 
                WHEN 'low' THEN 3 
            END,
            st.created_at DESC";

$tickets = $db->query($query)->fetch_all(MYSQLI_ASSOC);

// Get statistics
$stats = [
    'total' => $db->query("SELECT COUNT(*) as count FROM support_tickets")->fetch_assoc()['count'],
    'open' => $db->query("SELECT COUNT(*) as count FROM support_tickets WHERE status = 'open'")->fetch_assoc()['count'],
    'in_progress' => $db->query("SELECT COUNT(*) as count FROM support_tickets WHERE status = 'in_progress'")->fetch_assoc()['count'],
    'closed' => $db->query("SELECT COUNT(*) as count FROM support_tickets WHERE status = 'closed'")->fetch_assoc()['count']
];
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">
            <i class="fas fa-headset me-2"></i>Support Tickets
        </h2>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Ticket deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Total Tickets</h6>
                            <h3 class="mb-0 fw-bold"><?php echo $stats['total']; ?></h3>
                        </div>
                        <i class="fas fa-ticket-alt fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Open</h6>
                            <h3 class="mb-0 fw-bold"><?php echo $stats['open']; ?></h3>
                        </div>
                        <i class="fas fa-exclamation-circle fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">In Progress</h6>
                            <h3 class="mb-0 fw-bold"><?php echo $stats['in_progress']; ?></h3>
                        </div>
                        <i class="fas fa-spinner fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">Closed</h6>
                            <h3 class="mb-0 fw-bold"><?php echo $stats['closed']; ?></h3>
                        </div>
                        <i class="fas fa-check-circle fa-2x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Status Filter</label>
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="open" <?php echo $statusFilter === 'open' ? 'selected' : ''; ?>>Open</option>
                        <option value="in_progress" <?php echo $statusFilter === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                        <option value="closed" <?php echo $statusFilter === 'closed' ? 'selected' : ''; ?>>Closed</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Priority Filter</label>
                    <select name="priority" class="form-select" onchange="this.form.submit()">
                        <option value="all" <?php echo $priorityFilter === 'all' ? 'selected' : ''; ?>>All Priorities</option>
                        <option value="high" <?php echo $priorityFilter === 'high' ? 'selected' : ''; ?>>High</option>
                        <option value="medium" <?php echo $priorityFilter === 'medium' ? 'selected' : ''; ?>>Medium</option>
                        <option value="low" <?php echo $priorityFilter === 'low' ? 'selected' : ''; ?>>Low</option>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <a href="support.php" class="btn btn-secondary">
                        <i class="fas fa-redo me-2"></i>Reset Filters
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Tickets List -->
    <?php if (empty($tickets)): ?>
        <div class="card text-center py-5">
            <div class="card-body">
                <i class="fas fa-ticket-alt fa-4x text-muted mb-3"></i>
                <h4 class="mb-3">No Support Tickets</h4>
                <p class="text-muted mb-0">No support tickets found matching your filters.</p>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($tickets as $ticket): ?>
            <?php
            $statusClass = match($ticket['status']) {
                'open' => 'danger',
                'in_progress' => 'warning',
                'closed' => 'success',
                default => 'secondary'
            };
            
            $priorityClass = match($ticket['priority']) {
                'high' => 'danger',
                'medium' => 'warning',
                'low' => 'info',
                default => 'secondary'
            };
            ?>
            
            <div class="card mb-3">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-md-5">
                            <h6 class="mb-1 fw-bold">
                                <i class="fas fa-ticket-alt me-2"></i>
                                <?php echo htmlspecialchars($ticket['subject']); ?>
                            </h6>
                            <small class="text-muted">
                                <i class="fas fa-user me-1"></i>
                                <?php echo htmlspecialchars($ticket['user_name']); ?> 
                                (<?php echo htmlspecialchars($ticket['user_email']); ?>)
                            </small>
                        </div>
                        <div class="col-md-4 mt-2 mt-md-0">
                            <small class="text-muted">
                                <i class="fas fa-clock me-1"></i>
                                <?php echo date('M j, Y g:i A', strtotime($ticket['created_at'])); ?>
                            </small>
                            <br>
                            <small class="text-muted">
                                <i class="fas fa-comments me-1"></i>
                                <?php echo $ticket['reply_count']; ?> replies
                            </small>
                        </div>
                        <div class="col-md-3 text-md-end mt-2 mt-md-0">
                            <span class="badge bg-<?php echo $statusClass; ?> me-1">
                                <?php echo ucfirst(str_replace('_', ' ', $ticket['status'])); ?>
                            </span>
                            <span class="badge bg-<?php echo $priorityClass; ?>">
                                <?php echo ucfirst($ticket['priority']); ?>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <p class="mb-3"><?php echo nl2br(htmlspecialchars($ticket['message'])); ?></p>
                    
                    <?php
                    // Get replies
                    $stmt = $db->prepare("SELECT tr.*, u.name as user_name 
                                         FROM ticket_replies tr 
                                         JOIN users u ON tr.user_id = u.id 
                                         WHERE tr.ticket_id = ? 
                                         ORDER BY tr.created_at ASC");
                    $stmt->bind_param("i", $ticket['id']);
                    $stmt->execute();
                    $replies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    ?>
                    
                    <?php if (!empty($replies)): ?>
                        <div class="border-top pt-3 mt-3">
                            <h6 class="fw-bold mb-3">
                                <i class="fas fa-comments me-2"></i>Conversation (<?php echo count($replies); ?>)
                            </h6>
                            <?php foreach ($replies as $reply): ?>
                                <div class="mb-3 p-3 rounded <?php echo $reply['is_admin'] ? 'bg-primary bg-opacity-10 border-start border-primary border-3' : 'bg-light'; ?>">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <strong class="<?php echo $reply['is_admin'] ? 'text-primary' : ''; ?>">
                                            <?php echo $reply['is_admin'] ? '<i class="fas fa-user-shield me-1"></i>Support Team (You)' : '<i class="fas fa-user me-1"></i>' . htmlspecialchars($reply['user_name']); ?>
                                        </strong>
                                        <small class="text-muted">
                                            <?php echo date('M j, Y g:i A', strtotime($reply['created_at'])); ?>
                                        </small>
                                    </div>
                                    <p class="mb-0"><?php echo nl2br(htmlspecialchars($reply['message'])); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="border-top pt-3 mt-3">
                        <div class="row">
                            <div class="col-md-8">
                                <form method="POST" class="mb-3">
                                    <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                    <div class="form-outline mb-3">
                                        <textarea id="reply_message_<?php echo $ticket['id']; ?>" 
                                                  name="reply_message" class="form-control" rows="3" required></textarea>
                                        <label class="form-label" for="reply_message_<?php echo $ticket['id']; ?>">Reply to Customer</label>
                                    </div>
                                    <button type="submit" name="add_reply" class="btn btn-primary">
                                        <i class="fas fa-reply me-2"></i>Send Reply
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <form method="POST" class="mb-3">
                                    <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                    <label class="form-label">Update Status</label>
                                    <select name="status" class="form-select mb-2">
                                        <option value="open" <?php echo $ticket['status'] === 'open' ? 'selected' : ''; ?>>Open</option>
                                        <option value="in_progress" <?php echo $ticket['status'] === 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                        <option value="closed" <?php echo $ticket['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-warning w-100 mb-2">
                                        <i class="fas fa-edit me-2"></i>Update Status
                                    </button>
                                </form>
                                <a href="?delete=<?php echo $ticket['id']; ?>" 
                                   class="btn btn-danger w-100" 
                                   onclick="return confirmDelete('Are you sure you want to delete this ticket and all its replies?')">
                                    <i class="fas fa-trash me-2"></i>Delete Ticket
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
