<?php
require_once __DIR__ . '/../../config/config.php';

// Check if user is admin
if (!isAdmin()) {
    redirect(SITE_URL . '/login');
}

$currentUser = getCurrentUser();
$siteName = getSetting('site_name', 'YBT Digital');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - Admin' : 'Admin Dashboard'; ?> - <?php echo $siteName; ?></title>
    
    <!-- Material Design Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <?php 
    $faviconPath = getSetting('favicon_path', 'assets/images/favicon.svg');
    $faviconUrl = SITE_URL . '/' . $faviconPath;
    $faviconExt = pathinfo($faviconPath, PATHINFO_EXTENSION);
    $faviconType = match($faviconExt) {
        'svg' => 'image/svg+xml',
        'png' => 'image/png',
        'jpg', 'jpeg' => 'image/jpeg',
        'ico' => 'image/x-icon',
        default => 'image/x-icon'
    };
    ?>
    <link rel="icon" href="<?php echo $faviconUrl; ?>" type="<?php echo $faviconType; ?>">
    <link rel="shortcut icon" href="<?php echo $faviconUrl; ?>" type="<?php echo $faviconType; ?>">
    <link rel="apple-touch-icon" href="<?php echo $faviconUrl; ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --sidebar-width: 250px;
            --header-height: 60px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f5f5f5;
        }

        /* Admin Header */
        .admin-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: var(--header-height);
            background-color: #1976d2;
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 1.5rem;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .admin-header .logo {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .admin-header .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        /* Sidebar */
        .admin-sidebar {
            position: fixed;
            top: var(--header-height);
            left: 0;
            width: var(--sidebar-width);
            height: calc(100vh - var(--header-height));
            background-color: #2d2d2d;
            color: white;
            overflow-y: auto;
            z-index: 999;
            transition: transform 0.3s;
        }

        .admin-sidebar.collapsed {
            transform: translateX(-100%);
        }

        .sidebar-menu {
            list-style: none;
            padding: 1rem 0;
        }

        .sidebar-menu li a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: #b0b0b0;
            text-decoration: none;
            transition: all 0.3s;
        }

        .sidebar-menu li a:hover,
        .sidebar-menu li a.active {
            background-color: #1976d2;
            color: white;
        }

        .sidebar-menu li a i {
            width: 20px;
            margin-right: 0.75rem;
        }

        /* Main Content */
        .admin-content {
            margin-left: var(--sidebar-width);
            margin-top: var(--header-height);
            min-height: calc(100vh - var(--header-height));
            transition: margin-left 0.3s;
        }

        .admin-content.expanded {
            margin-left: 0;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }

            .admin-sidebar.show {
                transform: translateX(0);
            }

            .admin-content {
                margin-left: 0;
            }
        }

        /* Toggle Button */
        .sidebar-toggle {
            background: none;
            border: none;
            color: white;
            font-size: 1.25rem;
            cursor: pointer;
            padding: 0.5rem;
        }

        /* Cards */
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }

        /* Tables */
        .table {
            background-color: white;
        }

        .table thead th {
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
        }
    </style>
</head>
<body>

<!-- Admin Header -->
<div class="admin-header">
    <div class="d-flex align-items-center">
        <button class="sidebar-toggle me-3" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
        <div class="logo">
            <i class="fas fa-cog me-2"></i><?php echo $siteName; ?> Admin
        </div>
    </div>
    
    <div class="user-menu">
        <a href="<?php echo SITE_URL; ?>" class="text-white text-decoration-none" target="_blank">
            <i class="fas fa-external-link-alt me-1"></i>View Site
        </a>
        <div class="dropdown">
            <a class="text-white text-decoration-none dropdown-toggle" href="#" role="button" 
               data-mdb-toggle="dropdown">
                <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($currentUser['name']); ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/profile">
                    <i class="fas fa-user me-2"></i>Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/logout">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</div>

<!-- Sidebar -->
<div class="admin-sidebar" id="adminSidebar">
    <ul class="sidebar-menu">
        <li>
            <a href="<?php echo ADMIN_URL; ?>" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i>Dashboard
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/products.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>">
                <i class="fas fa-box"></i>Products
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/add-product.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add-product.php' ? 'active' : ''; ?>">
                <i class="fas fa-plus-circle"></i>Add Product
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/categories.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : ''; ?>">
                <i class="fas fa-folder"></i>Categories
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/blogs.php" class="<?php echo in_array(basename($_SERVER['PHP_SELF']), ['blogs.php', 'add-blog.php', 'edit-blog.php']) ? 'active' : ''; ?>">
                <i class="fas fa-blog"></i>Blogs
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/add-landing.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'add-landing.php' ? 'active' : ''; ?>">
                <i class="fas fa-flag"></i>Add Landing Page
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/orders.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>">
                <i class="fas fa-shopping-cart"></i>Orders
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/users.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>Users
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/coupons.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'coupons.php' ? 'active' : ''; ?>">
                <i class="fas fa-tag"></i>Coupons
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/support.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'support.php' ? 'active' : ''; ?>">
                <i class="fas fa-headset"></i>Support Tickets
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/email-management.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'email-management.php' ? 'active' : ''; ?>">
                <i class="fas fa-envelope-open-text"></i>Email Management
            </a>
        </li>
        <li>
            <a href="<?php echo ADMIN_URL; ?>/settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i>Settings
            </a>
        </li>
    </ul>
</div>

<!-- Main Content -->
<div class="admin-content" id="adminContent">