</div> <!-- Close main-content -->

<!-- Footer -->
<footer class="mt-5 py-5" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #e8eaed;">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 mb-4">
                <h5 class="fw-bold text-white mb-3"><?php echo getSetting('site_name', 'YBT Digital'); ?></h5>
                <p style="color: #cbd5e1;">Your trusted marketplace for premium digital products.</p>
                <div class="d-flex gap-3 mt-3">
                    <a href="#" class="text-white" style="font-size: 1.5rem;" title="Facebook"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="text-white" style="font-size: 1.5rem;" title="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-white" style="font-size: 1.5rem;" title="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-white" style="font-size: 1.5rem;" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h6 class="fw-bold text-white mb-3">Quick Links</h6>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Home</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/products" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Shop</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/about" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">About Us</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/blogs" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Blogs</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/official-store" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Official Store</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h6 class="fw-bold text-white mb-3">Support</h6>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/contact" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Contact Us</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/faq" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">FAQ</a></li>
                    <li class="mb-2"><a href="https://globalsell.site/track-order" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'" target="_blank">Track Order</a></li>
                    <li class="mb-2"><a href="<?php echo SITE_URL; ?>/terms" style="color: #94a3b8; text-decoration: none;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#94a3b8'">Terms & Conditions</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6 mb-4">
                <h6 class="fw-bold text-white mb-3">Newsletter</h6>
                <p style="color: #cbd5e1; font-size: 0.9rem;">Subscribe to get updates on new products</p>
                <form id="newsletterFormFooter" class="d-flex gap-2 mb-3">
                    <input type="email" id="newsletterEmail" class="form-control" placeholder="Your email" required style="border-radius: 8px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: white;">
                    <button type="submit" class="btn btn-primary" style="border-radius: 8px; background: linear-gradient(135deg, #4287f5 0%, #9333ea 100%); border: none;">
                        <span class="newsletter-btn-text">Subscribe</span>
                        <span class="newsletter-btn-loading d-none">
                            <span class="spinner-border spinner-border-sm" role="status"></span>
                        </span>
                    </button>
                </form>
                <div id="newsletterMessage" class="mt-2"></div>
            </div>
        </div>
        <hr class="my-4" style="border-color: rgba(255,255,255,0.1); opacity: 0.3;">
        <div class="text-center" style="color: #94a3b8;">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo getSetting('site_name', 'YBT Digital'); ?>. All rights reserved.</p>
        </div>
    </div>
</footer>

<style>
footer a {
    transition: all 0.3s ease;
}

footer .fab {
    transition: all 0.3s ease;
}

footer .fab:hover {
    transform: scale(1.2);
    color: #4287f5 !important;
}

footer input::placeholder {
    color: rgba(255, 255, 255, 0.5);
}

footer input:focus {
    background: rgba(255,255,255,0.15) !important;
    border-color: #4287f5 !important;
    box-shadow: 0 0 0 0.2rem rgba(66, 135, 245, 0.25);
    color: white !important;
}
</style>

<!-- Material Design Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>

<script>
// Navbar Scroll Effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.desktop-navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
});

// Mobile Menu Toggle
function toggleMobileMenu() {
    const drawer = document.getElementById('mobileMenuDrawer');
    const overlay = document.getElementById('mobileMenuOverlay');
    
    if (drawer && overlay) {
        drawer.classList.toggle('open');
        overlay.classList.toggle('show');
        
        // Prevent body scroll when menu is open
        if (drawer.classList.contains('open')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    }
}

// Theme Toggle
function toggleTheme() {
    const body = document.body;
    const themeIcon = document.getElementById('theme-icon');
    const themeIconMobile = document.getElementById('theme-icon-mobile');
    
    if (body.classList.contains('light-mode')) {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
        if (themeIcon) themeIcon.className = 'fas fa-sun';
        if (themeIconMobile) themeIconMobile.className = 'fas fa-sun';
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.remove('dark-mode');
        body.classList.add('light-mode');
        if (themeIcon) themeIcon.className = 'fas fa-moon';
        if (themeIconMobile) themeIconMobile.className = 'fas fa-moon';
        localStorage.setItem('theme', 'light');
    }
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const body = document.body;
    const themeIcon = document.getElementById('theme-icon');
    const themeIconMobile = document.getElementById('theme-icon-mobile');
    
    if (savedTheme === 'dark') {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
        if (themeIcon) themeIcon.className = 'fas fa-sun';
        if (themeIconMobile) themeIconMobile.className = 'fas fa-sun';
    }
    
    // Update cart count
    updateCartCount();
});

// Update cart count
function updateCartCount() {
    fetch('/api/cart-count.php')
        .then(response => response.json())
        .then(data => {
            const count = data.count || 0;
            const cartBadge = document.getElementById('cart-count');
            const cartBadgeMobile = document.getElementById('cart-count-mobile');
            
            if (cartBadge) {
                cartBadge.textContent = count;
                cartBadge.style.display = count > 0 ? 'block' : 'none';
            }
            if (cartBadgeMobile) {
                cartBadgeMobile.textContent = count;
                cartBadgeMobile.style.display = count > 0 ? 'block' : 'none';
            }
        })
        .catch(error => console.error('Error updating cart count:', error));
}

// Add to cart function
function addToCart(productId) {
    // Use relative path so the API call works on local and production environments
    fetch('/api/add-to-cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ product_id: productId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount();
            showNotification('Product added to cart!', 'success');
        } else {
            // If user is not logged in, redirect them to the login page with return URL
            if (typeof data.message === 'string' && data.message.toLowerCase().includes('please login')) {
                const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
                window.location.href = '<?php echo SITE_URL; ?>/login.php?redirect=' + returnUrl;
                return;
            }
            showNotification(data.message || 'Failed to add to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred', 'error');
    });
}

// Show notification
function showNotification(message, type = 'info') {
    const alertClass = type === 'success' ? 'alert-success' : 
                      type === 'error' ? 'alert-danger' : 'alert-info';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alert.style.zIndex = '9999';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 3000);
}

// Newsletter Subscription
document.getElementById('newsletterFormFooter')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const email = document.getElementById('newsletterEmail').value;
    const button = form.querySelector('button[type="submit"]');
    const btnText = button.querySelector('.newsletter-btn-text');
    const btnLoading = button.querySelector('.newsletter-btn-loading');
    const messageDiv = document.getElementById('newsletterMessage');
    
    // Disable button and show loading
    button.disabled = true;
    btnText.classList.add('d-none');
    btnLoading.classList.remove('d-none');
    messageDiv.innerHTML = '';
    
    // Send AJAX request
    fetch('/api/subscribe-newsletter.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'email=' + encodeURIComponent(email)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageDiv.innerHTML = '<small class="text-success"><i class="fas fa-check-circle me-1"></i>' + data.message + '</small>';
            form.reset();
        } else {
            messageDiv.innerHTML = '<small class="text-danger"><i class="fas fa-exclamation-circle me-1"></i>' + data.message + '</small>';
        }
    })
    .catch(error => {
        messageDiv.innerHTML = '<small class="text-danger"><i class="fas fa-exclamation-circle me-1"></i>An error occurred. Please try again.</small>';
    })
    .finally(() => {
        // Re-enable button and hide loading
        button.disabled = false;
        btnText.classList.remove('d-none');
        btnLoading.classList.add('d-none');
    });
});
</script>

<!-- Newsletter Popup Modal -->
<div class="modal fade" id="newsletterModal" tabindex="-1" aria-labelledby="newsletterModalLabel" aria-hidden="true" data-mdb-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
            <div class="modal-header border-0 position-relative" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 2rem;">
                <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3" data-mdb-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-4 pb-5" style="margin-top: -40px;">
                <!-- Icon -->
                <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center shadow-lg mb-3" style="width: 80px; height: 80px;">
                    <i class="fas fa-envelope-open-text fa-3x text-primary"></i>
                </div>
                
                <h3 class="fw-bold mb-3">Stay Updated!</h3>
                <p class="text-muted mb-4">
                    Subscribe to our newsletter and get <strong class="text-primary">20% OFF</strong> your first order! 
                    Plus exclusive deals, new arrivals, and international shipping updates.
                </p>
                
                <!-- Newsletter Form -->
                <form id="newsletterForm" class="mb-3">
                    <div class="input-group input-group-lg mb-3">
                        <input type="email" id="newsletter_email" class="form-control" placeholder="Enter your email" required style="border-radius: 50px 0 0 50px; padding: 1rem 1.5rem;">
                        <button class="btn btn-primary" type="submit" style="border-radius: 0 50px 50px 0; padding: 1rem 2rem;">
                            <i class="fas fa-paper-plane me-2"></i>Subscribe
                        </button>
                    </div>
                </form>
                
                <!-- Benefits -->
                <div class="row g-3 text-start">
                    <div class="col-6">
                        <small class="text-muted">
                            <i class="fas fa-check-circle text-success me-2"></i>Exclusive Deals
                        </small>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">
                            <i class="fas fa-check-circle text-success me-2"></i>New Arrivals
                        </small>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">
                            <i class="fas fa-check-circle text-success me-2"></i>Free Shipping Updates
                        </small>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">
                            <i class="fas fa-check-circle text-success me-2"></i>Unsubscribe Anytime
                        </small>
                    </div>
                </div>
                
                <p class="text-muted small mt-4 mb-0">
                    <i class="fas fa-lock me-1"></i>We respect your privacy. No spam, ever.
                </p>
            </div>
        </div>
    </div>
</div>

<script>
// Newsletter Modal Trigger
document.addEventListener('DOMContentLoaded', function() {
    // Check if user has already subscribed or closed the popup
    const hasSeenNewsletter = localStorage.getItem('newsletterSeen');
    const hasSubscribed = localStorage.getItem('newsletterSubscribed');
    
    if (!hasSeenNewsletter && !hasSubscribed) {
        // Show newsletter popup after 5 seconds
        setTimeout(function() {
            const newsletterModal = new mdb.Modal(document.getElementById('newsletterModal'));
            newsletterModal.show();
            localStorage.setItem('newsletterSeen', 'true');
        }, 5000); // 5 seconds delay
    }
    
    // Handle newsletter form submission
    document.getElementById('newsletterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('newsletter_email').value;
        
    // Send to server via AJAX
    fetch('/api/newsletter-subscribe.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'email=' + encodeURIComponent(email)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                document.querySelector('#newsletterModal .modal-body').innerHTML = `
                    <div class="text-center py-5">
                        <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                            <i class="fas fa-check fa-3x text-success"></i>
                        </div>
                        <h3 class="fw-bold mb-3">Thank You!</h3>
                        <p class="text-muted mb-4">
                            You've successfully subscribed to our newsletter.<br>
                            Check your email for your <strong class="text-success">20% OFF</strong> coupon code!
                        </p>
                        <button type="button" class="btn btn-primary" data-mdb-dismiss="modal">
                            <i class="fas fa-shopping-bag me-2"></i>Start Shopping
                        </button>
                    </div>
                `;
                
                // Mark as subscribed
                localStorage.setItem('newsletterSubscribed', 'true');
                
                // Auto close after 3 seconds
                setTimeout(function() {
                    const modal = mdb.Modal.getInstance(document.getElementById('newsletterModal'));
                    modal.hide();
                }, 3000);
            } else {
                alert(data.message || 'Subscription failed. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    });
});
</script>

<style>
/* Newsletter Modal Animations */
#newsletterModal .modal-content {
    animation: slideInDown 0.5s ease-out;
}

@keyframes slideInDown {
    from {
        transform: translateY(-100px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

#newsletterModal .modal-body {
    transition: all 0.3s ease;
}

#newsletterModal .input-group input:focus {
    box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
    border-color: #667eea;
}

#newsletterModal .btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    transition: all 0.3s ease;
}

#newsletterModal .btn-primary:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}
</style>

</body>
</html>
<?php
// Flush output buffer that was started in header.php
if (ob_get_level() > 0) {
    ob_end_flush();
}
?>