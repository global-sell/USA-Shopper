<?php
require_once '../config/config.php';

// Admin authentication check
if (!isLoggedIn() || !isAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$testEmail = $input['email'] ?? '';

if (empty($testEmail) || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

// Prepare test email
$subject = "Test Email from " . getSetting('site_name', 'Rangpur Food');
$message = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 30px auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; color: white; }
        .content { padding: 30px; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #888; font-size: 14px; }
        .badge { display: inline-block; background: #28a745; color: white; padding: 5px 15px; border-radius: 20px; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>✅ Test Email</h1>
            <span class='badge'>Email Configuration Working!</span>
        </div>
        <div class='content'>
            <h2>Hello!</h2>
            <p>This is a test email from your Rangpur Food admin panel.</p>
            <p>If you're reading this, your email configuration is working correctly!</p>
            <p><strong>Sent at:</strong> " . date('Y-m-d H:i:s') . "</p>
            <p><strong>From:</strong> " . getSetting('from_name', 'Rangpur Food') . " &lt;" . getSetting('from_email', 'noreply@rangpurfood.com') . "&gt;</p>
        </div>
        <div class='footer'>
            <p><strong>" . getSetting('site_name', 'Rangpur Food') . "</strong></p>
            <p>© " . date('Y') . " All rights reserved.</p>
        </div>
    </div>
</body>
</html>
";

// Send email
$result = sendEmail($testEmail, $subject, $message);

if ($result) {
    echo json_encode([
        'success' => true, 
        'message' => 'Test email sent successfully! Check your inbox at ' . $testEmail
    ]);
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to send test email. Check logs/emails.log for details.'
    ]);
}
