<?php
ob_start(); // Start output buffering to prevent "headers already sent" errors
require_once __DIR__ . '/../config/config.php';

// Check maintenance mode (will exit if maintenance is enabled and user is not admin)
require_once __DIR__ . '/maintenance-check.php';

$currentUser = getCurrentUser();
$siteName = getSetting('site_name', 'YBT Digital');

// Define variables needed for analytics tracking
$googleAnalyticsId = getSetting('google_analytics_id', 'G-X0ZXK1ZT9C');
$facebookPixelId = getSetting('facebook_pixel_id', '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="yandex-verification" content="a48733b9aec24f87" />
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NX7X6D6Z');</script>
<!-- End Google Tag Manager -->
    
<?php if ($googleAnalyticsId): ?>
<!-- Google Analytics (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo htmlspecialchars($googleAnalyticsId); ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo htmlspecialchars($googleAnalyticsId); ?>');
</script>
<?php endif; ?>

<?php if ($facebookPixelId): ?>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo htmlspecialchars($facebookPixelId); ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo htmlspecialchars($facebookPixelId); ?>&ev=PageView&noscript=1"
/></noscript>
<?php endif; ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . $siteName : $siteName; ?></title>
    <?php 
    $siteMetaDescription = getSetting('site_meta_description', 'Welcome to ' . $siteName . ' - Your trusted online shopping destination for quality products at great prices.');
    $pageMetaDescription = isset($metaDescription) ? $metaDescription : $siteMetaDescription;
    $siteKeywords = getSetting('site_keywords', 'online shopping, ecommerce, quality products, fast delivery');
    $ogImage = getSetting('og_image', SITE_URL . '/assets/images/logo.png');
    $twitterHandle = getSetting('twitter_handle', '');
    ?>
    <meta name="description" content="<?php echo htmlspecialchars($pageMetaDescription); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($siteKeywords); ?>">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ? SITE_URL . $_SERVER['REQUEST_URI'] : SITE_URL); ?>">
    <meta property="og:title" content="<?php echo isset($pageTitle) ? htmlspecialchars($pageTitle . ' - ' . $siteName) : htmlspecialchars($siteName); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageMetaDescription); ?>">
    <meta property="og:image" content="<?php echo htmlspecialchars($ogImage); ?>">
    <meta property="og:site_name" content="<?php echo htmlspecialchars($siteName); ?>">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ? SITE_URL . $_SERVER['REQUEST_URI'] : SITE_URL); ?>">
    <meta property="twitter:title" content="<?php echo isset($pageTitle) ? htmlspecialchars($pageTitle . ' - ' . $siteName) : htmlspecialchars($siteName); ?>">
    <meta property="twitter:description" content="<?php echo htmlspecialchars($pageMetaDescription); ?>">
    <meta property="twitter:image" content="<?php echo htmlspecialchars($ogImage); ?>">
    <?php if ($twitterHandle): ?>
    <meta property="twitter:site" content="<?php echo htmlspecialchars($twitterHandle); ?>">
    <?php endif; ?>
    <meta name="yandex-verification" content="a48733b9aec24f87" />


    <!--  Favicon added -->
    <link rel="icon" type="image/png" href="https://www.usashopper.site/wp-content/uploads/2025/09/ChatGPT-Image-Sep-6-2025-10_03_09-PM-4-100x100.png?v=2">
    <link rel="shortcut icon" type="image/png" href="https://www.usashopper.site/wp-content/uploads/2025/09/ChatGPT-Image-Sep-6-2025-10_03_09-PM-4-100x100.png?v=2">
    
    <!-- Material Design Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <?php 
    $faviconPath = getSetting('favicon_path', 'assets/images/favicon.svg');
    $faviconUrl = SITE_URL . '/' . $faviconPath;
    $faviconExt = pathinfo($faviconPath, PATHINFO_EXTENSION);
    $faviconType = match($faviconExt) {
        'svg' => 'image/svg+xml',
        'png' => 'image/png',
        'jpg', 'jpeg' => 'image/jpeg',
        'ico' => 'image/x-icon',
        default => 'image/x-icon'
    };
    ?>
    <link rel="icon" href="<?php echo $faviconUrl; ?>" type="<?php echo $faviconType; ?>">
    <link rel="shortcut icon" href="<?php echo $faviconUrl; ?>" type="<?php echo $faviconType; ?>">
    <link rel="apple-touch-icon" href="<?php echo $faviconUrl; ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Cloudflare Turnstile -->
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    
    <style>
        :root {
            --primary-color: #1976d2;
            --secondary-color: #dc004e;
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --danger-color: #f44336;
            --dark-bg: #121212;
            --dark-surface: #1e1e1e;
            --dark-card: #2d2d2d;
            --light-bg: #f5f5f5;
            --light-surface: #ffffff;
            --text-primary-light: #212121;
            --text-secondary-light: #757575;
            --text-primary-dark: #ffffff;
            --text-secondary-dark: #b0b0b0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            transition: background-color 0.3s, color 0.3s;
        }

        /* Light Mode */
        body.light-mode {
            background-color: var(--light-bg);
            color: var(--text-primary-light);
        }

        body.light-mode .navbar {
            background-color: var(--light-surface) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        body.light-mode .card {
            background-color: var(--light-surface);
            color: var(--text-primary-light);
        }

        /* Dark Mode */
        body.dark-mode {
            background-color: var(--dark-bg);
            color: var(--text-primary-dark);
        }

        body.dark-mode .navbar {
            background-color: var(--dark-surface) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }

        body.dark-mode .navbar-brand,
        body.dark-mode .nav-link {
            color: var(--text-primary-dark) !important;
        }

        body.dark-mode .card {
            background-color: var(--dark-card);
            color: var(--text-primary-dark);
        }

        body.dark-mode .form-control,
        body.dark-mode .form-select {
            background-color: var(--dark-surface);
            color: var(--text-primary-dark);
            border-color: #444;
        }

        body.dark-mode .modal-content {
            background-color: var(--dark-card);
            color: var(--text-primary-dark);
        }

        /* Desktop Navbar */
        .desktop-navbar {
            display: block;
            background-color: #ffffff !important;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1030;
            transition: all 0.3s ease;
            padding: 0.5rem 0;
        }

        .desktop-navbar.scrolled {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        body.dark-mode .desktop-navbar {
            background-color: #1f2937 !important;
            border-bottom: 1px solid #374151;
        }

        .navbar-brand {
            font-size: 1.25rem;
            font-weight: 600;
            color: #111827 !important;
            transition: all 0.3s ease;
        }

        body.dark-mode .navbar-brand {
            color: #f9fafb !important;
        }

        .navbar-brand:hover {
            opacity: 0.8;
        }

        .nav-link {
            font-weight: 400;
            font-size: 0.95rem;
            color: #6b7280 !important;
            position: relative;
            transition: all 0.3s ease;
            padding: 0.5rem 1rem !important;
        }

        body.dark-mode .nav-link {
            color: #9ca3af !important;
        }

        .nav-link:hover {
            color: #111827 !important;
        }

        body.dark-mode .nav-link:hover {
            color: #f9fafb !important;
        }

        .nav-link::after {
            display: none;
        }

        .dropdown-menu {
            border: none;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
            border-radius: 12px;
            padding: 0.5rem;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .dropdown-item {
            border-radius: 6px;
            padding: 0.5rem 1rem;
            transition: all 0.2s ease;
            color: #6b7280;
            font-size: 0.9rem;
        }

        .dropdown-item:hover {
            background: #f3f4f6;
            color: #111827;
        }

        body.dark-mode .dropdown-item {
            color: #9ca3af;
        }

        body.dark-mode .dropdown-item:hover {
            background: #374151;
            color: #f9fafb;
        }

        .mobile-bottom-nav {
            display: none;
        }

        /* Theme Toggle Button */
        .theme-toggle {
            cursor: pointer;
            font-size: 1.1rem;
            padding: 0.4rem;
            border: none;
            background: transparent;
            color: #6b7280;
            transition: all 0.3s ease;
            border-radius: 6px;
        }

        body.dark-mode .theme-toggle {
            color: #9ca3af;
        }

        .theme-toggle:hover {
            background: #f3f4f6;
            color: #111827;
        }

        body.dark-mode .theme-toggle:hover {
            background: #374151;
            color: #f9fafb;
        }

        /* Enhanced Buttons */
        .btn-primary {
            background: #3b82f6;
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: #2563eb;
        }

        /* Desktop - Hide Mobile Elements */
        @media (min-width: 769px) {
            .mobile-appbar,
            .mobile-bottom-nav,
            .mobile-menu-drawer,
            .mobile-menu-overlay,
            .mobile-menu-btn {
                display: none !important;
            }
        }

        /* Mobile Styles */
        @media (max-width: 768px) {
            .desktop-navbar {
                display: none !important;
            }

            .mobile-bottom-nav {
                display: flex;
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background-color: var(--light-surface);
                box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
                z-index: 1000;
                justify-content: space-around;
                padding: 0.5rem 0;
            }

            body.dark-mode .mobile-bottom-nav {
                background-color: var(--dark-surface);
                box-shadow: 0 -2px 10px rgba(0,0,0,0.5);
            }

            .mobile-bottom-nav .nav-item {
                flex: 1;
                text-align: center;
            }

            .mobile-bottom-nav .nav-link {
                display: flex;
                flex-direction: column;
                align-items: center;
                padding: 0.5rem;
                color: var(--text-secondary-light);
                text-decoration: none;
                font-size: 0.75rem;
            }

            body.dark-mode .mobile-bottom-nav .nav-link {
                color: var(--text-secondary-dark);
            }

            .mobile-bottom-nav .nav-link.active,
            .mobile-bottom-nav .nav-link:hover {
                color: var(--primary-color);
            }

            .mobile-bottom-nav .nav-link i {
                font-size: 1.5rem;
                margin-bottom: 0.25rem;
            }

            /* Mobile AppBar */
            .mobile-appbar {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 1rem;
                background-color: var(--light-surface);
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                position: sticky;
                top: 0;
                z-index: 1030;
            }

            body.dark-mode .mobile-appbar {
                background-color: var(--dark-surface);
            }

            .mobile-appbar .logo {
                font-size: 1.25rem;
                font-weight: 700;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .mobile-menu-btn {
                background: none;
                border: none;
                font-size: 1.5rem;
                color: inherit;
                cursor: pointer;
            }

            /* Mobile Menu Drawer */
            .mobile-menu-drawer {
                position: fixed;
                top: 0;
                left: -100%;
                width: 80%;
                max-width: 300px;
                height: 100vh;
                background-color: var(--light-surface);
                box-shadow: 2px 0 10px rgba(0,0,0,0.1);
                z-index: 1040;
                transition: left 0.3s ease;
                overflow-y: auto;
                display: block;
            }

            body.dark-mode .mobile-menu-drawer {
                background-color: var(--dark-surface);
            }

            .mobile-menu-drawer.open {
                left: 0;
            }

            .mobile-menu-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100vh;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 1035;
                display: none;
            }

            .mobile-menu-overlay.show {
                display: block;
            }

            .mobile-menu-header {
                padding: 1.5rem;
                border-bottom: 1px solid rgba(0, 0, 0, 0.1);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            body.dark-mode .mobile-menu-header {
                border-bottom-color: rgba(255, 255, 255, 0.1);
            }

            .mobile-menu-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                color: inherit;
                cursor: pointer;
            }

            .mobile-menu-items {
                padding: 1rem 0;
            }

            .mobile-menu-item {
                padding: 1rem 1.5rem;
                display: flex;
                align-items: center;
                color: inherit;
                text-decoration: none;
                transition: all 0.2s ease;
                border-left: 3px solid transparent;
            }

            .mobile-menu-item:hover,
            .mobile-menu-item.active {
                background: rgba(102, 126, 234, 0.1);
                border-left-color: #667eea;
            }

            .mobile-menu-item i {
                width: 30px;
                margin-right: 1rem;
            }

            /* Add bottom padding to content for mobile nav */
            .main-content {
                padding-bottom: 80px;
            }
        }

        /* Product Cards */
        .product-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            cursor: pointer;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        }

        .product-card img {
            height: 200px;
            object-fit: cover;
        }

        /* Buttons */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #1565c0;
            border-color: #1565c0;
        }

        /* Cart Badge */
        .cart-badge {
            background: #ef4444;
            color: white;
            border-radius: 50%;
            min-width: 18px;
            height: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: 600;
            line-height: 1;
        }

        /* Smooth Animations */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="light-mode">

<!-- Desktop Navigation -->
<nav class="navbar navbar-expand-lg desktop-navbar">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="<?php echo SITE_URL; ?>">
            <img src="<?php echo SITE_URL; ?>/assets/images/logo.png" alt="<?php echo $siteName; ?>" 
                 style="height: 40px; margin-right: 10px;" 
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='inline'">
            <i class="fas fa-shopping-bag me-2" style="display: none;"></i>
            <span><?php echo $siteName; ?></span>
        </a>
        
        <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNav">
            <i class="fas fa-bars"></i>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo SITE_URL; ?>">
                        <i class="fas fa-home me-1"></i>Home
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-mdb-toggle="dropdown">
                        <i class="fas fa-shopping-bag me-1"></i>Shop
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/products">
                            <i class="fas fa-shopping-bag me-2"></i>All Products</a></li>
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/products?sort=latest">
                            <i class="fas fa-star me-2"></i>New Arrivals</a></li>
                        <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/products?sort=popular">
                            <i class="fas fa-fire me-2"></i>Best Sellers</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo SITE_URL; ?>/about">
                        <i class="fas fa-info-circle me-1"></i>About Us
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo SITE_URL; ?>/contact">
                        <i class="fas fa-envelope me-1"></i>Contact Us
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo SITE_URL; ?>/blogs">
                        <i class="fas fa-blog me-1"></i>Our Blogs
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://globalsell.site/track-order" target="_blank">
                        <i class="fas fa-map-marker-alt me-1"></i>Order Tracking
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo SITE_URL; ?>/official-store">
                        <i class="fas fa-store me-1"></i>Official Store
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link position-relative d-flex align-items-center" href="<?php echo SITE_URL; ?>/cart">
                        <i class="fas fa-shopping-cart me-1" style="font-size: 1.1rem;"></i>
                        <span>Cart</span>
                        <span class="cart-badge" id="cart-count-nav" style="position: absolute; top: 0; right: 5px; background: #ef4444; color: white; border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 600;">0</span>
                    </a>
                </li>
                <?php if (isLoggedIn()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                           data-mdb-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($currentUser['name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/profile">
                                <i class="fas fa-user me-2"></i>My Account</a></li>
                            <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/orders">
                                <i class="fas fa-box me-2"></i>My Orders</a></li>
                            <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/checkout">
                                <i class="fas fa-credit-card me-2"></i>Checkout</a></li>
                            <?php if (isAdmin()): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo ADMIN_URL; ?>">
                                    <i class="fas fa-cog me-2"></i>Admin Dashboard</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/logout">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/login">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-primary btn-sm ms-2" href="<?php echo SITE_URL; ?>/signup">Sign Up</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
                        <i class="fas fa-moon" id="theme-icon"></i>
                    </button>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Mobile AppBar -->
<div class="mobile-appbar d-lg-none">
    <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
        <i class="fas fa-bars"></i>
    </button>
    <a href="<?php echo SITE_URL; ?>" class="logo d-flex align-items-center text-decoration-none">
        <img src="<?php echo SITE_URL; ?>/assets/images/logo.png" alt="<?php echo $siteName; ?>" 
             style="height: 30px; margin-right: 8px;" 
             onerror="this.style.display='none'">
        <span><?php echo $siteName; ?></span>
    </a>
    <div>
        <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
            <i class="fas fa-moon" id="theme-icon-mobile"></i>
        </button>
    </div>
</div>

<!-- Mobile Menu Drawer -->
<div class="mobile-menu-overlay" id="mobileMenuOverlay" onclick="toggleMobileMenu()"></div>
<div class="mobile-menu-drawer" id="mobileMenuDrawer">
    <div class="mobile-menu-header">
        <div class="logo d-flex align-items-center">
            <img src="<?php echo SITE_URL; ?>/assets/images/logo.png" alt="<?php echo $siteName; ?>" 
                 style="height: 30px; margin-right: 8px;" 
                 onerror="this.style.display='none'">
            <span><?php echo $siteName; ?></span>
        </div>
        <button class="mobile-menu-close" onclick="toggleMobileMenu()">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="mobile-menu-items">
        <a href="<?php echo SITE_URL; ?>" class="mobile-menu-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/products" class="mobile-menu-item">
            <i class="fas fa-shopping-bag"></i>
            <span>Shop</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/cart" class="mobile-menu-item">
            <i class="fas fa-shopping-cart"></i>
            <span>Cart</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/about" class="mobile-menu-item">
            <i class="fas fa-info-circle"></i>
            <span>About Us</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/contact" class="mobile-menu-item">
            <i class="fas fa-envelope"></i>
            <span>Contact Us</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/blogs" class="mobile-menu-item">
            <i class="fas fa-blog"></i>
            <span>Our Blogs</span>
        </a>
        <a href="https://globalsell.site/track-order" target="_blank" class="mobile-menu-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Order Tracking</span>
        </a>
        <a href="<?php echo SITE_URL; ?>/official-store" class="mobile-menu-item">
            <i class="fas fa-store"></i>
            <span>Official Store</span>
        </a>
        <?php if (isLoggedIn()): ?>
            <a href="<?php echo SITE_URL; ?>/orders" class="mobile-menu-item">
                <i class="fas fa-box"></i>
                <span>My Orders</span>
            </a>
            <?php if (isAdmin()): ?>
                <a href="<?php echo ADMIN_URL; ?>" class="mobile-menu-item">
                    <i class="fas fa-cog"></i>
                    <span>Admin Dashboard</span>
                </a>
            <?php endif; ?>
            <a href="<?php echo SITE_URL; ?>/logout" class="mobile-menu-item">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        <?php else: ?>
            <a href="<?php echo SITE_URL; ?>/login" class="mobile-menu-item">
                <i class="fas fa-sign-in-alt"></i>
                <span>Login</span>
            </a>
            <a href="<?php echo SITE_URL; ?>/signup" class="mobile-menu-item">
                <i class="fas fa-user-plus"></i>
                <span>Sign Up</span>
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Mobile Bottom Navigation -->
<nav class="mobile-bottom-nav d-lg-none">
    <div class="nav-item">
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
           href="<?php echo SITE_URL; ?>">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
    </div>
    <div class="nav-item">
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>" 
           href="<?php echo SITE_URL; ?>/products">
            <i class="fas fa-th-large"></i>
            <span>Products</span>
        </a>
    </div>
    <?php if (isLoggedIn()): ?>
        <div class="nav-item">
            <a class="nav-link position-relative <?php echo basename($_SERVER['PHP_SELF']) == 'cart.php' ? 'active' : ''; ?>" 
               href="<?php echo SITE_URL; ?>/cart">
                <i class="fas fa-shopping-cart"></i>
                <span>Cart</span>
                <span class="cart-badge" id="cart-count-mobile">0</span>
            </a>
        </div>
        <div class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>" 
               href="<?php echo SITE_URL; ?>/profile">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
        </div>
    <?php else: ?>
        <div class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : ''; ?>" 
               href="<?php echo SITE_URL; ?>/login">
                <i class="fas fa-sign-in-alt"></i>
                <span>Login</span>
            </a>
        </div>
    <?php endif; ?>
</nav>

<div class="main-content">

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NX7X6D6Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script>
// Mobile Menu Toggle
function toggleMobileMenu() {
    const drawer = document.getElementById('mobileMenuDrawer');
    const overlay = document.getElementById('mobileMenuOverlay');
    
    if (drawer && overlay) {
        drawer.classList.toggle('open');
        overlay.classList.toggle('show');
    }
}

// Theme Toggle Function
function toggleTheme() {
    const body = document.body;
    const themeIcon = document.getElementById('theme-icon');
    const themeIconMobile = document.getElementById('theme-icon-mobile');
    
    if (body.classList.contains('light-mode')) {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
        if (themeIcon) themeIcon.classList.replace('fa-moon', 'fa-sun');
        if (themeIconMobile) themeIconMobile.classList.replace('fa-moon', 'fa-sun');
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.remove('dark-mode');
        body.classList.add('light-mode');
        if (themeIcon) themeIcon.classList.replace('fa-sun', 'fa-moon');
        if (themeIconMobile) themeIconMobile.classList.replace('fa-sun', 'fa-moon');
        localStorage.setItem('theme', 'light');
    }
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const body = document.body;
    const themeIcon = document.getElementById('theme-icon');
    const themeIconMobile = document.getElementById('theme-icon-mobile');
    
    if (savedTheme === 'dark') {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
        if (themeIcon) themeIcon.classList.replace('fa-moon', 'fa-sun');
        if (themeIconMobile) themeIconMobile.classList.replace('fa-sun', 'fa-moon');
    }
    
    // Update cart count
    updateCartCount();
    
    // Add scroll effect to navbar
    const navbar = document.querySelector('.desktop-navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }
});

// Update Cart Count
function updateCartCount() {
    fetch('<?php echo SITE_URL; ?>/api/cart-count.php')
        .then(response => response.json())
        .then(data => {
            const countNav = document.getElementById('cart-count-nav');
            const countMobile = document.getElementById('cart-count-mobile');
            if (countNav) countNav.textContent = data.count || 0;
            if (countMobile) countMobile.textContent = data.count || 0;
            
            // Show/hide badge if count is 0
            if (data.count > 0) {
                if (countNav) countNav.style.display = 'flex';
                if (countMobile) countMobile.style.display = 'flex';
            } else {
                if (countNav) countNav.style.display = 'none';
                if (countMobile) countMobile.style.display = 'none';
            }
        })
        .catch(error => console.error('Error fetching cart count:', error));
}
</script>