<?php
$pageTitle = "Manage Blogs";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

// Handle delete
if (isset($_GET['delete'])) {
    $blogId = (int)$_GET['delete'];
    
    // Get blog image to delete
    $blog = $db->query("SELECT featured_image FROM blogs WHERE id = $blogId")->fetch_assoc();
    if ($blog && !empty($blog['featured_image'])) {
        $imagePath = UPLOADS_PATH . '/blogs/' . $blog['featured_image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    $db->query("DELETE FROM blogs WHERE id = $blogId");
    redirect(ADMIN_URL . '/blogs.php?deleted=1');
}

// Handle toggle status
if (isset($_GET['toggle_status'])) {
    $blogId = (int)$_GET['toggle_status'];
    $db->query("UPDATE blogs SET status = IF(status = 'published', 'draft', 'published') WHERE id = $blogId");
    redirect(ADMIN_URL . '/blogs.php?updated=1');
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Get total count
$totalBlogs = $db->query("SELECT COUNT(*) as total FROM blogs")->fetch_assoc()['total'];
$totalPages = ceil($totalBlogs / $perPage);

// Get blogs
$blogs = $db->query("SELECT * FROM blogs ORDER BY created_at DESC LIMIT $perPage OFFSET $offset")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">
            <i class="fas fa-blog me-2"></i>Manage Blogs
        </h2>
        <a href="<?php echo ADMIN_URL; ?>/add-blog.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add New Blog
        </a>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Blog deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['added'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Blog added successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body p-0">
            <?php if (empty($blogs)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-blog fa-4x text-muted mb-3"></i>
                    <h5>No blogs yet</h5>
                    <p class="text-muted">Start by adding your first blog post</p>
                    <a href="<?php echo ADMIN_URL; ?>/add-blog.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add New Blog
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Category</th>
                                <th>Views</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($blogs as $blog): ?>
                                <tr>
                                    <td><?php echo $blog['id']; ?></td>
                                    <td>
                                        <?php if (!empty($blog['featured_image'])): ?>
                                            <img src="<?php echo UPLOADS_URL; ?>/blogs/<?php echo $blog['featured_image']; ?>" 
                                                 alt="<?php echo htmlspecialchars($blog['title']); ?>" 
                                                 style="width: 60px; height: 40px; object-fit: cover; border-radius: 5px;">
                                        <?php else: ?>
                                            <div style="width: 60px; height: 40px; background: #e0e0e0; border-radius: 5px; display: flex; align-items: center; justify-content: center;">
                                                <i class="fas fa-image text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($blog['title']); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo substr(htmlspecialchars($blog['excerpt']), 0, 50); ?>...</small>
                                    </td>
                                    <td><?php echo htmlspecialchars($blog['author'] ?? 'Admin'); ?></td>
                                    <td>
                                        <?php if ($blog['category']): ?>
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($blog['category']); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <i class="fas fa-eye me-1"></i><?php echo $blog['views']; ?>
                                    </td>
                                    <td>
                                        <?php if ($blog['status'] === 'published'): ?>
                                            <span class="badge bg-success">Published</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small><?php echo date('M j, Y', strtotime($blog['created_at'])); ?></small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?php echo SITE_URL; ?>/blog-detail.php?slug=<?php echo $blog['slug']; ?>" 
                                               class="btn btn-info" target="_blank" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo ADMIN_URL; ?>/edit-blog.php?id=<?php echo $blog['id']; ?>" 
                                               class="btn btn-primary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="?toggle_status=<?php echo $blog['id']; ?>" 
                                               class="btn btn-warning" title="Toggle Status">
                                                <i class="fas fa-toggle-on"></i>
                                            </a>
                                            <a href="?delete=<?php echo $blog['id']; ?>" 
                                               class="btn btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this blog?')" 
                                               title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="card-footer">
                        <nav aria-label="Blog pagination">
                            <ul class="pagination justify-content-center mb-0">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
