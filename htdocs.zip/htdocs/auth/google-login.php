<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/google-oauth.php';

// Redirect to Google OAuth using the helper function
$authUrl = getGoogleLoginUrl();
header('Location: ' . $authUrl);
exit;
?>
