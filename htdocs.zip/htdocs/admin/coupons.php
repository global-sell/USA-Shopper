<?php
$pageTitle = "Manage Coupons";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

// Handle add coupon
if (isset($_POST['add_coupon'])) {
    $code = strtoupper(sanitizeInput($_POST['code'] ?? ''));
    $discountType = sanitizeInput($_POST['discount_type'] ?? 'flat');
    $discountValue = (float)($_POST['discount_value'] ?? 0);
    $minPurchase = (float)($_POST['min_purchase'] ?? 0);
    $maxUsage = !empty($_POST['max_usage']) ? (int)$_POST['max_usage'] : null;
    $expiresAt = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
    
    if (empty($code) || $discountValue <= 0) {
        $error = 'Please fill in all required fields';
    } else {
        $stmt = $db->prepare("INSERT INTO coupons (code, discount_type, discount_value, min_purchase, max_usage, expires_at) 
                             VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssddis", $code, $discountType, $discountValue, $minPurchase, $maxUsage, $expiresAt);
        
        if ($stmt->execute()) {
            $success = 'Coupon added successfully';
        } else {
            $error = 'Failed to add coupon. Code might already exist.';
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $couponId = (int)$_GET['delete'];
    $db->query("DELETE FROM coupons WHERE id = $couponId");
    redirect(ADMIN_URL . '/coupons.php?deleted=1');
}

// Handle toggle status
if (isset($_GET['toggle_status'])) {
    $couponId = (int)$_GET['toggle_status'];
    $db->query("UPDATE coupons SET status = IF(status = 'active', 'inactive', 'active') WHERE id = $couponId");
    redirect(ADMIN_URL . '/coupons.php?updated=1');
}

// Get all coupons
$coupons = $db->query("SELECT * FROM coupons ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">
        <i class="fas fa-tag me-2"></i>Manage Coupons
    </h2>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Coupon deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Coupon status updated successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Add Coupon Form -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Add New Coupon</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-outline mb-3">
                            <input type="text" id="code" name="code" class="form-control" required>
                            <label class="form-label" for="code">Coupon Code</label>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Discount Type</label>
                            <select name="discount_type" class="form-select">
                                <option value="flat">Flat Amount</option>
                                <option value="percentage">Percentage</option>
                            </select>
                        </div>
                        
                        <div class="form-outline mb-3">
                            <input type="number" id="discount_value" name="discount_value" class="form-control" 
                                   step="0.01" min="0" required>
                            <label class="form-label" for="discount_value">Discount Value</label>
                        </div>
                        
                        <div class="form-outline mb-3">
                            <input type="number" id="min_purchase" name="min_purchase" class="form-control" 
                                   step="0.01" min="0" value="0">
                            <label class="form-label" for="min_purchase">Min Purchase Amount</label>
                        </div>
                        
                        <div class="form-outline mb-3">
                            <input type="number" id="max_usage" name="max_usage" class="form-control" min="1">
                            <label class="form-label" for="max_usage">Max Usage (optional)</label>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label" for="expires_at">Expires At (optional)</label>
                            <input type="datetime-local" id="expires_at" name="expires_at" class="form-control">
                        </div>
                        
                        <button type="submit" name="add_coupon" class="btn btn-primary w-100">
                            <i class="fas fa-plus me-2"></i>Add Coupon
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Coupons List -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Code</th>
                                    <th>Discount</th>
                                    <th>Min Purchase</th>
                                    <th>Usage</th>
                                    <th>Expires</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($coupons as $coupon): ?>
                                    <tr>
                                        <td class="fw-bold"><?php echo htmlspecialchars($coupon['code']); ?></td>
                                        <td>
                                            <?php 
                                            if ($coupon['discount_type'] === 'flat') {
                                                echo formatPrice($coupon['discount_value']);
                                            } else {
                                                echo $coupon['discount_value'] . '%';
                                            }
                                            ?>
                                        </td>
                                        <td><?php echo formatPrice($coupon['min_purchase']); ?></td>
                                        <td>
                                            <?php echo $coupon['used_count']; ?>
                                            <?php if ($coupon['max_usage']): ?>
                                                / <?php echo $coupon['max_usage']; ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php 
                                            if ($coupon['expires_at']) {
                                                echo date('M j, Y', strtotime($coupon['expires_at']));
                                            } else {
                                                echo 'Never';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <?php if ($coupon['status'] === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="?toggle_status=<?php echo $coupon['id']; ?>" 
                                                   class="btn btn-warning" title="Toggle Status">
                                                    <i class="fas fa-toggle-on"></i>
                                                </a>
                                                <a href="?delete=<?php echo $coupon['id']; ?>" 
                                                   class="btn btn-danger" 
                                                   onclick="return confirmDelete('Are you sure you want to delete this coupon?')" 
                                                   title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
