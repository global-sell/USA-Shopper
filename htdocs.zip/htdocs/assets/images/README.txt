LOGO SETUP INSTRUCTIONS
========================

To add the USA Shopper logo to your website:

1. Save the USA Shopper logo image as "logo.png" in this folder:
   c:\xampp\htdocs\Rangpur food\assets\images\logo.png

2. The logo should be:
   - Format: PNG with transparent background
   - Recommended size: 200x80px or similar
   - The logo will be automatically resized to:
     * 40px height on desktop
     * 30px height on mobile

3. The logo appears in:
   - Desktop navbar (top left)
   - Mobile app bar (top center)
   - Mobile menu drawer (header)

4. If the logo file is not found, the site will show a shopping bag icon as fallback.

CURRENT LOGO DESIGN:
- Blue shopping bag with "USA" text
- Red stripes underneath
- "SHOPPER" text in red

The logo is already configured in the header.php file and will display automatically
once you place the logo.png file in this directory.
