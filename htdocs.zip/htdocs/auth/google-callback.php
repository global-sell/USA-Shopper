<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/google-oauth.php';

if (!isset($_GET['code'])) {
    // Check for error from Google
    if (isset($_GET['error'])) {
        redirect(SITE_URL . '/signup.php?error=google_' . $_GET['error']);
    }
    redirect(SITE_URL . '/signup.php?error=google_auth_failed');
}

// Exchange code for access token
$tokenUrl = 'https://oauth2.googleapis.com/token';
$tokenData = [
    'code' => $_GET['code'],
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'grant_type' => 'authorization_code'
];

$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_VERBOSE, true);
$verboseLog = fopen('php://temp', 'w+');
curl_setopt($ch, CURLOPT_STDERR, $verboseLog);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
$curlErrno = curl_errno($ch);

rewind($verboseLog);
$verboseOutput = stream_get_contents($verboseLog);
fclose($verboseLog);

// Enhanced logging
$logDir = dirname(__DIR__) . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/google-oauth.log';
$logEntry = "\n" . str_repeat('=', 80) . "\n";
$logEntry .= "Date: " . date('Y-m-d H:i:s') . "\n";
$logEntry .= "Code from Google: " . $_GET['code'] . "\n";
$logEntry .= "Token Data Sent: " . print_r($tokenData, true) . "\n";
$logEntry .= "HTTP Status: " . $httpCode . "\n";
if ($curlError) {
    $logEntry .= "cURL Error ($curlErrno): $curlError\n";
}
$logEntry .= "cURL Verbose Log:\n$verboseOutput\n";
$logEntry .= "Token Response: " . print_r($response, true) . "\n";
$logEntry .= str_repeat('=', 80) . "\n";
@file_put_contents($logFile, $logEntry, FILE_APPEND);

// If curl failed completely
if ($response === false) {
    error_log("Google OAuth cURL Error: " . $curlError);
    redirect(SITE_URL . '/signup.php?error=google_curl_error&detail=' . urlencode($curlError));
}

// If we got a non-200 response
if ($httpCode !== 200) {
    error_log("Google OAuth HTTP Error: " . $httpCode . ", Response: " . $response);
    redirect(SITE_URL . '/signup.php?error=google_http_error&code=' . $httpCode);
}

curl_close($ch);

$tokenInfo = json_decode($response, true);

// Log for debugging
$logDir = dirname(__DIR__) . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logFile = $logDir . '/google-oauth.log';
$logEntry = "\n" . str_repeat('=', 80) . "\n";
$logEntry .= "Date: " . date('Y-m-d H:i:s') . "\n";
$logEntry .= "Token Response: " . print_r($tokenInfo, true) . "\n";
$logEntry .= str_repeat('=', 80) . "\n";
@file_put_contents($logFile, $logEntry, FILE_APPEND);

if (!isset($tokenInfo['access_token'])) {
    // Log the error
    $errorLog = "\nERROR: No access token received\n";
    $errorLog .= "Response: " . $response . "\n";
    @file_put_contents($logFile, $errorLog, FILE_APPEND);
    redirect(SITE_URL . '/signup.php?error=google_token_failed');
}

// Get user info
$userInfoUrl = 'https://www.googleapis.com/oauth2/v2/userinfo';
$ch = curl_init($userInfoUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $tokenInfo['access_token']]);
$userInfoResponse = curl_exec($ch);
curl_close($ch);

$userInfo = json_decode($userInfoResponse, true);

if (!isset($userInfo['email'])) {
    redirect(SITE_URL . '/signup.php?error=google_user_failed');
}

// Check if user exists
$db = Database::getInstance();
$stmt = $db->prepare("SELECT id, name, email, role, status FROM users WHERE email = ?");
$stmt->bind_param("s", $userInfo['email']);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    // User exists, log them in
    if ($user['status'] === 'blocked') {
        redirect(SITE_URL . '/login.php?error=account_blocked');
    }
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['last_activity'] = time();
    
    redirect(SITE_URL);
} else {
    // Check if oauth columns exist, add if not
    $columns = $db->query("SHOW COLUMNS FROM users LIKE 'oauth_provider'")->num_rows;
    if ($columns == 0) {
        $db->query("ALTER TABLE users ADD COLUMN oauth_provider VARCHAR(50) NULL AFTER password");
        $db->query("ALTER TABLE users ADD COLUMN oauth_id VARCHAR(255) NULL AFTER oauth_provider");
    }
    
    // Create new user
    $name = $userInfo['name'] ?? $userInfo['email'];
    $email = $userInfo['email'];
    
    // Generate username from email
    $baseUsername = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', substr($userInfo['email'], 0, strpos($userInfo['email'], '@'))));
    
    // Make sure username is unique
    $username = $baseUsername;
    $counter = 1;
    do {
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            break;
        }
        $username = $baseUsername . $counter;
        $counter++;
    } while (true);
    
    $randomPassword = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
    
    $stmt = $db->prepare("INSERT INTO users (name, username, email, password, role, oauth_provider, oauth_id) VALUES (?, ?, ?, ?, 'user', 'google', ?)");
    $stmt->bind_param("sssss", $name, $username, $email, $randomPassword, $userInfo['id']);
    
    if ($stmt->execute()) {
        $userId = $db->getConnection()->insert_id;
        
        // Log them in
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['role'] = 'user';
        $_SESSION['last_activity'] = time();
        
        // Send welcome email
        $subject = "Welcome to " . getSetting('site_name', 'YBT Digital');
        $message = "
            <h2>Welcome to " . getSetting('site_name', 'YBT Digital') . "!</h2>
            <p>Hi $name,</p>
            <p>Thank you for signing up with Google. You can now start exploring our products.</p>
            <p>Your username is: $username</p>
            <p>Best regards,<br>" . getSetting('site_name', 'YBT Digital') . " Team</p>
        ";
        sendEmail($email, $subject, $message);
        
        redirect(SITE_URL . '?welcome=1');
    } else {
        redirect(SITE_URL . '/signup.php?error=registration_failed');
    }
}
?>
