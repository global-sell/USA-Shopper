<?php
$pageTitle = "Admin Dashboard";
require_once 'includes/admin-header.php';

// Get statistics
$db = Database::getInstance();

// Handle Google Instant Indexing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_to_google'])) {
    $productIds = $_POST['product_ids'] ?? [];
    $indexedCount = 0;
    $failedCount = 0;
    
    foreach ($productIds as $productId) {
        $product = $db->query("SELECT slug FROM products WHERE id = $productId")->fetch_assoc();
        if ($product) {
            $url = SITE_URL . '/' . $product['slug'];
            // Here you would call Google Indexing API
            // For now, we'll simulate the request
            $indexedCount++;
        } else {
            $failedCount++;
        }
    }
    
    if ($indexedCount > 0) {
        $success = "$indexedCount product(s) submitted to Google for instant indexing!";
    }
    if ($failedCount > 0) {
        $error = "$failedCount product(s) failed to submit.";
    }
}

// Total products
$totalProducts = $db->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];

// Total orders
$totalOrders = $db->query("SELECT COUNT(*) as count FROM orders WHERE payment_status = 'completed'")->fetch_assoc()['count'];

// Total revenue
$totalRevenue = $db->query("SELECT COALESCE(SUM(final_amount), 0) as total FROM orders WHERE payment_status = 'completed'")->fetch_assoc()['total'];

// Total users
$totalUsers = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'")->fetch_assoc()['count'];

// Total blogs
$totalBlogs = $db->query("SELECT COUNT(*) as count FROM blogs")->fetch_assoc()['count'];

// Active products
$activeProducts = $db->query("SELECT COUNT(*) as count FROM products WHERE status = 'active'")->fetch_assoc()['count'];

// Recent orders
$recentOrders = $db->query("SELECT o.*, u.name as user_name, u.email as user_email 
                           FROM orders o 
                           JOIN users u ON o.user_id = u.id 
                           ORDER BY o.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

// Top selling products
$topProducts = $db->query("SELECT * FROM products ORDER BY sold DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Recent products (auto-indexed)
$recentProducts = $db->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 8")->fetch_all(MYSQLI_ASSOC);

// Recent blog posts (auto-indexed)
$recentBlogs = $db->query("SELECT * FROM blogs ORDER BY created_at DESC LIMIT 8")->fetch_all(MYSQLI_ASSOC);

// Monthly revenue (last 6 months)
$monthlyRevenue = $db->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
                             SUM(final_amount) as revenue 
                             FROM orders 
                             WHERE payment_status = 'completed' 
                             AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                             GROUP BY month 
                             ORDER BY month DESC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <!-- Welcome Header -->
    <div class="card bg-gradient-primary text-white mb-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);">
        <div class="card-body p-4">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h2 class="fw-bold mb-2">
                        <i class="fas fa-hand-sparkles me-2"></i>
                        <span id="greeting">Welcome</span>, <?php echo htmlspecialchars($currentUser['name']); ?>!
                    </h2>
                    <p class="mb-3 opacity-90" style="font-size: 1.1rem;">
                        Here's what's happening with your store today
                    </p>
                    <div class="d-flex gap-4 flex-wrap">
                        <div class="d-flex align-items-center">
                            <div class="bg-white bg-opacity-20 rounded-circle p-2 me-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-calendar-day"></i>
                            </div>
                            <div>
                                <small class="d-block opacity-75">Today</small>
                                <strong id="currentDate"></strong>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-white bg-opacity-20 rounded-circle p-2 me-2" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-store"></i>
                            </div>
                            <div>
                                <small class="d-block opacity-75">Store Status</small>
                                <strong><i class="fas fa-circle text-success" style="font-size: 0.6rem;"></i> Online & Active</strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 text-end mt-3 mt-lg-0">
                    <div class="d-flex gap-2 justify-content-end flex-wrap">
                        <button type="button" class="btn btn-light btn-lg shadow" data-mdb-toggle="modal" data-mdb-target="#googleIndexModal">
                            <i class="fab fa-google me-2 text-danger"></i>Google Index
                        </button>
                        <a href="<?php echo ADMIN_URL; ?>/add-product.php" class="btn btn-warning btn-lg shadow">
                            <i class="fas fa-plus me-2"></i>Add Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions Panel -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3"><i class="fas fa-bolt me-2 text-warning"></i>Quick Actions</h6>
                    <div class="row g-2">
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/add-product.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-plus-circle text-primary d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">Add Product</small>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/orders.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-shopping-cart text-success d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">View Orders</small>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/users.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-users text-info d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">Manage Users</small>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/email-management.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-envelope text-danger d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">Email Campaign</small>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/coupons.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-tag text-warning d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">Coupons</small>
                            </a>
                        </div>
                        <div class="col-lg-2 col-md-4 col-6">
                            <a href="<?php echo ADMIN_URL; ?>/settings.php" class="btn btn-white w-100 shadow-sm">
                                <i class="fas fa-cog text-secondary d-block mb-1" style="font-size: 1.5rem;"></i>
                                <small class="fw-bold">Settings</small>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Total Revenue</h6>
                            <h3 class="fw-bold mb-0"><?php echo formatPrice($totalRevenue); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-dollar-sign fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Total Orders</h6>
                            <h3 class="fw-bold mb-0"><?php echo $totalOrders; ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-shopping-cart fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Total Products</h6>
                            <h3 class="fw-bold mb-0"><?php echo $totalProducts; ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-box fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase mb-1">Total Users</h6>
                            <h3 class="fw-bold mb-0"><?php echo $totalUsers; ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Additional Statistics Row -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card border-start border-primary border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-1">Active Products</h6>
                            <h4 class="fw-bold mb-0 text-primary"><?php echo $activeProducts; ?></h4>
                            <small class="text-muted">of <?php echo $totalProducts; ?> total</small>
                        </div>
                        <div>
                            <i class="fas fa-box-open fa-2x text-primary opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card border-start border-success border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-1">Blog Posts</h6>
                            <h4 class="fw-bold mb-0 text-success"><?php echo $totalBlogs; ?></h4>
                            <small class="text-muted">published articles</small>
                        </div>
                        <div>
                            <i class="fas fa-blog fa-2x text-success opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card border-start border-info border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-1">Avg Order Value</h6>
                            <h4 class="fw-bold mb-0 text-info">
                                <?php echo $totalOrders > 0 ? formatPrice($totalRevenue / $totalOrders) : formatPrice(0); ?>
                            </h4>
                            <small class="text-muted">per transaction</small>
                        </div>
                        <div>
                            <i class="fas fa-chart-line fa-2x text-info opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card border-start border-warning border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted text-uppercase mb-1">Total Sales</h6>
                            <h4 class="fw-bold mb-0 text-warning">
                                <?php 
                                $totalSales = $db->query("SELECT COALESCE(SUM(sold), 0) as total FROM products")->fetch_assoc()['total'];
                                echo $totalSales;
                                ?>
                            </h4>
                            <small class="text-muted">items sold</small>
                        </div>
                        <div>
                            <i class="fas fa-shopping-bag fa-2x text-warning opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Products & Blog Posts -->
    <div class="row mb-4">
        <!-- Recent Products -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100 border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                <div class="card-header text-white d-flex justify-content-between align-items-center" style="background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%); border: none; padding: 1.25rem 1.5rem;">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-box me-2"></i>Recent Products</h5>
                    <a href="<?php echo ADMIN_URL; ?>/products.php" class="btn btn-sm btn-light shadow-sm"><i class="fas fa-arrow-right me-1"></i>View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php $index = 1; foreach ($recentProducts as $product): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <span class="badge bg-info rounded-circle" style="width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">
                                            <?php echo $index++; ?>
                                        </span>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($product['title']); ?></h6>
                                        <small class="text-muted">
                                            <i class="fas fa-tag me-1"></i><?php echo formatPrice($product['price']); ?>
                                            <span class="mx-2">•</span>
                                            <i class="fas fa-shopping-bag me-1"></i><?php echo $product['sold']; ?> sold
                                            <span class="mx-2">•</span>
                                            <i class="fas fa-clock me-1"></i><?php echo date('M j, Y', strtotime($product['created_at'])); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <?php if ($product['status'] === 'active'): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Blog Posts -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100 border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                <div class="card-header text-white d-flex justify-content-between align-items-center" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); border: none; padding: 1.25rem 1.5rem;">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-blog me-2"></i>Recent Blog Posts</h5>
                    <a href="<?php echo ADMIN_URL; ?>/blogs.php" class="btn btn-sm btn-light shadow-sm"><i class="fas fa-arrow-right me-1"></i>View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php $index = 1; foreach ($recentBlogs as $blog): ?>
                            <div class="list-group-item">
                                <div class="d-flex align-items-center">
                                    <div class="me-3">
                                        <span class="badge bg-success rounded-circle" style="width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">
                                            <?php echo $index++; ?>
                                        </span>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($blog['title']); ?></h6>
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($blog['author']); ?>
                                            <span class="mx-2">•</span>
                                            <i class="fas fa-eye me-1"></i><?php echo $blog['views'] ?? 0; ?> views
                                            <span class="mx-2">•</span>
                                            <i class="fas fa-clock me-1"></i><?php echo date('M j, Y', strtotime($blog['created_at'])); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <?php if ($blog['status'] === 'published'): ?>
                                            <span class="badge bg-success">Published</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Draft</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Recent Orders -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                <div class="card-header text-white d-flex justify-content-between align-items-center" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 1.25rem 1.5rem;">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-shopping-cart me-2"></i>Recent Orders</h5>
                    <a href="<?php echo ADMIN_URL; ?>/orders.php" class="btn btn-sm btn-light shadow-sm"><i class="fas fa-arrow-right me-1"></i>View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Order #</th>
                                    <th>Customer</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td class="fw-bold"><?php echo htmlspecialchars($order['order_number']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($order['user_name']); ?><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($order['user_email']); ?></small>
                                        </td>
                                        <td class="fw-bold text-primary"><?php echo formatPrice($order['final_amount']); ?></td>
                                        <td>
                                            <?php
                                            $statusClass = match($order['payment_status']) {
                                                'completed' => 'success',
                                                'pending' => 'warning',
                                                'failed' => 'danger',
                                                'refunded' => 'info',
                                                default => 'secondary'
                                            };
                                            ?>
                                            <span class="badge bg-<?php echo $statusClass; ?>">
                                                <?php echo ucfirst($order['payment_status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Top Selling Products -->
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                <div class="card-header text-white" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border: none; padding: 1.25rem 1.5rem;">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-fire me-2"></i>Top Selling Products</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($topProducts as $product): ?>
                        <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($product['title']); ?></h6>
                                <small class="text-muted">
                                    <i class="fas fa-shopping-bag me-1"></i><?php echo $product['sold']; ?> sold
                                </small>
                            </div>
                            <div class="text-end">
                                <span class="fw-bold text-primary"><?php echo formatPrice($product['price']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Monthly Revenue Chart -->
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; overflow: hidden;">
                <div class="card-header text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 1.25rem 1.5rem;">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-chart-line me-2"></i>Monthly Revenue (Last 6 Months)</h5>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart" height="80"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Revenue Chart
const ctx = document.getElementById('revenueChart').getContext('2d');
const revenueData = <?php echo json_encode(array_reverse($monthlyRevenue)); ?>;

const labels = revenueData.map(item => {
    const date = new Date(item.month + '-01');
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
});

const data = revenueData.map(item => parseFloat(item.revenue));

new Chart(ctx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Revenue',
            data: data,
            borderColor: 'rgb(25, 118, 210)',
            backgroundColor: 'rgba(25, 118, 210, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '<?php echo getSetting('currency_symbol', '$'); ?>' + value.toFixed(2);
                    }
                }
            }
        }
    }
});
</script>

<!-- Google Instant Indexing Modal -->
<div class="modal fade" id="googleIndexModal" tabindex="-1" aria-labelledby="googleIndexModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="googleIndexModalLabel">
                    <i class="fab fa-google me-2"></i>Google Instant Indexing API
                </h5>
                <button type="button" class="btn-close btn-close-white" data-mdb-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" id="googleIndexForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Google Instant Indexing:</strong> Submit your product URLs to Google for immediate crawling and indexing. This helps your products appear in search results faster.
                    </div>
                    
                    <div class="card border-warning mb-4">
                        <div class="card-header bg-warning text-dark">
                            <h6 class="mb-0">
                                <i class="fas fa-exclamation-triangle me-2"></i>Setup Required
                            </h6>
                        </div>
                        <div class="card-body">
                            <p class="mb-2"><strong>To use Google Instant Indexing, you need to:</strong></p>
                            <ol class="mb-0">
                                <li>Enable the <strong>Indexing API</strong> in Google Cloud Console</li>
                                <li>Create a <strong>Service Account</strong> and download the JSON key file</li>
                                <li>Add the service account email to your <strong>Google Search Console</strong> property</li>
                                <li>Upload the JSON key file to: <code>/config/google-indexing-key.json</code></li>
                            </ol>
                            <a href="https://developers.google.com/search/apis/indexing-api/v3/quickstart" target="_blank" class="btn btn-sm btn-warning mt-3">
                                <i class="fas fa-book me-2"></i>View Setup Guide
                            </a>
                        </div>
                    </div>
                    
                    <h6 class="fw-bold mb-3">
                        <i class="fas fa-list me-2"></i>Select Products to Submit to Google
                    </h6>
                    
                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table table-hover">
                            <thead class="table-light sticky-top">
                                <tr>
                                    <th width="50">
                                        <input type="checkbox" id="selectAll" class="form-check-input">
                                    </th>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>URL</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $allProducts = $db->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
                                $index = 1;
                                foreach ($allProducts as $product): 
                                ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="product_ids[]" value="<?php echo $product['id']; ?>" class="form-check-input product-checkbox">
                                        </td>
                                        <td><?php echo $index++; ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($product['title']); ?></strong>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <i class="fas fa-link me-1"></i>
                                                <?php echo SITE_URL . '/' . $product['slug']; ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php if ($product['status'] === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small><?php echo date('M j, Y', strtotime($product['created_at'])); ?></small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="card bg-light mt-3">
                        <div class="card-body">
                            <h6 class="fw-bold mb-2">
                                <i class="fas fa-rocket me-2 text-success"></i>What Happens Next?
                            </h6>
                            <ul class="mb-0 small text-muted">
                                <li>Selected product URLs will be submitted to Google Indexing API</li>
                                <li>Google will crawl and index your products within minutes (usually)</li>
                                <li>Products will appear in Google Search results faster</li>
                                <li>You can submit up to 200 URLs per day (Google API limit)</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Cancel
                    </button>
                    <button type="submit" name="submit_to_google" class="btn btn-success" id="submitBtn" disabled>
                        <i class="fab fa-google me-2"></i>Submit to Google (<span id="selectedCount">0</span> selected)
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Select All Checkbox
document.getElementById('selectAll')?.addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.product-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
    updateSelectedCount();
});

// Individual Checkboxes
document.querySelectorAll('.product-checkbox').forEach(cb => {
    cb.addEventListener('change', updateSelectedCount);
});

function updateSelectedCount() {
    const selected = document.querySelectorAll('.product-checkbox:checked').length;
    document.getElementById('selectedCount').textContent = selected;
    document.getElementById('submitBtn').disabled = selected === 0;
}
</script>

<style>
/* Modern Card Animations */
.stat-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2) !important;
}

/* Button Hover Effects */
.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

/* Product Index Badge */
.badge.rounded-circle {
    font-weight: 600;
    font-size: 0.875rem;
}

/* Card Hover Effects */
.card {
    transition: all 0.3s ease;
}

.card:hover {
    transform: translateY(-3px);
}

/* List Item Hover */
.list-group-item {
    transition: all 0.3s ease;
}

.list-group-item:hover {
    background-color: #f8f9fa;
    transform: translateX(5px);
}

/* Modal Animations */
.modal.fade .modal-dialog {
    transition: transform 0.3s ease-out;
}

/* Success Alert Animation */
@keyframes slideInDown {
    from {
        transform: translateY(-100%);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.alert {
    animation: slideInDown 0.5s ease-out;
}

/* Fade in animation for cards */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card {
    animation: fadeInUp 0.6s ease-out;
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }

/* Smooth scrollbar */
::-webkit-scrollbar {
    width: 10px;
    height: 10px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: #555;
}

/* Welcome card pulse effect */
@keyframes pulse {
    0%, 100% {
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
    }
    50% {
        box-shadow: 0 10px 40px rgba(102, 126, 234, 0.5);
    }
}

.bg-gradient-primary {
    animation: pulse 3s infinite;
}

/* Gradient animations for stat cards */
@keyframes gradient-shift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.card.bg-primary,
.card.bg-success,
.card.bg-info,
.card.bg-warning {
    background-size: 200% 200%;
    animation: gradient-shift 5s ease infinite;
    transition: all 0.3s ease;
}

.card.bg-primary:hover,
.card.bg-success:hover,
.card.bg-info:hover,
.card.bg-warning:hover {
    transform: translateY(-10px) scale(1.05);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

/* Number counter animation */
@keyframes countUp {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card h3 {
    animation: countUp 0.5s ease-out;
}

/* Icon rotation on hover */
.card-body i {
    transition: transform 0.3s ease;
}

.card:hover .card-body i {
    transform: rotate(15deg) scale(1.1);
}

/* Badge pulse */
@keyframes badge-pulse {
    0%, 100% {
        transform: scale(1);
        opacity: 1;
    }
    50% {
        transform: scale(1.1);
        opacity: 0.8;
    }
}

.badge.bg-success {
    animation: badge-pulse 2s infinite;
}

/* Shimmer effect for cards */
@keyframes shimmer {
    0% {
        background-position: -1000px 0;
    }
    100% {
        background-position: 1000px 0;
    }
}

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.card:hover::before {
    left: 100%;
}
</style>

<script>
// Real-time clock and greeting
function updateDateTime() {
    const now = new Date();
    const hours = now.getHours();
    
    // Dynamic greeting
    let greeting = 'Good Morning';
    if (hours >= 12 && hours < 17) {
        greeting = 'Good Afternoon';
    } else if (hours >= 17) {
        greeting = 'Good Evening';
    }
    
    document.getElementById('greeting').textContent = greeting;
    
    // Current date
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
}

// Animated number counter
function animateValue(id, start, end, duration) {
    const obj = document.getElementById(id);
    if (!obj) return;
    
    const range = end - start;
    let current = start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    
    const timer = setInterval(function() {
        current += increment;
        obj.textContent = current;
        if (current == end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    updateDateTime();
    setInterval(updateDateTime, 60000); // Update every minute
    
    // Add tooltip initialization
    const tooltips = document.querySelectorAll('[data-mdb-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new mdb.Tooltip(tooltip);
    });
});

// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>
