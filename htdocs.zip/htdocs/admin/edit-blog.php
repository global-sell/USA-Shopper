<?php
require_once __DIR__ . '/../config/config.php';

// Check if user is admin
if (!isAdmin()) {
    redirect(SITE_URL . '/login.php');
}

$db = Database::getInstance();
$blogId = (int)($_GET['id'] ?? 0);

if ($blogId <= 0) {
    redirect(ADMIN_URL . '/blogs.php');
}

// Get blog details
$stmt = $db->prepare("SELECT * FROM blogs WHERE id = ?");
$stmt->bind_param("i", $blogId);
$stmt->execute();
$blog = $stmt->get_result()->fetch_assoc();

if (!$blog) {
    redirect(ADMIN_URL . '/blogs.php');
}

$pageTitle = "Edit Blog";
require_once 'includes/admin-header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title'] ?? '');
    $excerpt = sanitizeInput($_POST['excerpt'] ?? '');
    $content = $_POST['content'] ?? ''; // Don't sanitize content (allow HTML)
    $author = sanitizeInput($_POST['author'] ?? 'Admin');
    $category = sanitizeInput($_POST['category'] ?? '');
    $tags = sanitizeInput($_POST['tags'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? 'draft');
    
    if (empty($title) || empty($content)) {
        $error = 'Title and content are required';
    } else {
        // Generate slug
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        // Handle featured image upload
        $imagePath = $blog['featured_image']; // Keep existing image
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (in_array($_FILES['featured_image']['type'], $allowedTypes)) {
                $fileName = time() . '_' . basename($_FILES['featured_image']['name']);
                $targetPath = UPLOADS_PATH . '/blogs/' . $fileName;
                
                // Create directory if it doesn't exist
                if (!is_dir(UPLOADS_PATH . '/blogs')) {
                    mkdir(UPLOADS_PATH . '/blogs', 0777, true);
                }
                
                if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $targetPath)) {
                    // Delete old image if exists
                    if (!empty($blog['featured_image']) && file_exists(UPLOADS_PATH . '/blogs/' . $blog['featured_image'])) {
                        unlink(UPLOADS_PATH . '/blogs/' . $blog['featured_image']);
                    }
                    $imagePath = $fileName;
                }
            }
        }
        
        try {
            $stmt = $db->prepare("UPDATE blogs SET title = ?, slug = ?, excerpt = ?, content = ?, 
                                 featured_image = ?, author = ?, category = ?, tags = ?, status = ? 
                                 WHERE id = ?");
            $stmt->bind_param("sssssssssi", $title, $slug, $excerpt, $content, $imagePath, 
                             $author, $category, $tags, $status, $blogId);
            
            if ($stmt->execute()) {
                $success = 'Blog updated successfully!';
                // Refresh blog data
                $stmt = $db->prepare("SELECT * FROM blogs WHERE id = ?");
                $stmt->bind_param("i", $blogId);
                $stmt->execute();
                $blog = $stmt->get_result()->fetch_assoc();
            } else {
                $error = 'Failed to update blog: ' . $stmt->error;
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Blog Post</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-8 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="title" name="title" class="form-control" 
                                           value="<?php echo htmlspecialchars($blog['title']); ?>" required>
                                    <label class="form-label" for="title">Blog Title *</label>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <label class="form-label" for="status">Status</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="draft" <?php echo $blog['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                                    <option value="published" <?php echo $blog['status'] === 'published' ? 'selected' : ''; ?>>Published</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="excerpt">Excerpt/Summary</label>
                            <textarea id="excerpt" name="excerpt" class="form-control" rows="2" 
                                      placeholder="Brief summary of the blog post"><?php echo htmlspecialchars($blog['excerpt'] ?? ''); ?></textarea>
                        </div>

                        <?php // SEO checker include for blogs ?>
                        <?php
                        $seoPath = __DIR__ . '/includes/seo-checker.php';
                        if (file_exists($seoPath)) {
                            require_once $seoPath;
                        }
                        ?>
                        
                        <div class="mb-4">
                            <label class="form-label" for="content">Content *</label>
                            <textarea id="content" name="content" class="form-control" rows="15" required 
                                      placeholder="Write your blog content here..."><?php echo htmlspecialchars($blog['content']); ?></textarea>
                            <small class="text-muted">You can use HTML tags for formatting</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="author" name="author" class="form-control" 
                                           value="<?php echo htmlspecialchars($blog['author'] ?? 'Admin'); ?>">
                                    <label class="form-label" for="author">Author</label>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="category" name="category" class="form-control" 
                                           value="<?php echo htmlspecialchars($blog['category'] ?? ''); ?>"
                                           placeholder="e.g., Shopping Tips">
                                    <label class="form-label" for="category">Category</label>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="tags" name="tags" class="form-control" 
                                           value="<?php echo htmlspecialchars($blog['tags'] ?? ''); ?>"
                                           placeholder="e.g., shopping, deals, tips">
                                    <label class="form-label" for="tags">Tags (comma separated)</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="featured_image">
                                <i class="fas fa-image me-2"></i>Featured Image
                            </label>
                            
                            <?php if (!empty($blog['featured_image'])): ?>
                                <div class="mb-3">
                                    <img src="<?php echo UPLOADS_URL; ?>/blogs/<?php echo $blog['featured_image']; ?>" 
                                         alt="Current featured image" 
                                         style="max-width: 300px; height: auto; border-radius: 8px;">
                                    <p class="text-muted small mt-2">Current featured image</p>
                                </div>
                            <?php endif; ?>
                            
                            <input type="file" id="featured_image" name="featured_image" class="form-control" accept="image/*">
                            <small class="text-muted">Upload a new featured image to replace the current one (recommended: 1200x630px)</small>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save me-2"></i>Update Blog
                            </button>
                            <a href="<?php echo ADMIN_URL; ?>/blogs.php" class="btn btn-secondary btn-lg">
                                <i class="fas fa-arrow-left me-2"></i>Back to Blogs
                            </a>
                            <a href="<?php echo SITE_URL; ?>/blog/<?php echo $blog['slug']; ?>" 
                               class="btn btn-info btn-lg" target="_blank">
                                <i class="fas fa-eye me-2"></i>Preview
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
