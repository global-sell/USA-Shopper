<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to add items to cart']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Handle both JSON and form-urlencoded data
$productId = 0;
if (isset($_POST['product_id'])) {
    $productId = (int)$_POST['product_id'];
} else {
    $data = json_decode(file_get_contents('php://input'), true);
    $productId = (int)($data['product_id'] ?? 0);
}

if ($productId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
    exit;
}

$db = Database::getInstance();

// Check if product exists and is active
$stmt = $db->prepare("SELECT id, title, price FROM products WHERE id = ? AND status = 'active'");
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Product not found']);
    exit;
}

// Check if user already purchased this product
$stmt = $db->prepare("SELECT COUNT(*) as count FROM order_items oi 
                     JOIN orders o ON oi.order_id = o.id 
                     WHERE o.user_id = ? AND oi.product_id = ? AND o.payment_status = 'completed'");
$stmt->bind_param("ii", $_SESSION['user_id'], $productId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    echo json_encode(['success' => false, 'message' => 'You already own this product']);
    exit;
}

// Check if already in cart
$stmt = $db->prepare("SELECT id FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->bind_param("ii", $_SESSION['user_id'], $productId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Product already in cart']);
    exit;
}

// Add to cart
$stmt = $db->prepare("INSERT INTO cart (user_id, product_id) VALUES (?, ?)");
$stmt->bind_param("ii", $_SESSION['user_id'], $productId);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Product added to cart']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add product to cart']);
}
?>
