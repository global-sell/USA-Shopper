<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$count = 0;

if (isLoggedIn()) {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];
}

echo json_encode(['count' => $count]);
?>
