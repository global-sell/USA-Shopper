<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration
require_once __DIR__ . '/database.php';

// Include Turnstile configuration
require_once __DIR__ . '/turnstile.php';

// Site Configuration
define('SITE_URL', 'https://us.usashopper.site');
define('ADMIN_URL', SITE_URL . '/admin');
define('ASSETS_URL', SITE_URL . '/assets');
define('UPLOADS_URL', SITE_URL . '/uploads');

// Directory paths
define('ROOT_PATH', dirname(__DIR__));
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('PRODUCTS_PATH', UPLOADS_PATH . '/products');
define('SCREENSHOTS_PATH', UPLOADS_PATH . '/screenshots');

// Create upload directories if they don't exist
if (!file_exists(UPLOADS_PATH)) mkdir(UPLOADS_PATH, 0755, true);
if (!file_exists(PRODUCTS_PATH)) mkdir(PRODUCTS_PATH, 0755, true);
if (!file_exists(SCREENSHOTS_PATH)) mkdir(SCREENSHOTS_PATH, 0755, true);

// Security settings
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_HASH_COST', 10);

// Session timeout (30 minutes)
define('SESSION_TIMEOUT', 1800);

// Download settings
define('MAX_DOWNLOADS_PER_PRODUCT', 5);
define('DOWNLOAD_LINK_EXPIRY_DAYS', 30);

// Pagination
define('PRODUCTS_PER_PAGE', 12);
define('ORDERS_PER_PAGE', 10);

// Helper Functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && isset($_SESSION['role']) && 
           ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin');
}

function isSuperAdmin() {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'super_admin';
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT id, name, email, role, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function redirect($url) {
    header("Location: " . $url);
    exit();
}

function getSetting($key, $default = '') {
    $db = Database::getInstance();
    $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['setting_value'];
    }
    return $default;
}

function updateSetting($key, $value) {
    $db = Database::getInstance();
    $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                         ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param("sss", $key, $value, $value);
    return $stmt->execute();
}

function formatPrice($amount) {
    $symbol = getSetting('currency_symbol', '$');
    return $symbol . number_format($amount, 2);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function sendEmail($to, $subject, $message) {
    // Get SendGrid API key from settings
    $sendgridApiKey = getSetting('sendgrid_api_key', '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');
    $fromEmail = getSetting('from_email', 'noreply@rangpurfood.com');
    $fromName = getSetting('from_name', 'Rangpur Food');
    
    // Prepare SendGrid API request
    $data = [
        'personalizations' => [
            [
                'to' => [
                    ['email' => $to]
                ],
                'subject' => $subject
            ]
        ],
        'from' => [
            'email' => $fromEmail,
            'name' => $fromName
        ],
        'content' => [
            [
                'type' => 'text/html',
                'value' => $message
            ]
        ]
    ];
    
    // Send via SendGrid API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.sendgrid.com/v3/mail/send');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $sendgridApiKey,
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Log email for debugging
    $logDir = ROOT_PATH . '/logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    
    $logFile = $logDir . '/emails.log';
    $logEntry = "\n\n" . str_repeat('=', 80) . "\n";
    $logEntry .= "Date: " . date('Y-m-d H:i:s') . "\n";
    $logEntry .= "To: $to\n";
    $logEntry .= "Subject: $subject\n";
    $logEntry .= "Status: " . ($httpCode == 202 ? 'SUCCESS' : 'FAILED') . "\n";
    $logEntry .= "HTTP Code: $httpCode\n";
    $logEntry .= "Response: $response\n";
    $logEntry .= str_repeat('=', 80) . "\n";
    
    @file_put_contents($logFile, $logEntry, FILE_APPEND);
    
    // SendGrid returns 202 for successful queue
    return ($httpCode == 202);
}

function generateOrderNumber() {
    return 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

function checkSessionTimeout() {
    if (isLoggedIn()) {
        if (isset($_SESSION['last_activity']) && 
            (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            session_unset();
            session_destroy();
            return false;
        }
        $_SESSION['last_activity'] = time();
    }
    return true;
}

// Check session timeout on every page load
checkSessionTimeout();

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>