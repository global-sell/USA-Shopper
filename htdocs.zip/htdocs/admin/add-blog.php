<?php
$pageTitle = "Add Blog";
require_once 'includes/admin-header.php';

$db = Database::getInstance();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title'] ?? '');
    $excerpt = sanitizeInput($_POST['excerpt'] ?? '');
    $content = $_POST['content'] ?? ''; // Don't sanitize content (allow HTML)
    $author = sanitizeInput($_POST['author'] ?? 'Admin');
    $category = sanitizeInput($_POST['category'] ?? '');
    $tags = sanitizeInput($_POST['tags'] ?? '');
    $status = sanitizeInput($_POST['status'] ?? 'draft');
    
    if (empty($title) || empty($content)) {
        $error = 'Title and content are required';
    } else {
        // Get custom slug or generate from title
        $customSlug = sanitizeInput($_POST['slug'] ?? '');
        if (!empty($customSlug)) {
            // Use custom slug and sanitize it
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $customSlug)));
        } else {
            // Auto-generate slug from title
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        }
        
        // Handle featured image upload
        $imagePath = '';
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (in_array($_FILES['featured_image']['type'], $allowedTypes)) {
                $fileName = time() . '_' . basename($_FILES['featured_image']['name']);
                $targetPath = UPLOADS_PATH . '/blogs/' . $fileName;
                
                // Create directory if it doesn't exist
                if (!is_dir(UPLOADS_PATH . '/blogs')) {
                    mkdir(UPLOADS_PATH . '/blogs', 0777, true);
                }
                
                if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $targetPath)) {
                    $imagePath = $fileName;
                }
            }
        }
        
        try {
            $stmt = $db->prepare("INSERT INTO blogs (title, slug, excerpt, content, featured_image, author, category, tags, status) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssss", $title, $slug, $excerpt, $content, $imagePath, $author, $category, $tags, $status);
            
            if ($stmt->execute()) {
                redirect(ADMIN_URL . '/blogs.php?added=1');
            } else {
                $error = 'Failed to add blog: ' . $stmt->error;
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Add New Blog Post</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="title" name="title" class="form-control" required>
                                    <label class="form-label" for="title">Blog Title *</label>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="slug" name="slug" class="form-control">
                                    <label class="form-label" for="slug">Permalink (Slug)</label>
                                </div>
                                <small class="text-muted">
                                    <i class="fas fa-link me-1"></i>URL: <?php echo SITE_URL; ?>/blog/<span id="slug-preview"></span>
                                </small>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <label class="form-label" for="status">Status</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="draft">Draft</option>
                                    <option value="published">Published</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="excerpt">Excerpt/Summary</label>
                            <textarea id="excerpt" name="excerpt" class="form-control" rows="2" 
                                      placeholder="Brief summary of the blog post"></textarea>
                        </div>

                        <?php // SEO checker include for blogs ?>
                        <?php
                        $seoPath = __DIR__ . '/includes/seo-checker.php';
                        if (file_exists($seoPath)) {
                            require_once $seoPath;
                        }
                        ?>
                        
                        <div class="mb-4">
                            <label class="form-label" for="content">Content *</label>
                            <textarea id="content" name="content" class="form-control" rows="15" required 
                                      placeholder="Write your blog content here..."></textarea>
                            <small class="text-muted">You can use HTML tags for formatting</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="author" name="author" class="form-control" value="Admin">
                                    <label class="form-label" for="author">Author</label>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="category" name="category" class="form-control" 
                                           placeholder="e.g., Shopping Tips">
                                    <label class="form-label" for="category">Category</label>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-4">
                                <div class="form-outline">
                                    <input type="text" id="tags" name="tags" class="form-control" 
                                           placeholder="e.g., shopping, deals, tips">
                                    <label class="form-label" for="tags">Tags (comma separated)</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="featured_image">
                                <i class="fas fa-image me-2"></i>Featured Image
                            </label>
                            <input type="file" id="featured_image" name="featured_image" class="form-control" accept="image/*">
                            <small class="text-muted">Upload a featured image for your blog post (recommended: 1200x630px)</small>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save me-2"></i>Publish Blog
                            </button>
                            <a href="<?php echo ADMIN_URL; ?>/blogs.php" class="btn btn-secondary btn-lg">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Generate slug from string
function generateSlug(text) {
    return text
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9-]+/g, '-')
        .replace(/^-+|-+$/g, '');
}

// Update slug preview and input
function updateSlugPreview() {
    const slugInput = document.getElementById('slug');
    const slugPreview = document.getElementById('slug-preview');
    const titleInput = document.getElementById('title');
    
    let slug = slugInput.value;
    if (!slug && titleInput.value) {
        slug = generateSlug(titleInput.value);
    }
    
    slugPreview.textContent = slug || 'your-blog-slug';
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    const slugInput = document.getElementById('slug');
    const titleInput = document.getElementById('title');
    let manuallyEdited = false; // Track if user manually edited slug
    
    // Update slug preview when slug input changes
    slugInput.addEventListener('input', function() {
        manuallyEdited = true; // User is manually editing
        updateSlugPreview();
    });
    
    // Auto-generate slug from title
    titleInput.addEventListener('input', function() {
        // Only auto-update if user hasn't manually edited the slug
        if (!manuallyEdited) {
            const generatedSlug = generateSlug(titleInput.value);
            slugInput.value = generatedSlug;
            updateSlugPreview();
        }
    });
    
    // Allow user to clear and reset auto-generation
    slugInput.addEventListener('focus', function() {
        if (!slugInput.value) {
            manuallyEdited = false;
        }
    });
    
    // Initial preview
    updateSlugPreview();
});
</script>

<?php require_once 'includes/admin-footer.php'; ?>
