<?php
session_start();
require_once __DIR__ . '/../config/config.php';

$provider = $_GET['provider'] ?? '';

if (!in_array($provider, ['google', 'facebook', 'twitter'])) {
    redirect(SITE_URL . '/signup.php');
}

// Demo mode - simulate social login
// In production, this would redirect to OAuth providers

$pageTitle = ucfirst($provider) . " Login Demo";
require_once __DIR__ . '/../includes/header.php';
?>

<section class="py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 40vh; display: flex; align-items: center;">
    <div class="container text-center text-white">
        <div class="animate__animated animate__fadeInDown">
            <?php if ($provider === 'google'): ?>
                <i class="fab fa-google fa-4x mb-3"></i>
                <h1 class="display-4 fw-bold mb-3">Continue with Google</h1>
            <?php elseif ($provider === 'facebook'): ?>
                <i class="fab fa-facebook-f fa-4x mb-3"></i>
                <h1 class="display-4 fw-bold mb-3">Continue with Facebook</h1>
            <?php else: ?>
                <i class="fab fa-twitter fa-4x mb-3"></i>
                <h1 class="display-4 fw-bold mb-3">Continue with Twitter</h1>
            <?php endif; ?>
            <p class="lead mb-0">Quick and secure signup</p>
        </div>
    </div>
</section>

<div class="container py-5" style="margin-top: -80px;">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="card border-0 shadow-lg animate__animated animate__fadeInUp" style="border-radius: 20px;">
                <div class="card-body p-4 p-md-5">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Demo Mode</strong><br>
                        This is a demonstration of social login. Enter your details below to simulate <?php echo ucfirst($provider); ?> signup.
                    </div>
                    
                    <form method="POST" action="<?php echo SITE_URL; ?>/auth/process-social-demo.php">
                        <input type="hidden" name="provider" value="<?php echo $provider; ?>">
                        
                        <div class="form-outline mb-4">
                            <input type="text" id="name" name="name" class="form-control form-control-lg" required>
                            <label class="form-label" for="name">Full Name</label>
                        </div>
                        
                        <div class="form-outline mb-4">
                            <input type="email" id="email" name="email" class="form-control form-control-lg" required>
                            <label class="form-label" for="email">Email Address</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100 mb-3" style="border-radius: 10px; padding: 15px;">
                            <i class="fab fa-<?php echo $provider; ?> me-2"></i>Continue with <?php echo ucfirst($provider); ?>
                        </button>
                        
                        <div class="text-center">
                            <a href="<?php echo SITE_URL; ?>/signup.php" class="text-muted">
                                <i class="fas fa-arrow-left me-1"></i>Back to Signup
                            </a>
                        </div>
                    </form>
                    
                    <div class="mt-4 pt-4 border-top">
                        <h6 class="fw-bold mb-3">How to Enable Real OAuth:</h6>
                        <ol class="small text-muted">
                            <li>Get OAuth credentials from <?php echo ucfirst($provider); ?> Developer Console</li>
                            <li>Update credentials in <code>auth/<?php echo $provider; ?>-login.php</code></li>
                            <li>Configure redirect URIs</li>
                            <li>Remove demo mode</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    transition: transform 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
