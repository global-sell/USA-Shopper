<?php
require_once __DIR__ . '/../config/config.php';

// Check if user is admin
if (!isAdmin()) {
    redirect(SITE_URL . '/login.php');
}

$db = Database::getInstance();

// Handle delete (BEFORE any output)
if (isset($_GET['delete'])) {
    $categoryId = (int)$_GET['delete'];
    $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    redirect(ADMIN_URL . '/categories.php?deleted=1');
}

// Handle toggle status (BEFORE any output)
if (isset($_GET['toggle_status'])) {
    $categoryId = (int)$_GET['toggle_status'];
    $stmt = $db->prepare("UPDATE categories SET status = IF(status = 'active', 'inactive', 'active') WHERE id = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    redirect(ADMIN_URL . '/categories.php?updated=1');
}

$pageTitle = "Manage Categories";
require_once 'includes/admin-header.php';

$error = '';
$success = '';

// Handle add category
if (isset($_POST['add_category'])) {
    $name = sanitizeInput($_POST['name'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    
    if (empty($name)) {
        $error = 'Category name is required';
    } elseif (!isset($_FILES['icon']) || $_FILES['icon']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Category icon/logo is required';
    } else {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        
        // Handle icon upload
        $iconPath = '';
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/svg+xml'];
        
        if (!in_array($_FILES['icon']['type'], $allowedTypes)) {
            $error = 'Invalid file type. Please upload PNG, JPG, GIF or SVG';
        } else {
            $fileName = time() . '_' . basename($_FILES['icon']['name']);
            $targetPath = UPLOADS_PATH . '/categories/' . $fileName;
            
            // Create directory if it doesn't exist
            if (!is_dir(UPLOADS_PATH . '/categories')) {
                mkdir(UPLOADS_PATH . '/categories', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['icon']['tmp_name'], $targetPath)) {
                $iconPath = $fileName;
            } else {
                $error = 'Failed to upload icon. Please try again.';
            }
        }
        
        // Only insert if no errors occurred
        if (empty($error)) {
            // Check if icon column exists
            $columns = $db->query("SHOW COLUMNS FROM categories LIKE 'icon'")->fetch_all(MYSQLI_ASSOC);
            
            if (!empty($columns)) {
                // Icon column exists
                $stmt = $db->prepare("INSERT INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $name, $slug, $description, $iconPath);
            } else {
                // Icon column doesn't exist
                $stmt = $db->prepare("INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $slug, $description);
            }
            
            if ($stmt->execute()) {
                $success = 'Category added successfully';
            } else {
                $error = 'Failed to add category. Slug might already exist.';
            }
        }
    }
}

// Get all categories
$categories = $db->query("SELECT c.*, 
                         (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count 
                         FROM categories c 
                         ORDER BY c.name")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4">
        <i class="fas fa-folder me-2"></i>Manage Categories
    </h2>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Category deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Add Category Form -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Add New Category</h5>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-outline mb-4">
                            <input type="text" id="name" name="name" class="form-control" required>
                            <label class="form-label" for="name">Category Name</label>
                        </div>
                        
                        <div class="form-outline mb-4">
                            <textarea id="description" name="description" class="form-control" rows="3"></textarea>
                            <label class="form-label" for="description">Description</label>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label" for="icon">
                                <i class="fas fa-image me-2"></i>Category Icon/Logo <span class="text-danger">*</span>
                            </label>
                            <input type="file" id="icon" name="icon" class="form-control" accept="image/*" required>
                            <small class="text-muted">Upload PNG, JPG, GIF or SVG (recommended: 100x100px)</small>
                        </div>
                        
                        <button type="submit" name="add_category" class="btn btn-primary w-100">
                            <i class="fas fa-plus me-2"></i>Add Category
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Categories List -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Icon</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Products</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $category): ?>
                                    <tr>
                                        <td><?php echo $category['id']; ?></td>
                                        <td>
                                            <?php if (isset($category['icon']) && !empty($category['icon'])): ?>
                                                <img src="<?php echo UPLOADS_URL; ?>/categories/<?php echo $category['icon']; ?>" 
                                                     alt="<?php echo htmlspecialchars($category['name']); ?>" 
                                                     style="width: 40px; height: 40px; object-fit: cover; border-radius: 5px;">
                                            <?php else: ?>
                                                <div style="width: 40px; height: 40px; background: #e0e0e0; border-radius: 5px; display: flex; align-items: center; justify-content: center;">
                                                    <i class="fas fa-folder text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($category['name']); ?></td>
                                        <td><code><?php echo htmlspecialchars($category['slug']); ?></code></td>
                                        <td><?php echo $category['product_count']; ?> products</td>
                                        <td>
                                            <?php if ($category['status'] === 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="<?php echo SITE_URL; ?>/products.php?category=<?php echo $category['slug']; ?>" 
                                                   class="btn btn-info" target="_blank" title="View Products">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="?toggle_status=<?php echo $category['id']; ?>" 
                                                   class="btn btn-warning" title="Toggle Status">
                                                    <i class="fas fa-toggle-on"></i>
                                                </a>
                                                <a href="?delete=<?php echo $category['id']; ?>" 
                                                   class="btn btn-danger" 
                                                   onclick="return confirmDelete('Are you sure? This will not delete products, just unlink them.')" 
                                                   title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
