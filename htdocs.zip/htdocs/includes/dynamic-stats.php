<?php
function generateRandomStats() {
    // Use a per-visitor cookie as the seed so each visitor sees different numbers.
    // If the cookie doesn't exist, create a random one and persist it for 30 days.
    $cookieName = 'visitor_stats_seed';
    if (!empty($_COOKIE[$cookieName])) {
        $visitorSeed = $_COOKIE[$cookieName];
    } else {
        // random 16 hex chars
        $visitorSeed = bin2hex(random_bytes(8));
        setcookie($cookieName, $visitorSeed, time() + 30 * 24 * 60 * 60, "/", "", false, true);
        // also populate $_COOKIE for the current request
        $_COOKIE[$cookieName] = $visitorSeed;
    }

    // Create a seed from the visitor cookie and current day so values are different
    // per visitor and still refresh daily. Remove date('Y-m-d') here if you want
    // values persistent instead of daily-changing.
    $seed = crc32($visitorSeed . date('Y-m-d'));
    mt_srand($seed);
    
    // Generate random numbers within reasonable ranges
    // Ranges: products 600k-1M, orders 600k-1M, countries 70-85, customers 600k-1M
    // Generate random numbers within reasonable ranges
    // Ranges: products 600k-1M, orders 600k-1M, countries 70-85, customers 600k-1M
    $stats = [
        'products' => mt_rand(600000, 1000000),   // Products between 600,000 - 1,000,000
        'orders' => mt_rand(600000, 1000000),     // Orders between 600,000 - 1,000,000
        'countries' => mt_rand(70, 85),           // Countries between 70 - 85
        'customers' => mt_rand(600000, 1000000)   // Customers between 600,000 - 1,000,000
    ];
    
    return $stats;
}
?>