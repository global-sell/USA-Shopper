<?php
/**
 * Cloudflare Turnstile Configuration
 * 
 * To get your Turnstile keys:
 * 1. Go to https://dash.cloudflare.com/
 * 2. Select your account
 * 3. Go to Turnstile section
 * 4. Create a new site
 * 5. Copy the Site Key and Secret Key
 */

// Turnstile Configuration
define('TURNSTILE_SITE_KEY', '0x4AAAAAAB-sJBO_GtmVrIPg');
define('TURNSTILE_SECRET_KEY', '0x4AAAAAAB-sJEPM7gXe_NBb30gXENW0Mqg');

// Turnstile API endpoint
define('TURNSTILE_VERIFY_URL', 'https://challenges.cloudflare.com/turnstile/v0/siteverify');

/**
 * Verify Turnstile token
 * @param string $token The Turnstile token from the form
 * @param string $remoteip The user's IP address (optional)
 * @return array Response with success status and error codes
 */
function verifyTurnstile($token, $remoteip = null) {
    if (empty($token)) {
        return [
            'success' => false,
            'error' => 'Missing Turnstile token'
        ];
    }
    
    if (TURNSTILE_SECRET_KEY === 'YOUR_TURNSTILE_SECRET_KEY_HERE') {
        // Development mode - always return success if keys not configured
        error_log('Turnstile: Using development mode - keys not configured');
        return [
            'success' => true,
            'development_mode' => true
        ];
    }
    
    $data = [
        'secret' => TURNSTILE_SECRET_KEY,
        'response' => $token
    ];
    
    if ($remoteip) {
        $data['remoteip'] = $remoteip;
    }
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $response = file_get_contents(TURNSTILE_VERIFY_URL, false, $context);
    
    if ($response === false) {
        return [
            'success' => false,
            'error' => 'Failed to verify Turnstile token'
        ];
    }
    
    $result = json_decode($response, true);
    
    if (!$result) {
        return [
            'success' => false,
            'error' => 'Invalid response from Turnstile API'
        ];
    }
    
    return $result;
}

/**
 * Check if Turnstile is properly configured
 * @return bool
 */
function isTurnstileConfigured() {
    return TURNSTILE_SITE_KEY !== 'YOUR_TURNSTILE_SITE_KEY_HERE' && 
           TURNSTILE_SECRET_KEY !== 'YOUR_TURNSTILE_SECRET_KEY_HERE';
}

/**
 * Get Turnstile widget HTML
 * @param string $theme Theme: 'light', 'dark', or 'auto'
 * @param string $size Size: 'normal' or 'compact'
 * @return string HTML for Turnstile widget
 */
function getTurnstileWidget($theme = 'auto', $size = 'normal') {
    if (!isTurnstileConfigured()) {
        return '<!-- Turnstile not configured - using development mode -->';
    }
    
    return '<div class="cf-turnstile" data-sitekey="' . TURNSTILE_SITE_KEY . '" data-theme="' . $theme . '" data-size="' . $size . '"></div>';
}
