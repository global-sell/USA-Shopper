<?php
require_once __DIR__ . '/../config/config.php';

// Check if user is admin
if (!isAdmin()) {
    redirect(SITE_URL . '/login.php');
}

$db = Database::getInstance();

// Handle delete
if (isset($_GET['delete'])) {
    $productId = (int)$_GET['delete'];
    $db->query("DELETE FROM products WHERE id = $productId");
    redirect(ADMIN_URL . '/products.php?deleted=1');
}

// Handle status toggle
if (isset($_GET['toggle_status'])) {
    $productId = (int)$_GET['toggle_status'];
    $db->query("UPDATE products SET status = IF(status = 'active', 'inactive', 'active') WHERE id = $productId");
    redirect(ADMIN_URL . '/products.php?updated=1');
}

$pageTitle = "Manage Products";
require_once 'includes/admin-header.php';

// Get all products
$products = $db->query("SELECT p.*, c.name as category_name 
                       FROM products p 
                       LEFT JOIN categories c ON p.category_id = c.id 
                       ORDER BY p.created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">
            <i class="fas fa-box me-2"></i>Manage Products
        </h2>
        <a href="<?php echo ADMIN_URL; ?>/add-product.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add New Product
        </a>
    </div>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Product deleted successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i>Product updated successfully
            <button type="button" class="btn-close" data-mdb-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Sold</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?php echo $product['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($product['title']); ?></strong><br>
                                    <small class="text-muted"><?php echo substr(htmlspecialchars($product['description']), 0, 60); ?>...</small>
                                </td>
                                <td><?php echo htmlspecialchars($product['category_name'] ?? 'N/A'); ?></td>
                                <td class="fw-bold text-primary"><?php echo formatPrice($product['price']); ?></td>
                                <td><i class="fas fa-shopping-bag me-1"></i><?php echo $product['sold']; ?></td>
                                <td>
                                    <?php if ($product['status'] === 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo SITE_URL; ?>/product-detail.php?id=<?php echo $product['id']; ?>" 
                                           class="btn btn-info" target="_blank" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo ADMIN_URL; ?>/edit-product.php?id=<?php echo $product['id']; ?>" 
                                           class="btn btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="?toggle_status=<?php echo $product['id']; ?>" 
                                           class="btn btn-warning" title="Toggle Status">
                                            <i class="fas fa-toggle-on"></i>
                                        </a>
                                        <a href="?delete=<?php echo $product['id']; ?>" 
                                           class="btn btn-danger" 
                                           onclick="return confirmDelete('Are you sure you want to delete this product?')" 
                                           title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
